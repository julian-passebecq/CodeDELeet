# v2.6 QA Report

## Scope

This pass focused on regression safety and organization after the large curriculum expansion:

- Home/core progress consistency
- Core / Supporting / Optional classification
- SQL dialect and Multi-Engine switching safeguards
- source-derived previews
- Monaco appearance wiring
- Storage & Performance coverage
- Pipeline Troubleshooting coverage
- learning-hub / Home navigation targets
- production bundle integrity
- keyboard/reduced-motion behavior for organized curriculum cards

## Defects found and fixed

### 1. Core progress classification drift

The v2.5 Home page still maintained its own hard-coded Core track set. Airflow, Git and Cloud CLI could therefore affect the Home Core progress percentage even though the organized curriculum correctly showed them under Supporting Tools.

**Fix:** `src/curriculumTiers.js` is now the single source of truth used by both Home progress and curriculum grouping.

### 2. Stale MLOps tier identifier

The organized tier list contained an old `mlops-optional` identifier while the real track is `mlops-practical`.

**Fix:** the shared optional tier uses the canonical track ID, and CI verifies that every track belongs to exactly one explicit tier.

### 3. MutationObserver update pressure

The Home and organization bridges watched the React tree and could run their synchronization code for every relevant subtree mutation.

**Fix:** those synchronization calls are now coalesced through `requestAnimationFrame`.

### 4. Build regression was not enforced

v2.5 split a previously oversized JavaScript bundle, but nothing prevented a later configuration change from collapsing the bundles again.

**Fix:** `scripts/dist-check.mjs` verifies built asset references, expected vendor/curriculum chunks and a 500 KiB maximum individual JS chunk size.

### 5. Repository documentation drift

README, VERSION and QA documentation still described the old v1.4 / 206-item application.

**Fix:** repository documentation now describes v2.6 and the current 296-item trainer.

## Current validated structure

- 24 curriculum tracks
- 184 curriculum exercises
- 60 SQL challenge concepts
- 24 Multi-Engine challenges
- 28 Python Syntax Gym drills
- 296 distinct practice items
- 180 SQL dialect variants
- 81 Multi-Engine implementations

Additional dedicated validation covers Algorithms, Analytics Engineering, Junior → Senior, uploaded PySpark source labs, optional NoSQL/Kubernetes/GenAI/MLOps breadth, Storage & Performance, Pipeline Troubleshooting, Airflow troubleshooting, source previews, editor themes and navigation wiring.

## Commands

```bash
npm run validate
npm run build
npm run dist:check
```

Complete pass:

```bash
npm run check
```

GitHub Actions runs the same validation/build/asset-verification sequence for `main` pushes and pull requests.
