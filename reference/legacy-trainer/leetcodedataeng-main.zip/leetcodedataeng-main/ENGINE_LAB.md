# v1.3 practice-lab design

## Why dialects are variants instead of duplicate exercises

A join, aggregation, ranking, or latest-row problem is a *data operation*. Treating T-SQL, DuckDB and BigQuery as three unrelated exercises would inflate counts without improving conceptual transfer. v1.3 therefore keeps one SQL challenge and switches the dialect-specific starter/solution.

## Why pandas and PySpark are paired

pandas and PySpark share a DataFrame mental model but differ materially in execution. The Multi-Engine Lab intentionally places their syntax side by side while the explanations call out distributed concepts such as Column expressions, windows, shuffles, broadcast joins and repartitioning.

## Progress semantics

- Flags / mastery are tracked at the conceptual-problem level.
- Code drafts are stored separately per SQL dialect or engine.
- Solutions remain hidden until the user selects Solution or Compare.

## Content policy

The imported notebook packs remain a distinct challenge source. The new Multi-Engine and Python labs are original trainer exercises created to complement those packs and the pre-existing core curriculum.
