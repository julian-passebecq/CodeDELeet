# Visual learning research — v2.13

This pass intentionally separates **concept animation** from **system architecture**:

- use React/CSS/SVG animation when the learner needs to see state change over time;
- use Mermaid only when the learner needs to see topology, dependency, or architecture;
- use a compact static/animated cheat sheet when the goal is rapid pattern recognition.

## Sources reviewed

### Algorithm animation patterns

- VisuAlgo — https://visualgo.net/en
  - strong pattern: play/pause, step-by-step state, user-controlled pacing, visible algorithm state;
  - useful for search, sorting, graph traversal, heaps, and other stateful algorithms.
- David Galles / University of San Francisco Data Structure Visualizations — https://www.cs.usfca.edu/~galles/visualizations/
  - strong pattern: play/pause, step forward/back, animation speed, algorithm-specific controls;
  - useful reminder that animation controls should explain an operation rather than merely decorate it.

### SQL visual explanations

- SQL Window Functions Visualized — Medium / Learning SQL
  - https://medium.com/learning-sql/sql-window-function-visualized-fff1927f00f2
  - useful teaching idea: explicitly show how PARTITION, ORDER, and the current window are constructed and moved row by row.
- SQL Window Functions Explained Visually — Medium
  - https://medium.com/@sqlmentor/sql-window-functions-explained-visually-b571c3726384
  - useful teaching idea: show input rows and visible output for ranking/running-total patterns rather than only displaying syntax.
- Window Functions Demystified — Medium
  - https://medium.com/@SwanandPotnis/window-functions-demystified-sqls-most-powerful-feature-explained-visually-223d190fa2e1
  - useful teaching idea: emphasize that window functions preserve row detail while reading a related set of rows.

### ML / visual explanation references

- What Is Machine Learning? — A visual explanation — Medium / TDS Archive
  - https://medium.com/data-science/what-is-machine-learning-a-visual-explanation-14642b90429f
- Awesome Machine Learning Visualizations — Medium / Analytics Vidhya
  - https://medium.com/analytics-vidhya/awesome-machine-learning-visualizations-5208f1617ec5

These ML articles were used only as a pedagogical reference: a small diagram should communicate the model intuition directly. The Data Engineering trainer is not being expanded into a duplicate ML course.

## Design rules used in the trainer

1. **Animate the state that changes.**
   - current row during a scan;
   - moving window boundaries;
   - two pointers;
   - queue/visited state in BFS;
   - ready nodes in a DAG;
   - rows disappearing after `rn = 1`;
   - partitions/blocks being pruned.

2. **Show one mental model at a time.**
   A concept card has one visual, one current-step explanation, and a small complexity/pattern badge.

3. **Give the learner control.**
   Play/pause, previous, next, direct-step dots, reset, and speed controls are available on animated practice concepts.

4. **Do not use Mermaid for micro-behavior.**
   Mermaid remains appropriate for CDC/Fabric/dbt/Spark architecture and dependency topology. It is not used for row scans, sorting, window movement, joins, or partition pruning.

5. **Respect reduced motion.**
   Autoplay is disabled when `prefers-reduced-motion: reduce` is active, and CSS motion is removed.

6. **Prefer data-job examples.**
   Arrays are represented as rows, batches, files, partitions, business keys, DAG tasks, and lakehouse layers whenever possible.

7. **Do not copy article artwork.**
   The implementation uses original React/CSS/SVG visualizations inspired by general teaching patterns, not reproduced article graphics.
