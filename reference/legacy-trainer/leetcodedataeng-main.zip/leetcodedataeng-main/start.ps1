$ErrorActionPreference = "Stop"
if (-not (Test-Path "node_modules")) {
    Write-Host "Installing dependencies..."
    npm install
}
Write-Host "Starting the Coding Reset Lab..."
npm run dev
