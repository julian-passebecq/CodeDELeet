import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

function manualChunks(id) {
  if (id.includes('node_modules')) {
    if (id.includes('@monaco-editor') || id.includes('monaco-editor')) return 'editor-vendor'
    if (id.includes('react') || id.includes('scheduler')) return 'react-vendor'
    if (id.includes('lucide-react')) return 'icons-vendor'
    return 'vendor'
  }

  const curriculumModules = [
    '/src/curriculum.js',
    '/src/curriculumTiers.js',
    '/src/sqlChallenges.js',
    '/src/engineLab.js',
    '/src/pythonLab.js',
    '/src/algorithmExtensions.js',
    '/src/analyticsEngineeringExtensions.js',
    '/src/seniorityExtensions.js',
    '/src/sourceCourseExtensions.js',
    '/src/storagePerformanceExtensions.js',
    '/src/pipelineTroubleshootingExtensions.js',
    '/src/airflowTroubleshootingExtensions.js',
    '/src/sourcePreviewData.js',
    '/src/courseSourcePreviewData.js',
    '/src/learningHubContent.js',
    '/src/cheatSheets.js',
  ]

  if (curriculumModules.some((modulePath) => id.includes(modulePath))) return 'curriculum-data'
  return undefined
}

export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    rollupOptions: {
      output: { manualChunks },
    },
  },
})
