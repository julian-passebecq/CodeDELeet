# Data Engineering Coding Reset Lab — v2.12.2

## Animated concept explanation + visual cheat-sheet pass

v2.12.2 keeps the existing **323 practice items** and Data Engineering-first curriculum. The change is pedagogical: concepts that are easier to understand as changing state are now taught with original React/CSS/SVG animations rather than Mermaid boxes.

### Visual teaching model

- **Custom animation for behavior** — row scans, binary search, hash maps, dedupe, stack/queue, batching, sorting, two pointers, sliding windows, prefix sums, Top K, BFS, topological ordering, interval merging, SQL ranking, joins, partition pruning, medallion layers and Git state transitions.
- **Mermaid for architecture/topology** — CDC, Fabric, dbt/Spark lineage and other system relationships remain Mermaid where dependency/topology is the concept.
- **Static/animated visual cheat sheets for recognition** — Big-O patterns and SQL row-behavior patterns are summarized in compact visual reference panels.

### Interactive concept controls

Animated practice cards expose:

- Play / Pause
- Previous / Next
- Reset
- direct step dots
- 0.75× / 1× / 1.5× speed
- a concise explanation for the active state
- `prefers-reduced-motion` support; autoplay and CSS motion are suppressed for users requesting reduced motion.

### Classical algorithms

All **15 classical algorithm drills** now resolve to a concept-specific visual rather than the former generic input → pattern → result strip:

1. linear search
2. frequency map / hash lookup
3. ordered deduplication with a seen set
4. stack vs queue
5. batching
6. nested-loop lookup → hash lookup
7. binary search
8. stable sorting
9. two pointers
10. sliding window
11. prefix sums
12. heap / Top K
13. BFS graph traversal
14. topological sort
15. merge intervals

The Big-O visual cheat sheet reinforces O(1), O(log n), O(n), O(n log n), O(n²), O(V+E) and O(n log k) by showing how much work is touched rather than only displaying formulas.

### Data-job visual concepts

Additional practice concepts get animation when state change helps understanding:

- **SQL latest-row / dedupe** — raw rows → `PARTITION BY` → newest-first ordering → `ROW_NUMBER` → keep `rn = 1`.
- **SQL visual reference** — WHERE filters, JOIN connects, GROUP BY collapses, WINDOW preserves detail, QUALIFY filters the computed window result.
- **Partitioning / clustering** — candidate blocks visibly disappear first through partition pruning and then through narrower clustered-block selection.
- **Join** — business keys highlight on both sides before output rows appear.
- **Bronze → Silver → Gold** — the active medallion stage advances from raw landing to conformed data to business-ready output.
- **Git** — EDIT → ADD → COMMIT → PULL/REBASE → PUSH, with working-tree/staging/local-history/remote state shown explicitly.

### Research basis

`VISUAL_LEARNING_RESEARCH.md` records the teaching patterns reviewed from VisuAlgo, David Galles' Data Structure Visualizations, visual SQL-window explanations on Medium, and selected visual ML explainers. The implementation is original and does not reproduce article artwork.

The key rule is explicit: **do not use Mermaid for micro-behavior**. Mermaid remains useful for architecture; stateful data/algorithm behavior uses purpose-built visual components.

### Visual architecture/icon layer retained

v2.12.1 improvements remain intact:

- current Microsoft Fabric, Power BI and Fabric Lakehouse SVGs bundled locally;
- official Python mark with non-affiliation treatment;
- neutral pictograms for restricted or visually unsuitable vendor marks;
- 8 Mermaid `architecture-beta` diagrams;
- Mermaid 11.17.2, strict security, deterministic architecture layout and source fallback.

## Current curriculum shape

- 24 curriculum tracks
- **211 curriculum exercises**
- 60 SQL challenge concepts
- 24 Multi-Engine challenges
- 28 Python Syntax Gym drills
- **323 distinct practice items**
- 180 SQL dialect variants
- 81 Multi-Engine implementations
- **145 Core / 38 Supporting / 28 Optional** curriculum drills
- **15 classical algorithm drills with animated visual coverage**
- **19 interactive visual scene families**
- **8 Mermaid architecture-beta diagrams**

## QA

```bash
npm run validate
npm run build
npm run dist:check
```

`npm run validate` now includes `scripts/animated-concept-check.mjs`, which enforces algorithm coverage, SQL window semantics, partition-pruning progression, interaction controls, reduced-motion support, animation-frame DOM synchronization, visual cheat sheets and the Mermaid-vs-animation separation.

GitHub Actions runs validation, production build and generated-asset smoke checks on pushes to `main` and pull requests.
