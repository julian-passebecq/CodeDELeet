# Data Engineering Coding Reset Lab

React + Vite training site for practical data-engineering coding, interview preparation and production-oriented troubleshooting.

**Current release: v2.12.2**

The trainer contains **323 distinct practice items**:

- **211 curriculum exercises** across 24 tracks
- **60 SQL challenge concepts** with T-SQL, DuckDB and BigQuery variants
- **24 Multi-Engine challenges** with SQL / pandas / PySpark implementations where relevant
- **28 Python Syntax Gym drills**
- **180 SQL dialect variants** validated
- **81 Multi-Engine implementations** validated
- **145 Core / 38 Supporting / 28 Optional** curriculum exercises

The curriculum stays Data Engineering-first: SQL, Python, PySpark, storage design, troubleshooting, dbt/Analytics Engineering, modeling, data quality and reliable pipelines are Core. Docker, Kubernetes, MLOps, NoSQL and GenAI remain Optional breadth.

## Core learning path

1. Programming Foundations
2. Classical Algorithms
3. Python
4. SQL / T-SQL
5. Storage · Formats · Performance
6. PySpark + Structured Streaming
7. Pipeline Troubleshooting · CDC · recovery
8. Analytics Engineering · dbt
9. Junior → Senior comparisons
10. BI / DAX and business modeling

Core topics include Parquet/Avro/JSON, Delta Lake, Iceberg, DuckDB, partitioning, liquid clustering, V-Order, indexes, Spark AQE/shuffles/skew, Structured Streaming, CDC, idempotency, SCD2, quality gates, dbt incremental/microbatch/contracts, Fabric Mirroring and practical ETL troubleshooting.

## Visual learning system — v2.12.2

The main visual rule is now explicit:

> **Animate behavior; diagram architecture.**

Mermaid remains useful for topology, dependency and architecture. It is no longer the primary teaching device for row-level or algorithmic behavior.

### Interactive animated concept cards

Practice pages can now show original React/CSS/SVG concept animations with:

- Play / Pause
- Previous / Next
- Reset
- direct step selection
- 0.75× / 1× / 1.5× speed
- a concise explanation for the active state
- reduced-motion support

The layer contains **19 interactive scene families** covering:

- row-by-row linear scan
- binary search halving
- hash lookup / frequency map
- ordered dedupe with a seen set
- stack vs queue
- bounded batching
- stable sorting
- two pointers
- sliding windows
- prefix sums
- heap / Top K
- BFS traversal
- topological ordering
- interval merging
- SQL ranking / latest-row dedupe
- joins
- partition pruning / clustering
- Bronze → Silver → Gold
- Git working-tree → staging → commit → upstream/remote states

All **15 classical algorithm drills** are mapped to concept-specific visuals instead of a generic flow strip.

### SQL explained as row behavior

SQL window and transformation concepts now emphasize what happens to rows:

- **WHERE** → rows are filtered
- **JOIN** → rows connect on keys
- **GROUP BY** → detail rows collapse to groups
- **WINDOW** → row detail is preserved while related rows are inspected
- **QUALIFY** → rows are filtered after the window result exists

The latest-record animation explicitly shows:

**raw rows → PARTITION BY business key → newest-first ORDER BY → ROW_NUMBER → keep rn = 1**

This is intentionally a state animation rather than Mermaid.

### Visual Big-O cheat sheet

The Algorithms/Coding Concepts hub includes a compact visual reference for:

- O(1) hash lookup
- O(log n) binary search
- O(n) scan
- O(n) sliding window
- O(n log n) sort/merge
- O(n²) nested loops
- O(V+E) graph traversal
- O(n log k) Top K heap

The goal is to recognize the *amount and shape of work* rather than memorize formulas in isolation.

### Data Engineering visuals

The same visual language is used where it adds intuition:

- partition pruning visibly removes irrelevant blocks, then clustering narrows candidate blocks further;
- joins highlight matching business keys before producing output rows;
- medallion architecture progresses Bronze → Silver → Gold;
- Git moves through EDIT → ADD → COMMIT → PULL/REBASE → PUSH;
- DAG/lineage algorithm exercises animate active/visited/ready nodes.

## Mermaid architecture layer

Mermaid is pinned to **11.17.2** with `securityLevel: 'strict'`, deterministic architecture layout and source-text fallback.

Eight topology-heavy lessons use `architecture-beta`, including:

- CDC log → connector → stream → lakehouse
- Fabric Mirroring → OneLake → SQL/Spark/Power BI
- file format → table format → catalog → engine
- OpenLineage impact paths
- dbt staging/facts/marts
- Bronze → PySpark → Silver Delta → MERGE → Gold Delta

Process/state animations do **not** depend on Mermaid.

## Technology visuals

- current Microsoft Fabric, Power BI and Fabric Lakehouse SVG assets are bundled locally for training/reference use;
- the official Python mark is used nominatively with non-affiliation treatment;
- neutral technical pictograms are used where vendor-logo permissions are restrictive or a generic icon communicates the concept better;
- Home cards, hubs, curriculum cards, documentation links and diagram headings share one technology visual registry.

## Reference / learning hubs

Major language/domain hubs use a five-part structure:

1. Cheat sheet
2. Algorithms / patterns
3. Source labs
4. Typical problems
5. Interview preparation

The current reference layer includes Python, pandas/NumPy, PySpark, SQL/T-SQL, DuckDB, dbt, PowerShell, C#, Airflow 3, DAX/BI, Kubernetes, Storage & Performance, Pipeline Troubleshooting and Data Engineering Interview material.

## Production-oriented coverage

### Analytics Engineering

- dbt + DuckDB setup
- sources / staging / marts
- raw log parsing
- tests and documentation
- incremental + microbatch models
- model contracts vs data tests
- pandas/PySpark equivalents
- Delta `MERGE`

### Modern lakehouse

- Iceberg hidden partitioning/evolution
- DuckDB Iceberg scans/snapshots
- Databricks/Fabric liquid clustering
- Fabric V-Order
- Spark AQE
- Polars lazy Parquet scans
- evidence-based DuckDB / Polars / PySpark selection

### Airflow 3 + Structured Streaming

- public `airflow.sdk`
- Dataset → Asset terminology
- data-aware scheduling
- API-server / DAG-processor migration concepts
- watermarks and checkpoints
- `foreachBatch` idempotency
- stream-stream joins

### Reliability / troubleshooting

- schema drift and missing rows
- duplicate reruns / idempotency
- late data / watermarks
- skew and driver OOM
- partitions and small files
- retries and Airflow queue/retry failures
- safe backfills
- CDC offsets/deletes/recovery
- dbt contracts
- OpenLineage impact analysis
- Fabric Mirroring diagnostics

## Practice UX

- Monaco Editor with Gray / Black / Light syntax themes
- Code / Solution / Compare views
- dialect/engine-specific drafts
- T-SQL / DuckDB / BigQuery switching
- SQL / pandas / PySpark translation practice
- animated concept cards and visual cheat sheets
- source-derived Data Preview tables
- Mermaid architecture/flow diagrams where appropriate
- first-party documentation links
- hints, common traps and notes
- flags and mastery tracking
- exact JSON progress backup / restore with rollback
- responsive/keyboard-accessible interface

## Visual research / adaptation policy

`VISUAL_LEARNING_RESEARCH.md` records the visual teaching patterns reviewed from VisuAlgo, David Galles' Data Structure Visualizations, visual SQL-window explanations on Medium and selected visual ML explainers.

The trainer uses those sources as **pedagogical references only**. Its animations are original React/CSS/SVG implementations; article graphics are not copied.

The documented design rules include:

- animate the state that changes;
- show one mental model at a time;
- give the learner control over playback;
- do not use Mermaid for micro-behavior;
- prefer data-job examples;
- respect `prefers-reduced-motion`.

## Reliability / CI

`npm run validate` checks curriculum integrity, SQL/engine variants, source previews, storage/troubleshooting coverage, tier consistency, backup behavior, all **323 globally unique practice titles**, editor themes, variant-draft protection, current web-verified material, visual architecture and the new animated concept contracts.

The dedicated `scripts/animated-concept-check.mjs` enforces:

- exactly 15 classical algorithm drills remain visually covered;
- all 19 scene families exist;
- SQL ROW_NUMBER dedupe stays distinct from algorithmic seen-set dedupe;
- SQL ranking visibly orders before ranking/filtering;
- partition pruning progresses from partition to clustered-block selection;
- playback/step/speed/reset controls remain;
- reduced-motion behavior remains;
- visual cheat sheets remain mounted;
- the micro-behavior layer has no Mermaid dependency.

```bash
npm install
npm run validate
npm run build
npm run dist:check
# or
npm run check
```

The production build keeps React/editor/curriculum chunks separated and CI rejects JavaScript chunks over 500 KiB.

## Deployment

The app is deployed as a static Netlify site. Source-derived preview data is shown where available, but the browser does not pretend to execute cloud services or original notebooks remotely.

Third-party attribution remains in `THIRD_PARTY_NOTICES.md` and `ZILLACODE_APACHE_LICENSE.txt`.
