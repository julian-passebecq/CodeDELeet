import { lessons, tracks } from './curriculum.js'

const TRACK_ID = 'seniority'

const seniorityTrack = {
  id: TRACK_ID,
  name: 'Junior → Senior Data Engineering',
  short: 'Junior vs Senior',
  icon: 'JS',
  description: 'Compare code that works locally with code designed for reruns, late data, scale, observability and production recovery.',
  concepts: ['incremental load', 'idempotency', 'deduplication', 'late data', 'data quality', 'join strategy', 'Delta MERGE', 'dbt incremental', 'retries', 'observability'],
}

const incrementalFlow = `flowchart LR
  S[Source changes] --> W[Watermark / CDC]
  W --> T[Stage batch]
  T --> D[Deduplicate]
  D --> M[MERGE / upsert]
  M --> Q[Quality + reconciliation]
  Q --> A[Audit watermark]`

const sparkFlow = `flowchart LR
  F[Large fact] --> P[Filter + select early]
  D[Small dimension] --> B[Broadcast]
  P --> J[Join]
  B --> J
  J --> G[Aggregate]
  G --> M[Delta MERGE]`

const qualityFlow = `flowchart LR
  I[Ingest] --> C{Contract checks}
  C -->|valid| S[Silver]
  C -->|invalid| Q[Quarantine]
  S --> R[Reconciliation]
  R --> P[Publish]
  Q --> O[Metrics / alert]`

const dbtFlow = `flowchart LR
  SRC[source()] --> STG[staging]
  STG --> INT[intermediate]
  INT --> MART[mart]
  MART --> TEST[tests]
  MART --> DOC[docs / lineage]
  TEST --> DEPLOY[CI / deploy]`

const S = (x) => ({ sourcePack: 'Junior vs Senior — production data engineering', ...x })

const additions = [
  S({
    id: 'js-sql-incremental', track: TRACK_ID, level: 'Intermediate', language: 'sql', title: 'SQL: full append → incremental idempotent load',
    concept: 'Junior code often optimizes for getting today’s rows loaded. Senior code defines replay semantics, a business key and a safe state transition.',
    why: 'Interview lens: How does this behave on reruns, updates, deletes, late arrivals and a table 100× larger?',
    context: 'Interview questions: How will this handle reruns? What is the watermark? What happens when an order is updated after yesterday’s run?',
    task: 'Read the Junior baseline in Code. Then open Compare and identify the production guarantees added by the Senior version.',
    starter: `-- JUNIOR: valid for a simple append-only daily feed
INSERT INTO fact_orders (order_id, customer_id, amount, updated_at)
SELECT order_id, customer_id, amount, updated_at
FROM staging_orders
WHERE CAST(updated_at AS date) = CAST(GETDATE() AS date);`,
    solution: `-- SENIOR: replay-safe incremental upsert
WITH source_batch AS (
    SELECT order_id, customer_id, amount, updated_at,
           ROW_NUMBER() OVER (
               PARTITION BY order_id
               ORDER BY updated_at DESC
           ) AS rn
    FROM staging_orders
    WHERE updated_at >= @watermark_from
      AND updated_at <  @watermark_to
)
MERGE fact_orders AS t
USING (SELECT * FROM source_batch WHERE rn = 1) AS s
   ON t.order_id = s.order_id
WHEN MATCHED AND s.updated_at >= t.updated_at THEN
  UPDATE SET customer_id = s.customer_id,
             amount = s.amount,
             updated_at = s.updated_at
WHEN NOT MATCHED THEN
  INSERT (order_id, customer_id, amount, updated_at)
  VALUES (s.order_id, s.customer_id, s.amount, s.updated_at);`,
    solutionExplanation: 'The senior version makes the load bounded, deduplicates a business key, tolerates replay and updates only when the incoming version is at least as recent. In production you would advance the watermark only after validation succeeds.',
    hints: ['Look for a deterministic business key.', 'A rerun should converge to the same final state.', 'Watermark state should advance only after a successful publish.'],
    pitfall: 'A date-only append can duplicate reruns and miss updates that arrive after the original processing date.',
    diagram: incrementalFlow,
  }),
  S({
    id: 'js-sql-dedupe', track: TRACK_ID, level: 'Intermediate', language: 'sql', title: 'SQL: DISTINCT → deterministic latest-record dedupe',
    concept: 'DISTINCT removes byte-identical rows. Production deduplication usually chooses one winner per business key using explicit ordering.',
    why: 'A senior answer states the key, tie-breaker and audit behavior instead of saying “just use DISTINCT”.',
    context: 'Interview questions: Which row wins? What if updated_at ties? How do you prove no business key is duplicated afterward?',
    task: 'Compare the two approaches and explain why the senior query is deterministic for duplicate order events.',
    starter: `-- JUNIOR: useful only when duplicate rows are truly identical
SELECT DISTINCT
    order_id,
    customer_id,
    amount,
    updated_at
FROM raw_orders;`,
    solution: `-- SENIOR: choose one winner per business key
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY order_id
               ORDER BY updated_at DESC, ingestion_id DESC
           ) AS rn
    FROM raw_orders
)
SELECT order_id, customer_id, amount, updated_at
FROM ranked
WHERE rn = 1;`,
    solutionExplanation: 'The senior query defines business-key uniqueness and a deterministic winner. The extra ingestion_id tie-breaker prevents nondeterministic results when source timestamps collide.',
    hints: ['DISTINCT has no “latest row” semantics.', 'ROW_NUMBER needs both a partition key and an ordering rule.'],
    pitfall: 'Ordering only by a non-unique timestamp can still produce nondeterministic winners.',
  }),
  S({
    id: 'js-python-files', track: TRACK_ID, level: 'Intermediate', language: 'python', title: 'Python: load everything → bounded batch ingestion',
    concept: 'Junior scripts often materialize every file at once. Senior control code bounds memory, validates inputs and makes failures observable.',
    why: 'The goal is not clever Python; it is predictable behavior when the file count grows and one file is malformed.',
    context: 'Interview questions: What happens with 20,000 files? How do you retry one batch? Where do rejected files go?',
    task: 'Compare the simple pandas load with a batch-oriented version and identify the scalability/recovery differences.',
    starter: `from pathlib import Path
import pandas as pd

paths = list(Path('landing').glob('*.parquet'))
df = pd.concat([pd.read_parquet(path) for path in paths])
df.to_parquet('silver/orders.parquet')`,
    solution: `from pathlib import Path
import pandas as pd


def batches(items, size=100):
    for i in range(0, len(items), size):
        yield items[i:i + size]

paths = sorted(Path('landing').glob('*.parquet'))
for batch_id, batch in enumerate(batches(paths, 100)):
    frames = [pd.read_parquet(path) for path in batch]
    chunk = pd.concat(frames, ignore_index=True)
    if chunk['order_id'].isna().any():
        raise ValueError(f'batch {batch_id}: null order_id')
    chunk.to_parquet(
        f'silver/orders/part-{batch_id:05d}.parquet',
        index=False,
    )`,
    solutionExplanation: 'The senior version bounds the working set, sorts input paths for repeatability, validates the batch before publishing and writes deterministic batch outputs that can be retried independently.',
    hints: ['Bound the number of files handled together.', 'Deterministic ordering makes reruns easier to reason about.'],
    pitfall: 'Batching alone is not idempotency; output naming and publish semantics also need to be deterministic.',
  }),
  S({
    id: 'js-python-api', track: TRACK_ID, level: 'Expert', language: 'python', title: 'Python: one GET → resilient paginated ingestion',
    concept: 'Production API ingestion needs timeouts, bounded retries, status validation, pagination and a checkpoint.',
    why: 'A request that works once on a laptop is not yet a reliable ingestion pipeline.',
    context: 'Interview questions: Which failures are retryable? How do you resume page 438? How do you avoid an infinite pagination loop?',
    task: 'Compare the short API call with a bounded, observable pagination loop.',
    starter: `import requests

rows = requests.get('https://api.example.com/orders').json()
print(len(rows))`,
    solution: `import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

session = requests.Session()
retry = Retry(
    total=4,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=['GET'],
)
session.mount('https://', HTTPAdapter(max_retries=retry))

page = 1
while True:
    response = session.get(
        'https://api.example.com/orders',
        params={'page': page, 'page_size': 500},
        timeout=(5, 30),
    )
    response.raise_for_status()
    payload = response.json()
    rows = payload['items']
    if not rows:
        break
    write_page_idempotently(page, rows)
    save_checkpoint(page)
    page += 1`,
    solutionExplanation: 'The senior version retries only GET requests for transient statuses, uses explicit connection/read timeouts, validates HTTP failures, pages deterministically and checkpoints only after an idempotent write.',
    hints: ['Never leave network calls without a timeout.', 'Retrying POST blindly can duplicate side effects.'],
    pitfall: 'Retries without idempotent writes can make correctness worse rather than better.',
  }),
  S({
    id: 'js-pyspark-join', track: TRACK_ID, level: 'Intermediate', language: 'python', title: 'PySpark: blind join → size-aware join plan',
    concept: 'Spark performance is dominated by data movement. Senior code reduces columns/rows early and chooses a join strategy from table size and skew.',
    why: 'Interview lens: Where is the shuffle? Which side is small? Are keys skewed? What will happen at 100× data volume?',
    context: 'orders is a multi-terabyte fact; customers is a small dimension. Only paid orders and three fact columns are needed.',
    task: 'Compare the correct but naive join with a plan that reduces shuffle and data volume.',
    starter: `result = (
    orders
    .join(customers, on='customer_id', how='left')
    .filter("status = 'PAID'")
    .groupBy('country')
    .sum('amount')
)`,
    solution: `from pyspark.sql import functions as F

paid = (
    orders
    .filter(F.col('status') == 'PAID')
    .select('customer_id', 'amount', 'order_date')
)

dim = customers.select('customer_id', 'country')

result = (
    paid
    .join(F.broadcast(dim), on='customer_id', how='left')
    .groupBy('country')
    .agg(F.sum('amount').alias('revenue'))
)`,
    solutionExplanation: 'The senior version filters and projects the large fact before the join and broadcasts the genuinely small dimension, avoiding a large-side shuffle. A senior answer also says broadcast must be justified by real size/statistics rather than habit.',
    hints: ['Filter/select the large side as early as possible.', 'Broadcast only when the dimension really fits worker memory.'],
    pitfall: 'Forcing broadcast on a large or unexpectedly growing dimension can cause executor memory failures.',
    diagram: sparkFlow,
  }),
  S({
    id: 'js-pyspark-delta', track: TRACK_ID, level: 'Expert', language: 'python', title: 'PySpark: append → dedupe + Delta MERGE',
    concept: 'Appending every micro-batch is simple. A senior design defines event identity and converges repeated or updated events into one target state.',
    why: 'This combines distributed deduplication, idempotent writes and incremental lakehouse processing.',
    context: 'order_id is the business key. update_ts defines recency. The same source event can be delivered more than once.',
    task: 'Compare append-only output with a deduplicated Delta MERGE.',
    starter: `(
    incoming
    .write
    .format('delta')
    .mode('append')
    .saveAsTable('silver.orders')
)`,
    solution: `from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.window import Window

w = Window.partitionBy('order_id').orderBy(F.col('update_ts').desc())
batch = (
    incoming
    .withColumn('_rn', F.row_number().over(w))
    .filter(F.col('_rn') == 1)
    .drop('_rn')
)

target = DeltaTable.forName(spark, 'silver.orders')
(
    target.alias('t')
    .merge(batch.alias('s'), 't.order_id = s.order_id')
    .whenMatchedUpdateAll(condition='s.update_ts >= t.update_ts')
    .whenNotMatchedInsertAll()
    .execute()
)`,
    solutionExplanation: 'The senior version first picks one source winner per key, then upserts only newer/equal versions. That makes duplicate delivery and reruns converge toward the same target state.',
    hints: ['Deduplicate the batch before MERGE.', 'Guard matched updates with recency.'],
    pitfall: 'MERGE is not automatically correct if the source contains multiple rows for the same target key.',
    diagram: incrementalFlow,
  }),
  S({
    id: 'js-dbt-incremental', track: TRACK_ID, level: 'Expert', language: 'sql', title: 'dbt: strict max watermark → late-data lookback',
    concept: 'A strict max(updated_at) predicate is efficient but can permanently miss late-arriving records. Senior incremental logic deliberately re-reads a bounded lookback.',
    why: 'dbt interviews often test whether you understand incremental materialization beyond copying is_incremental().',
    context: 'Events can arrive 48 hours late. order_id is unique. The model is rebuilt many times per day.',
    task: 'Compare the two incremental predicates and explain the correctness/cost trade-off.',
    starter: `{{ config(materialized='incremental') }}

select *
from {{ ref('stg_orders') }}
{% if is_incremental() %}
where updated_at > (select max(updated_at) from {{ this }})
{% endif %}`,
    solution: `{{ config(
    materialized='incremental',
    unique_key='order_id',
    incremental_strategy='merge'
) }}

select *
from {{ ref('stg_orders') }}
{% if is_incremental() %}
where updated_at >= (
    select coalesce(max(updated_at), timestamp '1900-01-01')
           - interval 2 day
    from {{ this }}
)
{% endif %}`,
    solutionExplanation: 'The senior model declares the unique key and merge semantics, then trades a small reprocessing window for protection against late-arriving updates. The correct lookback length should come from observed lateness/SLA data.',
    hints: ['A lookback intentionally reprocesses some already-seen rows.', 'Reprocessing is safe only when the write is idempotent.'],
    pitfall: 'A lookback without a unique key/merge can simply create duplicates faster.',
    diagram: dbtFlow,
  }),
  S({
    id: 'js-quality-gate', track: TRACK_ID, level: 'Intermediate', language: 'python', title: 'Data quality: assert → quarantine + reconciliation',
    concept: 'An assertion is useful during development. Production quality design decides what fails the pipeline, what is quarantined and what is measured.',
    why: 'Senior engineers make bad-data behavior explicit so downstream consumers know whether a dataset is safe to use.',
    context: 'Required: order_id non-null, amount >= 0. Invalid rows should not enter Silver but should remain diagnosable.',
    task: 'Compare the one-line assertion with an explicit valid/invalid split and reconciliation metric.',
    starter: `assert df['order_id'].notna().all()
assert (df['amount'] >= 0).all()
write_silver(df)`,
    solution: `valid_mask = df['order_id'].notna() & df['amount'].ge(0)
valid = df.loc[valid_mask].copy()
invalid = df.loc[~valid_mask].copy()

metrics = {
    'input_rows': len(df),
    'valid_rows': len(valid),
    'invalid_rows': len(invalid),
}
assert metrics['input_rows'] == metrics['valid_rows'] + metrics['invalid_rows']

write_quarantine(invalid)
write_silver_idempotently(valid)
publish_quality_metrics(metrics)`,
    solutionExplanation: 'The senior version preserves rejected evidence, reconciles input/valid/invalid counts and makes publication behavior explicit. Whether invalid rows should stop the whole pipeline depends on the contract and business criticality.',
    hints: ['Invalid rows should remain explainable.', 'Reconcile counts at a boundary before publishing.'],
    pitfall: 'Silently dropping invalid records creates “clean” tables with unmeasured data loss.',
    diagram: qualityFlow,
  }),
]

if (!tracks.some((track) => track.id === TRACK_ID)) {
  const analyticsIndex = tracks.findIndex((track) => track.id === 'analytics-engineering')
  if (analyticsIndex >= 0) tracks.splice(analyticsIndex + 1, 0, seniorityTrack)
  else tracks.splice(Math.min(6, tracks.length), 0, seniorityTrack)
}

const existingIds = new Set(lessons.map((lesson) => lesson.id))
for (const lesson of additions) {
  if (!existingIds.has(lesson.id)) lessons.push(lesson)
}
