import React from 'react'
import ReactDOM from 'react-dom/client'
import './algorithmExtensions'
import './analyticsEngineeringExtensions'
import './seniorityExtensions'
import './sourceCourseExtensions'
import './storagePerformanceExtensions'
import './pipelineTroubleshootingExtensions'
import './airflowTroubleshootingExtensions'
import './modernLakehouseExtensions'
import './airflow3StreamingExtensions'
import './dataReliabilityExtensions'
import './architectureVisualExtensions'
import App from './App'
import FrontPageGuide from './FrontPageGuide'
import ReferenceLayer from './ReferenceLayer'
import OriginalSourcePreviews from './OriginalSourcePreviews'
import CourseSourcePreviews from './CourseSourcePreviews'
import LearningHubLayer from './LearningHubLayer'
import StorageHubBridge from './StorageHubBridge'
import TroubleshootingHubBridge from './TroubleshootingHubBridge'
import OrganizationLayer from './OrganizationLayer'
import TechnologyVisualLayer from './TechnologyVisualLayer'
import AnimatedConceptLayer from './AnimatedConceptLayer'
import EditorThemeBridge from './EditorThemeBridge'
import VariantSwitchGuard from './VariantSwitchGuard'
import PracticeDiagramLayer from './PracticeDiagramLayer'
import PracticalHubBridge from './PracticalHubBridge'
import PracticalAssetsLayer from './PracticalAssetsLayer'
import SeniorityPracticeLayer from './SeniorityPracticeLayer'
import OfficialSourceLayer from './OfficialSourceLayer'
import { LabErrorBoundary, LabUtilities } from './LabUtilities'
import './styles.css'
import './utilities.css'
import './frontPage.css'
import './focusPriority.css'
import './editorAppearance.css'
import './editorTheme.css'
import './referenceLayer.css'
import './originalSourcePreview.css'
import './learningHub.css'
import './practicalLabs.css'
import './seniorityPractice.css'
import './organization.css'
import './readability.css'
import './officialSources.css'
import './technologyVisuals.css'
import './animatedConcepts.css'
import './animatedConceptExtras.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LabUtilities>
      <LabErrorBoundary>
        <App />
        <OrganizationLayer />
        <TechnologyVisualLayer />
        <AnimatedConceptLayer />
        <EditorThemeBridge />
        <VariantSwitchGuard />
        <FrontPageGuide />
        <ReferenceLayer />
        <OriginalSourcePreviews />
        <CourseSourcePreviews />
        <LearningHubLayer />
        <StorageHubBridge />
        <TroubleshootingHubBridge />
        <PracticalHubBridge />
        <PracticalAssetsLayer />
        <SeniorityPracticeLayer />
        <PracticeDiagramLayer />
        <OfficialSourceLayer />
      </LabErrorBoundary>
    </LabUtilities>
  </React.StrictMode>,
)
