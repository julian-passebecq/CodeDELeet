import { lessons, tracks } from './curriculum.js'

const classicalAlgorithmLessons = [
  {
    id: 'al-sorting', track: 'algorithms', level: 'Beginner', language: 'python', title: 'Sorting + stable keys',
    concept: 'Comparison-based sorting is generally O(n log n). Merge sort and quicksort are the classic mental models; in Python you normally use the built-in stable `sorted` / `.sort()` implementation with an explicit key.',
    why: 'Sorting appears before deduplication, window logic, merge operations, ordered exports, and many distributed shuffles. A data engineer should know the cost and the stable-sort idea even when the engine performs the sort.',
    task: 'Sort events first by event_time and then by event_id. Keep the original list unchanged.',
    starter: 'events = [\n    {"event_id": 3, "event_time": "2026-09-03T10:02:00"},\n    {"event_id": 1, "event_time": "2026-09-03T10:01:00"},\n    {"event_id": 2, "event_time": "2026-09-03T10:01:00"},\n]\n\n# Create ordered_events\n',
    solution: 'ordered_events = sorted(\n    events,\n    key=lambda row: (row["event_time"], row["event_id"]),\n)',
    hints: ['Use `sorted(...)` to return a new list.', 'A tuple key lets you define primary and secondary sort keys.'],
    pitfall: 'Do not translate this into `collect()` + Python sorting for a large Spark dataset. Distributed sorting is an engine operation and usually causes a shuffle.',
  },
  {
    id: 'al-two-pointers', track: 'algorithms', level: 'Intermediate', language: 'python', title: 'Two pointers: merge sorted streams',
    concept: 'The two-pointer pattern advances through two ordered sequences once, giving O(n + m) work instead of repeatedly scanning or re-sorting.',
    why: 'This is the core idea behind the merge phase of merge sort and ordered merge operations. It is useful interview intuition for sorted files, partitions, timestamps, and incremental streams.',
    task: 'Merge the two already-sorted ID lists into one sorted list without calling `sorted()` on the combined result.',
    starter: 'left = [1, 4, 8, 12]\nright = [2, 3, 9, 15]\ni = 0\nj = 0\nmerged = []\n\n# Merge with two pointers\n',
    solution: 'left = [1, 4, 8, 12]\nright = [2, 3, 9, 15]\ni = 0\nj = 0\nmerged = []\n\nwhile i < len(left) and j < len(right):\n    if left[i] <= right[j]:\n        merged.append(left[i])\n        i += 1\n    else:\n        merged.append(right[j])\n        j += 1\n\nmerged.extend(left[i:])\nmerged.extend(right[j:])',
    hints: ['Compare the current item from each list.', 'When one list is exhausted, append the remaining tail of the other.'],
    pitfall: 'Two pointers only gives this simple linear merge because both inputs are already ordered.',
  },
  {
    id: 'al-sliding-window', track: 'algorithms', level: 'Intermediate', language: 'python', title: 'Sliding window',
    concept: 'A sliding window updates a metric as the window moves instead of recomputing the whole window from scratch. Many fixed-window problems become O(n).',
    why: 'Rolling row counts, recent-event thresholds, monitoring windows, and time-series features all use this mental model. SQL and Spark window functions automate much of it, but the underlying algorithm is worth knowing.',
    task: 'Find the maximum total rows processed across any 3 consecutive batches using a rolling sum.',
    starter: 'batch_rows = [120, 80, 200, 150, 90, 210]\nwindow_size = 3\n\n# Compute max_window_total with a sliding sum\n',
    solution: 'batch_rows = [120, 80, 200, 150, 90, 210]\nwindow_size = 3\n\nwindow_total = sum(batch_rows[:window_size])\nmax_window_total = window_total\n\nfor right in range(window_size, len(batch_rows)):\n    window_total += batch_rows[right]\n    window_total -= batch_rows[right - window_size]\n    max_window_total = max(max_window_total, window_total)',
    hints: ['Start with the sum of the first window.', 'For each move, add the new right value and subtract the value leaving on the left.'],
    pitfall: 'Calling `sum()` on every slice works for small inputs but repeats work and hides the sliding-window idea.',
  },
  {
    id: 'al-prefix-sum', track: 'algorithms', level: 'Intermediate', language: 'python', title: 'Prefix sums for fast range totals',
    concept: 'A prefix-sum array stores cumulative totals. After O(n) preprocessing, any contiguous range sum can be answered in O(1).',
    why: 'Prefix-style cumulative state appears in running totals, partition statistics, cumulative metrics, and some incremental-processing problems.',
    task: 'Build prefix so prefix[i] is the total of values before index i. Then compute the sum from start=1 through end=3 inclusive.',
    starter: 'rows = [10, 20, 30, 40, 50]\nstart = 1\nend = 3\nprefix = [0]\n\n# Build prefix and compute range_total\n',
    solution: 'rows = [10, 20, 30, 40, 50]\nstart = 1\nend = 3\nprefix = [0]\n\nfor value in rows:\n    prefix.append(prefix[-1] + value)\n\nrange_total = prefix[end + 1] - prefix[start]',
    hints: ['Start prefix with 0 so indexes stay convenient.', 'Range start..end is cumulative-through-end minus cumulative-before-start.'],
    pitfall: 'Be explicit about whether range endpoints are inclusive; off-by-one errors are the main failure mode.',
  },
  {
    id: 'al-heap-top-k', track: 'algorithms', level: 'Intermediate', language: 'python', title: 'Heap / priority queue: Top K',
    concept: 'A heap keeps the smallest or largest priority element accessible efficiently. A size-k heap can track Top K values without fully sorting every item.',
    why: 'Top customers, largest files, most expensive jobs, newest events, and priority scheduling are common data-engineering patterns. Distributed engines also implement Top K with related ideas.',
    task: 'Use `heapq.nlargest` to return the 3 files with the largest size_mb values.',
    starter: 'import heapq\n\nfiles = [\n    {"name": "a.parquet", "size_mb": 120},\n    {"name": "b.parquet", "size_mb": 900},\n    {"name": "c.parquet", "size_mb": 450},\n    {"name": "d.parquet", "size_mb": 700},\n]\n\n# Create top_3\n',
    solution: 'import heapq\n\nfiles = [\n    {"name": "a.parquet", "size_mb": 120},\n    {"name": "b.parquet", "size_mb": 900},\n    {"name": "c.parquet", "size_mb": 450},\n    {"name": "d.parquet", "size_mb": 700},\n]\n\ntop_3 = heapq.nlargest(3, files, key=lambda row: row["size_mb"])',
    hints: ['Import `heapq`.', '`nlargest(k, iterable, key=...)` returns the k largest items.'],
    pitfall: 'If you only need a small Top K, fully sorting a huge collection can do more work than necessary.',
  },
  {
    id: 'al-graph-traversal', track: 'algorithms', level: 'Intermediate', language: 'python', title: 'BFS graph traversal',
    concept: 'Breadth-first search (BFS) explores a graph level by level using a queue. Depth-first search (DFS) explores one branch deeply using recursion or a stack. Both are O(V + E) for a graph represented by adjacency lists.',
    why: 'Pipeline dependencies, lineage, downstream-impact analysis, and service dependency graphs are graph problems. You should be able to recognize BFS/DFS even if a framework performs the traversal.',
    task: 'Starting from ingest, use BFS to collect every reachable downstream task exactly once.',
    starter: 'from collections import deque\n\ngraph = {\n    "ingest": ["clean", "audit"],\n    "clean": ["model"],\n    "audit": [],\n    "model": ["publish"],\n    "publish": [],\n}\n\n# Traverse from ingest\n',
    solution: 'from collections import deque\n\ngraph = {\n    "ingest": ["clean", "audit"],\n    "clean": ["model"],\n    "audit": [],\n    "model": ["publish"],\n    "publish": [],\n}\n\nqueue = deque(["ingest"])\nvisited = set()\norder = []\n\nwhile queue:\n    node = queue.popleft()\n    if node in visited:\n        continue\n    visited.add(node)\n    order.append(node)\n    queue.extend(graph.get(node, []))',
    hints: ['BFS uses a FIFO queue such as `deque`.', 'Track visited nodes so shared dependencies or cycles do not make you process a node repeatedly.'],
    pitfall: 'A graph is not necessarily a tree: multiple parents and cycles are possible, so a visited set matters.',
  },
  {
    id: 'al-topological-sort', track: 'algorithms', level: 'Expert', language: 'python', title: 'Topological sort for pipeline dependencies',
    concept: 'Topological sorting produces a valid execution order for a directed acyclic graph (DAG). Kahn\'s algorithm repeatedly processes nodes whose in-degree is zero.',
    why: 'Airflow DAGs, dbt models, build systems, orchestration plans, and dependency-aware deployment all rely on this exact graph concept.',
    task: 'Build a valid task order from the dependency pairs. Use in-degree counts and a queue. Set has_cycle when not every task can be ordered.',
    starter: 'from collections import defaultdict, deque\n\ntasks = {"extract", "clean", "model", "publish"}\nedges = [\n    ("extract", "clean"),\n    ("clean", "model"),\n    ("model", "publish"),\n]\n\n# Kahn topological sort\n',
    solution: 'from collections import defaultdict, deque\n\ntasks = {"extract", "clean", "model", "publish"}\nedges = [\n    ("extract", "clean"),\n    ("clean", "model"),\n    ("model", "publish"),\n]\n\nchildren = defaultdict(list)\nindegree = {task: 0 for task in tasks}\n\nfor parent, child in edges:\n    children[parent].append(child)\n    indegree[child] += 1\n\nqueue = deque(task for task in tasks if indegree[task] == 0)\norder = []\n\nwhile queue:\n    task = queue.popleft()\n    order.append(task)\n    for child in children[task]:\n        indegree[child] -= 1\n        if indegree[child] == 0:\n            queue.append(child)\n\nhas_cycle = len(order) != len(tasks)',
    hints: ['In-degree means number of incoming dependencies.', 'Only tasks with in-degree 0 are ready to run.', 'If nodes remain after the queue empties, there is a cycle.'],
    pitfall: 'A topological order exists only for a DAG. Cyclic dependencies must be rejected or redesigned.',
  },
  {
    id: 'al-merge-intervals', track: 'algorithms', level: 'Expert', language: 'python', title: 'Merge overlapping intervals',
    concept: 'Sort intervals by start, then sweep once and merge whenever the next start is inside the current interval. Complexity is O(n log n) because of the initial sort.',
    why: 'Overlapping extraction windows, maintenance windows, reservation ranges, and backfill periods often need to be consolidated before execution.',
    task: 'Merge the overlapping ingestion windows so [[1, 4], [2, 6], [8, 10], [9, 12]] becomes [[1, 6], [8, 12]].',
    starter: 'windows = [[1, 4], [2, 6], [8, 10], [9, 12]]\n\n# Merge overlaps into merged\n',
    solution: 'windows = [[1, 4], [2, 6], [8, 10], [9, 12]]\nwindows.sort(key=lambda interval: interval[0])\nmerged = []\n\nfor start, end in windows:\n    if not merged or start > merged[-1][1]:\n        merged.append([start, end])\n    else:\n        merged[-1][1] = max(merged[-1][1], end)',
    hints: ['Sort by interval start first.', 'Compare each interval with the last merged interval.'],
    pitfall: 'Be clear whether touching intervals such as [1, 2] and [2, 3] should merge; that depends on your business definition of interval boundaries.',
  },
]

const algorithmTrack = tracks.find((track) => track.id === 'algorithms')
if (algorithmTrack) {
  algorithmTrack.name = 'Classical Algorithms for Data Engineering'
  algorithmTrack.description = 'The interview algorithms a data engineer should recognize and apply: hashing, sorting, searching, two pointers, sliding windows, heaps, graph traversal, DAG ordering, intervals, batching, and complexity.'
  algorithmTrack.concepts = [
    'Big-O', 'linear / binary search', 'hash maps', 'sorting', 'two pointers', 'sliding window',
    'prefix sums', 'heap / Top K', 'BFS / DFS', 'topological sort', 'merge intervals', 'batching',
  ]
}

const existingIds = new Set(lessons.map((lesson) => lesson.id))
const additions = classicalAlgorithmLessons.filter((lesson) => !existingIds.has(lesson.id))
if (additions.length) {
  let insertAt = lessons.length
  for (let index = lessons.length - 1; index >= 0; index -= 1) {
    if (lessons[index].track === 'algorithms') {
      insertAt = index + 1
      break
    }
  }
  lessons.splice(insertAt, 0, ...additions)
}

export { classicalAlgorithmLessons }
