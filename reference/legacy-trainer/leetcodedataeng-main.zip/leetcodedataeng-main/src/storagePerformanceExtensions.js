import { lessons, tracks } from './curriculum.js'
import { extraHubs, hubExtensions } from './learningHubContent.js'

const storageTrack = {
  id: 'storage-performance',
  name: 'Data Formats · Storage · Performance',
  short: 'Storage / Perf',
  icon: 'ST',
  description: 'Parquet, Avro, JSON, Delta Lake and DuckDB file queries, plus partitioning, clustering, indexes, pruning, compression and small-file design.',
  concepts: ['Parquet', 'Avro', 'JSON', 'Delta Lake', 'DuckDB', 'columnar vs row', 'partitioning', 'clustering', 'indexes', 'predicate pushdown', 'column pruning', 'compaction'],
}

const storageHub = {
  id: 'storage-performance',
  label: 'Storage · Formats · Performance',
  icon: 'ST',
  subtitle: 'Parquet, Delta, JSON, Avro, DuckDB, partitions, clustering and indexes',
  language: 'python',
  practiceTarget: 'Storage / Perf',
  useFor: ['data engineering interviews', 'lakehouse design', 'query performance', 'Python / PySpark I/O'],
  sections: [
    ['Know the layers', 'FILE FORMATS\nParquet → columnar analytics\nAvro → row-oriented + schema\nJSON → flexible semi-structured interchange\nCSV → simple text interchange\n\nTABLE FORMAT\nDelta Lake → transaction log + table semantics over data files\n\nENGINE\nDuckDB → in-process analytical SQL engine'],
    ['Python · Parquet', "import pandas as pd\n\ndf = pd.read_parquet(\n    'orders.parquet',\n    columns=['order_id', 'customer_id', 'amount'],\n    engine='pyarrow',\n)\n\ndf.to_parquet('clean/orders.parquet', index=False)"],
    ['PyArrow · selective scan', "import pyarrow.dataset as ds\n\ndataset = ds.dataset('lake/orders', format='parquet')\ntable = dataset.to_table(\n    columns=['customer_id', 'amount'],\n    filter=ds.field('event_date') >= '2026-09-01',\n)"],
    ['PySpark · Parquet', "df = (spark.read\n    .parquet('/lake/orders')\n    .select('order_id', 'customer_id', 'amount', 'event_date')\n    .filter(\"event_date >= '2026-09-01'\"))\n\n(df.write.mode('append')\n   .partitionBy('event_date')\n   .parquet('/lake/orders_curated'))"],
    ['DuckDB · files directly', "SELECT customer_id, SUM(amount) AS revenue\nFROM read_parquet('lake/orders/*.parquet')\nWHERE event_date >= DATE '2026-09-01'\nGROUP BY customer_id;"],
    ['Delta Lake', "df.write.format('delta').mode('append').save('/lake/orders_delta')\n\ndelta_df = spark.read.format('delta').load('/lake/orders_delta')\n\n-- Databricks / Delta SQL\nMERGE INTO target t\nUSING updates s\nON t.order_id = s.order_id\nWHEN MATCHED THEN UPDATE SET *\nWHEN NOT MATCHED THEN INSERT *;"],
    ['JSON + Avro', "# JSON lines\njson_df = spark.read.json('/landing/events/*.json')\n\n# Avro (availability/package depends on Spark distribution)\navro_df = spark.read.format('avro').load('/landing/events_avro')"],
    ['Physical design', 'PARTITIONING → coarse directory/segment pruning; choose low/moderate-cardinality filters such as date.\nCLUSTERING → colocate/order similar values inside storage; engine-specific.\nINDEX → separate lookup structure, common in databases; speeds reads but costs storage/write work.\nCOMPACTION → combine small files to reduce metadata/open-file overhead.'],
    ['SQL index example', "CREATE INDEX IX_orders_customer_date\nON dbo.orders(customer_id, order_date)\nINCLUDE (amount, status);\n\n-- Column order should follow real filter/join patterns."],
    ['Performance checklist', '1. Read only required columns\n2. Filter early enough for pushdown/pruning\n3. Partition on common coarse filters, not unique IDs\n4. Avoid thousands of tiny files\n5. Compact / optimize when appropriate\n6. Inspect the query plan before guessing\n7. Validate that clustering/indexes match access patterns'],
  ],
  mentalModels: [
    'Choose the storage layer before choosing an optimization: file format, table format and execution engine are different concerns.',
    'Parquet reduces analytical I/O because columnar readers can skip unneeded columns and often row groups; it does not automatically make every query fast.',
    'Partitioning is coarse pruning, clustering improves locality/data skipping, and an index is a lookup structure. They solve related but different problems.',
    'Distributed performance is often dominated by bytes read, files opened and data shuffled—not Python syntax.',
  ],
  interview: ['Parquet vs Avro vs JSON', 'Parquet vs Delta Lake', 'DuckDB vs Spark', 'partitioning vs clustering vs indexing', 'predicate pushdown + column pruning', 'small-file problem', 'schema evolution', 'compression trade-offs'],
  starter: "import pandas as pd\n\n# Read only the columns needed from Parquet.\ndf = pd.read_parquet(\n    'orders.parquet',\n    columns=[# ...],\n)\n",
}

const storagePatterns = [
  ['Column pruning', 'Read only the columns required by the query. Columnar formats such as Parquet make this especially valuable.'],
  ['Predicate pushdown', 'Push eligible filters into the scan so the reader can skip row groups/files rather than loading everything first.'],
  ['Partition pruning', 'Use partition predicates to avoid scanning unrelated partitions. Partition keys should match common coarse filters.'],
  ['Clustering / data locality', 'Colocate similar values so an engine can skip more data for frequently filtered columns without creating a directory per value.'],
  ['Index lookup', 'Use a database index when point/range access justifies the extra write and storage cost. Composite index column order matters.'],
  ['Compaction', 'Combine many tiny files into fewer appropriately sized files to reduce listing, metadata and file-open overhead.'],
  ['Compression', 'Compression trades CPU for less storage/network I/O. Snappy is common for fast analytics; gzip/zstd can compress more depending on workload.'],
  ['Schema evolution', 'Add/change fields deliberately and understand which readers/table formats can reconcile schemas safely.'],
]

const storageProblems = [
  'A 4 TB event table is queried mostly by event_date and region. Design the partition/clustering strategy and explain what you would not partition by.',
  'A Spark job writes 80,000 tiny Parquet files every day. Explain the performance symptoms and design a safer write/compaction strategy.',
  'Read only customer_id, amount and event_date from a Parquet lake in pandas/PyArrow without loading every column.',
  'Write the same Parquet filter in PySpark and DuckDB, then explain where predicate pushdown can reduce I/O.',
  'Choose between JSON, Avro and Parquet for API interchange, event streaming and analytical history, and justify each choice.',
  'Explain why Delta Lake is not simply another compression/file encoding like Parquet.',
  'Design an index for orders(customer_id, order_date, status, amount) when queries usually filter customer_id + date and return status + amount.',
  'A high-cardinality customer_id was used as a partition column and created millions of directories/files. Redesign the physical layout.',
]

const storageInterviewCards = [
  ['Parquet vs Avro vs JSON', 'Parquet is columnar and optimized for analytical scans; Avro is row-oriented with an explicit schema and is common for serialized records/events; JSON is flexible and human-readable but verbose and weakly typed.', "# analytics\npd.read_parquet('orders.parquet', columns=['id','amount'])\n\n# semi-structured JSON lines\npd.read_json('events.jsonl', lines=True)", 'Which format would you choose for analytics, streaming records and a public API payload?', 'Parquet for analytical history, Avro when compact schema-aware row serialization is valuable, JSON for flexible interoperability/debuggability. The exact choice also depends on the surrounding platform.', 'Pick formats for bronze API payloads, Kafka-style events and a 20 TB analytical fact table.'],
  ['Parquet vs Delta Lake', 'Parquet defines how columnar data is encoded in files. Delta Lake adds table-level transaction metadata and operations such as ACID commits, schema enforcement/evolution and MERGE semantics around data files.', "spark.read.parquet('/lake/raw')\nspark.read.format('delta').load('/lake/table')", 'Why is comparing Delta Lake directly to JSON slightly wrong?', 'Because Delta is a table format/layer, while JSON is a file serialization format. Delta tables commonly use Parquet data files plus a transaction log.', 'Explain how you would convert a mutable curated table from plain Parquet files to a transactional lakehouse table.'],
  ['Python vs PySpark Parquet', 'Use pandas/PyArrow when data comfortably fits a single machine and local execution is simpler. Use Spark when distributed scale, cluster storage and parallel transformations justify its overhead.', "pd.read_parquet('orders.parquet')\n\nspark.read.parquet('/lake/orders')", 'When should you not use Spark?', 'When the data/workload fits comfortably on one machine and the cluster startup, shuffle and operational overhead exceed the benefit. DuckDB/pandas can be simpler and faster for local analytics.', 'Given 2 GB, 200 GB and 20 TB Parquet datasets, discuss a reasonable execution engine for each.'],
  ['Partition vs cluster vs index', 'Partitioning performs coarse pruning, clustering improves physical locality/data skipping inside storage, while an index is a separate lookup structure maintained by a database engine.', "CREATE INDEX IX_orders_customer_date\nON dbo.orders(customer_id, order_date);", 'Would you partition a lake by customer_id if there are 40 million customers?', 'Usually no. Extremely high-cardinality partitioning tends to create huge metadata/file counts. Prefer a coarse key such as date and use clustering/indexing/data-skipping strategies suited to the engine.', 'Design physical storage for orders queried by date, region and customer.'],
  ['Small-file problem', 'Distributed writers can create many tiny files. Even if total bytes are modest, listing/opening/metadata overhead and task scheduling can dominate.', "# before a controlled batch write\nout = df.repartition(64, 'event_date')\nout.write.partitionBy('event_date').parquet(path)", 'Why can 100 GB in 100,000 files be slower than 100 GB in 500 files?', 'Each file has metadata/list/open overhead and often maps to tiny tasks. Fewer appropriately sized files improve scan planning and throughput, though one giant file is also undesirable.', 'A streaming pipeline creates one tiny file every minute per partition. Propose compaction and retention handling.'],
  ['Pushdown and pruning', 'Column pruning removes unused columns; predicate pushdown pushes eligible filters toward the scan; partition pruning skips entire partitions.', "SELECT customer_id, amount\nFROM read_parquet('orders/*.parquet')\nWHERE event_date = DATE '2026-09-03';", 'What is the difference between WHERE filtering and predicate pushdown?', 'WHERE is query semantics. Pushdown is an execution optimization where the filter is evaluated by/lowered into the data source scan so less data is read.', 'Use EXPLAIN/plan inspection to prove whether a filter is applied at the scan.'],
  ['Composite indexes', 'For B-tree-style composite indexes, the leading column(s) strongly affect which predicates can seek efficiently. INCLUDE columns can cover a query without becoming key columns in SQL Server.', "CREATE INDEX IX_sales_customer_date\nON dbo.sales(customer_id, sale_date)\nINCLUDE (amount);", 'Why might an index on (sale_date, customer_id) behave differently from (customer_id, sale_date)?', 'The ordering changes the searchable prefix and sort structure. Choose order from actual equality/range predicates and workload, not column importance.', 'Compare two index orders for equality on customer_id and a date range.'],
  ['Compression trade-offs', 'Compression reduces storage and I/O but consumes CPU. Columnar formats compress well because similar values are stored together.', "df.write.option('compression', 'snappy').parquet(path)", 'Should you always choose the codec with the smallest files?', 'No. Query latency, write cost, CPU budget, compatibility and network/storage cost matter. Fast codecs can outperform denser codecs in interactive pipelines.', 'Benchmark two codecs using file size, write time and scan time rather than storage size alone.'],
]

const storageDiagram = `flowchart LR
  J[JSON / Avro landing] --> S[Transform]
  S --> P[Parquet data files]
  P --> D[Delta table layer]
  D --> E[PySpark / SQL engine]
  P --> U[DuckDB / Python local analytics]`

const physicalDiagram = `flowchart TD
  Q[Query filter] --> A{Coarse common key?}
  A -->|Yes| P[Partition pruning]
  A -->|No / additional filters| C[Clustering / data locality]
  C --> I{Database point/range access?}
  I -->|Yes| X[Index]
  I -->|No| F[Column pruning + pushdown]
  P --> F
  X --> F`

const L = (x) => ({ sourcePack: 'Storage & Performance core', ...x })

export const storageLessons = [
  L({
    id: 'sp-layers', track: 'storage-performance', level: 'Beginner', language: 'plaintext', title: 'File format vs table format vs engine',
    concept: 'Parquet, Avro and JSON encode files/records. Delta Lake adds table-level transaction semantics. DuckDB is a query engine/database.',
    why: 'Interview answers become confusing when these layers are treated as interchangeable products.',
    context: 'Classify: Parquet · Avro · JSON · Delta Lake · DuckDB.',
    task: 'Place each technology in the correct layer and give one primary use case.',
    starter: 'FILE FORMAT:\n- \n\nTABLE FORMAT / TRANSACTION LAYER:\n- \n\nQUERY ENGINE / DATABASE:\n- ',
    solution: 'FILE FORMAT:\n- Parquet — columnar analytical files\n- Avro — row-oriented schema-aware records\n- JSON — flexible semi-structured interchange\n\nTABLE FORMAT / TRANSACTION LAYER:\n- Delta Lake — table metadata/transactions over data files\n\nQUERY ENGINE / DATABASE:\n- DuckDB — in-process analytical SQL engine',
    hints: ['Ask whether the technology describes bytes in a file, table transactions/metadata, or query execution.'],
    pitfall: 'Delta Lake is not just a Parquet replacement codec, and DuckDB is not a file format.', diagram: storageDiagram,
  }),
  L({
    id: 'sp-python-parquet', track: 'storage-performance', level: 'Beginner', language: 'python', title: 'Read Parquet efficiently in pandas',
    concept: 'Parquet readers can project only required columns; avoid loading wide tables when the task uses three fields.',
    why: 'Reducing bytes read is often a larger win than micro-optimizing Python code.',
    context: 'orders.parquet has order_id, customer_id, amount, status, event_date and many unused columns.',
    task: 'Read only order_id, customer_id, amount and event_date with pandas.',
    starter: "import pandas as pd\n\ndf = pd.read_parquet(\n    'orders.parquet',\n    columns=#\n)\n",
    solution: "import pandas as pd\n\ndf = pd.read_parquet(\n    'orders.parquet',\n    columns=['order_id', 'customer_id', 'amount', 'event_date'],\n    engine='pyarrow',\n)\n",
    hints: ['Use the columns argument.', 'pyarrow is a common pandas Parquet engine.'],
    pitfall: 'Reading every column and dropping most of them afterwards wastes I/O and memory.',
  }),
  L({
    id: 'sp-pyarrow-filter', track: 'storage-performance', level: 'Intermediate', language: 'python', title: 'Filter a Parquet dataset with PyArrow',
    concept: 'PyArrow Dataset can express column projection and filters at the dataset scan layer.',
    why: 'This exposes the same pruning/pushdown ideas used by larger analytical engines.',
    context: 'lake/orders contains partitioned Parquet files. Need customer_id + amount for event_date >= 2026-09-01.',
    task: 'Create a dataset scan with two selected columns and an event_date filter.',
    starter: "import pyarrow.dataset as ds\n\ndataset = ds.dataset('lake/orders', format='parquet')\ntable = dataset.to_table(\n    columns=#,\n    filter=#,\n)\n",
    solution: "import pyarrow.dataset as ds\n\ndataset = ds.dataset('lake/orders', format='parquet')\ntable = dataset.to_table(\n    columns=['customer_id', 'amount'],\n    filter=ds.field('event_date') >= '2026-09-01',\n)\n",
    hints: ['Use ds.field for the predicate.', 'Projection belongs in columns.'],
    pitfall: 'A Python filter after table.to_pandas() happens too late to reduce the original scan.',
  }),
  L({
    id: 'sp-spark-parquet', track: 'storage-performance', level: 'Beginner', language: 'python', title: 'Read and write Parquet with PySpark',
    concept: 'Spark reads Parquet natively and can combine projection, filters and partitioned writes in a distributed plan.',
    why: 'This is a standard lake ingestion/curation pattern in Databricks and Fabric Spark.',
    context: 'Read /lake/orders, keep four columns, filter recent dates, then write partitioned by event_date.',
    task: 'Complete the PySpark read/transform/write chain.',
    starter: "df = (spark.read\n    .#('/lake/orders')\n    .select(#)\n    .filter(#))\n\n(df.write.mode('append')\n   .partitionBy(#)\n   .parquet('/lake/orders_curated'))",
    solution: "df = (spark.read\n    .parquet('/lake/orders')\n    .select('order_id', 'customer_id', 'amount', 'event_date')\n    .filter(\"event_date >= '2026-09-01'\"))\n\n(df.write.mode('append')\n   .partitionBy('event_date')\n   .parquet('/lake/orders_curated'))",
    hints: ['spark.read.parquet reads the files.', 'Use a coarse reporting/filter key for the example partition.'],
    pitfall: 'Do not partition by a nearly unique business key such as order_id.',
  }),
  L({
    id: 'sp-duckdb-parquet', track: 'storage-performance', level: 'Beginner', language: 'sql', title: 'Query Parquet directly with DuckDB',
    concept: 'DuckDB can query analytical files directly without loading them into a server database first.',
    why: 'It is useful for local validation, ad-hoc analytics and testing lake transformations.',
    context: 'lake/orders/*.parquet contains customer_id, amount, event_date.',
    task: 'Return revenue by customer for events from 2026-09-01 onward.',
    starter: "SELECT #\nFROM read_parquet('lake/orders/*.parquet')\nWHERE #\nGROUP BY #;",
    solution: "SELECT customer_id, SUM(amount) AS revenue\nFROM read_parquet('lake/orders/*.parquet')\nWHERE event_date >= DATE '2026-09-01'\nGROUP BY customer_id;",
    hints: ['Project only the group key and aggregate.', 'Use a typed DATE literal.'],
    pitfall: 'DuckDB is the engine executing SQL over Parquet; Parquet itself does not execute queries.',
  }),
  L({
    id: 'sp-json-normalize', track: 'storage-performance', level: 'Intermediate', language: 'python', title: 'Normalize nested JSON in Python',
    concept: 'JSON is convenient for semi-structured interchange, but analytics often need explicit normalization and types.',
    why: 'Bronze/API data frequently arrives as nested JSON before being curated to a columnar format.',
    context: 'records contains nested customer objects and line items.',
    task: 'Normalize records to a tabular DataFrame while retaining order_id and nested customer fields.',
    starter: "import pandas as pd\n\ndf = pd.json_normalize(\n    records,\n    # configure nested/meta fields\n)\n",
    solution: "import pandas as pd\n\ndf = pd.json_normalize(\n    records,\n    record_path='items',\n    meta=['order_id', ['customer', 'customer_id'], ['customer', 'country']],\n    errors='ignore',\n)\n",
    hints: ['record_path identifies the repeated child array.', 'meta carries parent fields into each normalized row.'],
    pitfall: 'Flexible JSON does not remove the need for a downstream schema/data contract.',
  }),
  L({
    id: 'sp-avro-spark', track: 'storage-performance', level: 'Intermediate', language: 'python', title: 'Read Avro records with Spark',
    concept: 'Avro stores row-oriented records with a schema and is common in event/serialization workflows.',
    why: 'A data engineer should recognize Avro even if the serving layer ultimately uses Parquet/Delta for analytics.',
    context: 'landing/events_avro contains serialized event records.',
    task: 'Read the Avro dataset and select event_id, event_type and event_ts.',
    starter: "events = (spark.read\n    .format(#)\n    .load('/landing/events_avro')\n    .select(#))",
    solution: "events = (spark.read\n    .format('avro')\n    .load('/landing/events_avro')\n    .select('event_id', 'event_type', 'event_ts'))",
    hints: ['Use format("avro").', 'Some standalone Spark deployments may require the Spark Avro package; managed platforms often include support.'],
    pitfall: 'Do not describe Avro as a columnar warehouse format; it is row-oriented serialization.',
  }),
  L({
    id: 'sp-delta-read-write', track: 'storage-performance', level: 'Intermediate', language: 'python', title: 'Read and write a Delta table with PySpark',
    concept: 'Delta Lake adds transactional table semantics around lake data and metadata.',
    why: 'Mutable curated tables need safer commits, schema controls and update/merge workflows than unmanaged file replacement.',
    context: 'Write curated_orders as Delta, then read it again.',
    task: 'Complete the Delta write and read syntax.',
    starter: "(curated_orders.write\n    .format(#)\n    .mode('overwrite')\n    .save('/lake/curated_orders'))\n\nloaded = spark.read.format(#).load('/lake/curated_orders')",
    solution: "(curated_orders.write\n    .format('delta')\n    .mode('overwrite')\n    .save('/lake/curated_orders'))\n\nloaded = spark.read.format('delta').load('/lake/curated_orders')",
    hints: ['The format name is delta for both read and write.'],
    pitfall: 'Delta table semantics depend on the transaction log as well as the underlying data files.', diagram: storageDiagram,
  }),
  L({
    id: 'sp-partition-design', track: 'storage-performance', level: 'Intermediate', language: 'python', title: 'Choose a safe partition key',
    concept: 'Partitioning is coarse physical organization used to skip unrelated data. Very high-cardinality keys can create pathological file/directory counts.',
    why: 'Bad partition design is a common lake performance and operational failure mode.',
    context: 'orders has 5 years of data, 40 million customer_id values, 25 regions and daily reporting filters.',
    task: 'Choose a partition key and explain why customer_id is a poor default partition key.',
    starter: "# choose one\npartition_key = # 'event_date' | 'region' | 'customer_id'\nreason = #",
    solution: "partition_key = 'event_date'\nreason = 'Daily/date filtering is common and cardinality is bounded. customer_id is too high-cardinality for directory-style partitioning; region may be useful in combination with workload-specific clustering/layout.'",
    hints: ['Prefer common pruning predicates with manageable cardinality.', 'Unique IDs usually make poor directory partitions.'],
    pitfall: 'More partitions are not automatically more parallel or faster.', diagram: physicalDiagram,
  }),
  L({
    id: 'sp-clustering', track: 'storage-performance', level: 'Intermediate', language: 'sql', title: 'Partitioning vs clustering',
    concept: 'Clustering is an engine/table-format-specific way to colocate similar values so scans can skip more data without one partition per value.',
    why: 'Clustering is often useful for secondary high-value filters that are too granular for coarse partitioning.',
    context: 'The table is partitioned by event_date but often filtered by customer_id.',
    task: 'Explain a reasonable layout and state that clustering syntax/behavior is engine-specific.',
    starter: "-- conceptual design\nPARTITION BY #\nCLUSTER BY #",
    solution: "-- conceptual design (exact DDL is engine-specific)\nPARTITION BY event_date\nCLUSTER BY customer_id\n\n-- The partition provides coarse date pruning; clustering improves locality/data skipping for customer filters without creating one partition per customer.",
    hints: ['Use date for coarse pruning.', 'Treat exact clustering syntax as platform-specific.'],
    pitfall: 'Do not confuse a SQL Server clustered index, BigQuery clustering and Delta/Databricks clustering as identical implementations.', diagram: physicalDiagram,
  }),
  L({
    id: 'sp-sql-index', track: 'storage-performance', level: 'Intermediate', language: 'sql', title: 'Design a useful SQL index',
    concept: 'A B-tree-style index provides ordered lookup paths. Composite key order and included columns should match real predicates and projections.',
    why: 'Database indexes are central for OLTP/relational query tuning but are different from lake partitioning.',
    context: 'Most queries filter customer_id = ? and order_date between ? and ?, then return amount and status.',
    task: 'Create a SQL Server nonclustered index that supports the access pattern.',
    starter: "CREATE INDEX #\nON dbo.orders(#)\nINCLUDE (#);",
    solution: "CREATE INDEX IX_orders_customer_date\nON dbo.orders(customer_id, order_date)\nINCLUDE (amount, status);",
    hints: ['Put equality/range search columns in the key.', 'Return-only columns can be INCLUDE columns in SQL Server.'],
    pitfall: 'Every index adds storage and write-maintenance cost; more indexes are not free.',
  }),
  L({
    id: 'sp-small-files', track: 'storage-performance', level: 'Expert', language: 'python', title: 'Fix the small-file problem',
    concept: 'Many tiny analytical files create metadata, listing, file-open and scheduling overhead even when total bytes are modest.',
    why: 'The small-file problem is a frequent Spark/lakehouse performance issue.',
    context: 'A daily batch writes 80,000 tiny files for 100 GB of data.',
    task: 'Reduce output file count deliberately before the batch write and explain why one giant file is also not ideal.',
    starter: "target_partitions = #\nout = df.#(target_partitions, 'event_date')\n(out.write\n   .partitionBy('event_date')\n   .parquet(path))",
    solution: "target_partitions = 128  # choose from measured data size/cluster/workload, not as a universal constant\nout = df.repartition(target_partitions, 'event_date')\n(out.write\n   .mode('append')\n   .partitionBy('event_date')\n   .parquet(path))\n\n# For Delta/lakehouse systems, scheduled compaction/OPTIMIZE can consolidate files after ingestion where supported.",
    hints: ['Control partitions/files using measured workload characteristics.', 'Compaction is often separate from low-latency ingestion.'],
    pitfall: 'Hard-coding 128 as universally correct would be another tuning bug; file sizing is workload/platform dependent.',
  }),
  L({
    id: 'sp-pruning-pushdown', track: 'storage-performance', level: 'Expert', language: 'sql', title: 'Pruning, pushdown and column projection',
    concept: 'Partition pruning skips partitions, predicate pushdown moves eligible filters to the scan, and column pruning avoids reading unused columns.',
    why: 'These optimizations reduce bytes read before expensive joins/aggregations happen.',
    context: 'A Parquet lake has 120 columns and 5 years of date partitions. The report needs 3 columns for one week.',
    task: 'Write a narrow query and explain the three distinct pruning mechanisms an engine may apply.',
    starter: "SELECT #\nFROM read_parquet('lake/events/**/*.parquet')\nWHERE #;",
    solution: "SELECT customer_id, event_date, amount\nFROM read_parquet('lake/events/**/*.parquet')\nWHERE event_date BETWEEN DATE '2026-09-01' AND DATE '2026-09-07';\n\n-- column pruning: only 3 columns\n-- partition pruning: skip unrelated date partitions when partition metadata/layout is available\n-- predicate pushdown: apply eligible event_date filtering at the scan/reader level",
    hints: ['SELECT * defeats column pruning intent.', 'Use EXPLAIN/query plans to verify optimizations rather than assuming them.'],
    pitfall: 'A WHERE clause expresses semantics; it is not proof that a specific source reader actually pushed the predicate down.',
  }),
  L({
    id: 'sp-compression', track: 'storage-performance', level: 'Intermediate', language: 'python', title: 'Choose compression by workload',
    concept: 'Compression trades CPU for lower storage and I/O. Analytical formats compress especially well column-by-column.',
    why: 'The smallest file is not automatically the fastest end-to-end pipeline.',
    context: 'Compare Snappy and a denser codec for a large Parquet dataset.',
    task: 'Write Parquet with Snappy and state the three metrics you would benchmark before changing codecs.',
    starter: "df.write.option('compression', #).parquet(path)\nmetrics = [#, #, #]",
    solution: "df.write.option('compression', 'snappy').parquet(path)\nmetrics = ['file_size', 'write_time', 'scan_time']",
    hints: ['Measure both storage and compute/I/O performance.'],
    pitfall: 'Codec support and optimal choice vary by engine and workload; benchmark instead of assuming.',
  }),
]

if (!tracks.some((track) => track.id === storageTrack.id)) tracks.push(storageTrack)
const existingIds = new Set(lessons.map((lesson) => lesson.id))
for (const lesson of storageLessons) if (!existingIds.has(lesson.id)) lessons.push(lesson)

if (!extraHubs.some((hub) => hub.id === storageHub.id)) extraHubs.splice(3, 0, storageHub)
hubExtensions['storage-performance'] = {
  algorithms: storagePatterns,
  problems: storageProblems,
  interviewCards: storageInterviewCards,
}

const deCards = hubExtensions['de-interview']?.interviewCards
if (Array.isArray(deCards) && !deCards.some((card) => card[0] === 'Partitioning vs clustering vs indexing')) {
  deCards.push(storageInterviewCards[3])
  deCards.push(storageInterviewCards[4])
}
