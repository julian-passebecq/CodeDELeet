import { useEffect } from 'react'
import { loader } from '@monaco-editor/react'

const themeFor = (appearance) => appearance === 'black' ? 'de-black' : appearance === 'light' ? 'de-light' : 'de-gray'

function defineThemes(monaco) {
  monaco.editor.defineTheme('de-gray', {
    base: 'vs', inherit: true,
    rules: [
      { token: 'comment', foreground: '4F6B57', fontStyle: 'italic' },
      { token: 'keyword', foreground: '005EA8', fontStyle: 'bold' },
      { token: 'number', foreground: '7B3F00' },
      { token: 'string', foreground: '8C2F39' },
      { token: 'operator', foreground: '334155' },
      { token: 'predefined', foreground: '6D28D9' },
      { token: 'type', foreground: '006B65' },
      { token: 'type.identifier', foreground: '8C2F39' },
      { token: 'variable', foreground: '7C4A03' },
      { token: 'identifier', foreground: '1F2937' },
    ],
    colors: {
      'editor.background': '#E1E4E8', 'editor.foreground': '#1F2937', 'editorLineNumber.foreground': '#667085',
      'editorLineNumber.activeForeground': '#253247', 'editorCursor.foreground': '#111827', 'editor.selectionBackground': '#BFD7EE',
      'editor.inactiveSelectionBackground': '#CCD9E6', 'editor.lineHighlightBackground': '#D7DCE2', 'editorIndentGuide.background1': '#C4CBD4',
      'editorIndentGuide.activeBackground1': '#8C98A7', 'editorWhitespace.foreground': '#B4BBC4', 'editorGutter.background': '#D8DDE3',
    },
  })
  monaco.editor.defineTheme('de-black', {
    base: 'vs-dark', inherit: true,
    rules: [
      { token: 'comment', foreground: '8FBF9B', fontStyle: 'italic' },
      { token: 'keyword', foreground: '7DD3FC', fontStyle: 'bold' },
      { token: 'number', foreground: 'FDBA74' },
      { token: 'string', foreground: 'FCA5A5' },
      { token: 'operator', foreground: 'E5E7EB' },
      { token: 'predefined', foreground: 'C4B5FD' },
      { token: 'type', foreground: '67E8F9' },
      { token: 'type.identifier', foreground: 'FCA5A5' },
      { token: 'variable', foreground: 'FDE68A' },
      { token: 'identifier', foreground: 'F3F4F6' },
    ],
    colors: {
      'editor.background': '#0B0D10', 'editor.foreground': '#F3F4F6', 'editorLineNumber.foreground': '#818A96',
      'editorLineNumber.activeForeground': '#FFFFFF', 'editorCursor.foreground': '#FFFFFF', 'editor.selectionBackground': '#244967',
      'editor.inactiveSelectionBackground': '#1C3549', 'editor.lineHighlightBackground': '#121820', 'editorIndentGuide.background1': '#252D36',
      'editorIndentGuide.activeBackground1': '#566474', 'editorWhitespace.foreground': '#303A45', 'editorGutter.background': '#07090B',
    },
  })
  monaco.editor.defineTheme('de-light', {
    base: 'vs', inherit: true,
    rules: [
      { token: 'comment', foreground: '3F7A45', fontStyle: 'italic' },
      { token: 'keyword', foreground: '005A9C', fontStyle: 'bold' },
      { token: 'number', foreground: '8B3A00' },
      { token: 'string', foreground: 'A31515' },
      { token: 'operator', foreground: '253041' },
      { token: 'predefined', foreground: '6B21A8' },
      { token: 'type', foreground: '00695C' },
      { token: 'type.identifier', foreground: 'A31515' },
      { token: 'variable', foreground: '795000' },
      { token: 'identifier', foreground: '111827' },
    ],
    colors: {
      'editor.background': '#FFFFFF', 'editor.foreground': '#111827', 'editorLineNumber.foreground': '#6B7280',
      'editorLineNumber.activeForeground': '#111827', 'editorCursor.foreground': '#111827', 'editor.selectionBackground': '#C9E2F5',
      'editor.inactiveSelectionBackground': '#DCEAF5', 'editor.lineHighlightBackground': '#F2F5F8', 'editorIndentGuide.background1': '#D8DEE6',
      'editorIndentGuide.activeBackground1': '#8C98A7', 'editorWhitespace.foreground': '#D0D5DD', 'editorGutter.background': '#F8FAFC',
    },
  })
}

export default function EditorThemeBridge() {
  useEffect(() => {
    let disposed = false
    let currentMonaco = null
    let frame = 0
    let settleTimer = 0

    const currentAppearance = () => document.documentElement.dataset.editorAppearance ?? 'gray'
    const applyNow = (appearance = currentAppearance()) => {
      if (!currentMonaco || disposed) return
      defineThemes(currentMonaco)
      currentMonaco.editor.setTheme(themeFor(appearance))
    }
    const queueApply = (appearance = currentAppearance()) => {
      window.cancelAnimationFrame(frame)
      window.clearTimeout(settleTimer)
      frame = window.requestAnimationFrame(() => {
        applyNow(appearance)
        settleTimer = window.setTimeout(() => applyNow(currentAppearance()), 0)
      })
    }
    const init = (appearance = currentAppearance()) => {
      loader.init().then((monaco) => {
        if (disposed) return
        currentMonaco = monaco
        applyNow(appearance)
        queueApply(appearance)
      }).catch(() => {
        // Monaco's own error surface remains authoritative; avoid creating a
        // second error path just for theme decoration.
      })
    }
    init()

    const onTheme = (event) => {
      const appearance = event.detail ?? currentAppearance()
      if (currentMonaco) {
        applyNow(appearance)
        queueApply(appearance)
      } else init(appearance)
    }
    window.addEventListener('de-editor-appearance', onTheme)

    /* Some Editor instances still receive a static Monaco theme prop. Re-apply
       the trainer palette after React/Monaco finishes mounting or rerendering. */
    const observer = new MutationObserver((records) => {
      if (!currentMonaco) return
      const mountedEditor = records.some((record) => [...record.addedNodes].some((node) =>
        node instanceof Element && (node.matches?.('.monaco-editor') || node.querySelector?.('.monaco-editor')),
      ))
      if (mountedEditor) queueApply()
    })
    observer.observe(document.body, { childList: true, subtree: true })

    return () => {
      disposed = true
      window.cancelAnimationFrame(frame)
      window.clearTimeout(settleTimer)
      observer.disconnect()
      window.removeEventListener('de-editor-appearance', onTheme)
    }
  }, [])
  return null
}
