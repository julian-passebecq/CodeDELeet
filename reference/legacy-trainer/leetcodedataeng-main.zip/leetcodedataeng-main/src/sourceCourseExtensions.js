import { lessons, tracks } from './curriculum.js'

const sourceSpark = (x) => ({ sourcePack: 'pyspark-tutorial-master — uploaded course', ...x })
const sourceNoSql = (x) => ({ sourcePack: 'lyon2-nosql-main — uploaded course', ...x })
const sourceK8s = (x) => ({ sourcePack: 'Advanced Deployment with Kubernetes — uploaded tutorial', ...x })
const sourceGenAi = (x) => ({ sourcePack: 'Generative AI — uploaded tutorial', ...x })

const rddDiagram = `flowchart LR
  D[Driver] --> R[RDD]
  R --> P1[Partition 1]
  R --> P2[Partition 2]
  R --> P3[Partition 3]
  P1 --> T[Transformations]
  P2 --> T
  P3 --> T
  T --> A[Action / result]`

const sparkSqlDiagram = `flowchart LR
  F[CSV / Parquet] --> DF[DataFrame]
  DF --> LP[Logical plan]
  LP --> C[Catalyst optimizer]
  C --> PP[Physical plan]
  PP --> X[Executors / partitions]`

const k8sDiagram = `flowchart LR
  IMG[Container image] --> D[Deployment]
  D --> P1[Pod]
  D --> P2[Pod]
  D --> P3[Pod]
  S[Service] --> P1
  S --> P2
  S --> P3
  U[Client] --> S`

const ragDiagram = `flowchart LR
  DOC[Documents] --> CH[Chunk]
  CH --> EMB[Embeddings]
  EMB --> V[(Vector store)]
  Q[Question] --> QE[Query embedding]
  QE --> V
  V --> CTX[Retrieved context]
  CTX --> LLM[LLM]
  Q --> LLM
  LLM --> A[Grounded answer]`

const nosqlDiagram = `flowchart LR
  APP[Application] --> R[(Redis cache)]
  APP --> M[(MongoDB documents)]
  R -->|cache miss| M
  M --> APP`

const pysparkLessons = [
  sourceSpark({
    id: 'src-sp-rdd-parallelize', track: 'pyspark', level: 'Beginner', language: 'python', title: 'Source lab: create an RDD with parallelize',
    concept: 'An RDD is a partitioned distributed collection. Modern PySpark usually prefers DataFrames, but RDDs explain Spark’s execution model.',
    why: 'Know the abstraction, then know why DataFrame APIs are generally preferred for structured data.',
    context: 'Uploaded course · 2-novice/1-Initiation-RDD.ipynb · create values from 1..n with SparkContext.parallelize.',
    task: 'Return an RDD containing integers from 1 through n.',
    starter: `def rdd_from_list(sc, n):
    # return an RDD with 1..n
    pass`,
    solution: `def rdd_from_list(sc, n):
    return sc.parallelize(range(1, n + 1))`,
    hints: ['Build a Python range first.', 'SparkContext.parallelize distributes a local collection.'],
    pitfall: 'Do not collect large RDDs back to the driver just to inspect them.', diagram: rddDiagram,
  }),
  sourceSpark({
    id: 'src-sp-textfile', track: 'pyspark', level: 'Beginner', language: 'python', title: 'Source lab: load a text file as an RDD',
    concept: 'textFile creates an RDD of lines and lets Spark distribute downstream transformations.',
    why: 'This is the low-level version of distributed file ingestion before DataFrame readers add schema and optimization.',
    context: 'Uploaded FL_insurance_sample.csv. The site includes a small source-derived sample at /labs/pyspark/FL_insurance_sample.csv.',
    task: 'Load the supplied path with SparkContext and return the RDD unchanged.',
    starter: `def load_file_to_rdd(sc, path):
    # load the file as lines
    pass`,
    solution: `def load_file_to_rdd(sc, path):
    return sc.textFile(path)`,
    hints: ['Use sc.textFile(path).'],
    pitfall: 'RDD text ingestion does not infer a tabular schema.',
  }),
  sourceSpark({
    id: 'src-sp-map-filter', track: 'pyspark', level: 'Intermediate', language: 'python', title: 'Source lab: map + filter without collecting',
    concept: 'Transformations such as map and filter are lazy; they describe distributed work until an action or write executes it.',
    why: 'Interviewers expect you to distinguish transformations, actions and driver-side materialization.',
    context: 'Use an RDD of CSV lines after removing the header. Keep Residential rows and return policy IDs.',
    task: 'Filter Residential records and map each remaining row to its policyID.',
    starter: `residential_ids = (
    rows
    # filter Residential rows
    # map to policyID
)`,
    solution: `residential_ids = (
    rows
    .filter(lambda line: ',Residential,' in line)
    .map(lambda line: line.split(',')[0])
)`,
    hints: ['Keep transformations on the RDD.', 'policyID is the first CSV field.'],
    pitfall: 'Parsing production CSV with split(",") is fragile; this drill mirrors the RDD course, while DataFrame csv readers are preferable for structured files.',
  }),
  sourceSpark({
    id: 'src-sp-read-dataframe', track: 'pyspark', level: 'Beginner', language: 'python', title: 'Source lab: read insurance CSV as a DataFrame',
    concept: 'DataFrames add named columns, schema information and Catalyst optimization on top of distributed Spark execution.',
    why: 'For structured data engineering, DataFrame/Spark SQL APIs are the normal default rather than raw RDD parsing.',
    context: 'Use /labs/pyspark/FL_insurance_sample.csv. Columns include policyID, county, tiv_2011, tiv_2012, line and construction.',
    task: 'Read the CSV with a header and inferred types, then select the six business columns.',
    starter: `df = (
    spark.read
    # format/options
    # load path
)
result = df.select(# columns)`,
    solution: `df = (
    spark.read
    .option('header', True)
    .option('inferSchema', True)
    .csv('/labs/pyspark/FL_insurance_sample.csv')
)
result = df.select('policyID', 'county', 'tiv_2011', 'tiv_2012', 'line', 'construction')`,
    hints: ['Set header=True.', 'Use inferSchema for this learning sample; explicit schemas are preferable in stable production pipelines.'],
    pitfall: 'Schema inference adds an extra pass and can drift when source samples change.', diagram: sparkSqlDiagram,
  }),
  sourceSpark({
    id: 'src-sp-aggregate-insurance', track: 'pyspark', level: 'Intermediate', language: 'python', title: 'Source lab: aggregate insurance value by construction',
    concept: 'DataFrame groupBy + agg is a wide transformation: data with the same key must be brought together.',
    why: 'The syntax is easy; the senior question is where the shuffle happens and how many groups/rows move.',
    context: 'FL insurance sample · compare total tiv_2012 by construction for Residential policies.',
    task: 'Filter Residential rows, group by construction and sum tiv_2012 as total_tiv_2012.',
    starter: `from pyspark.sql import functions as F

result = (
    df
    # filter
    # group
    # aggregate
)`,
    solution: `from pyspark.sql import functions as F

result = (
    df
    .filter(F.col('line') == 'Residential')
    .groupBy('construction')
    .agg(F.sum('tiv_2012').alias('total_tiv_2012'))
)`,
    hints: ['Filter before groupBy.', 'Alias the aggregate.'],
    pitfall: 'groupBy causes a shuffle; do not add unnecessary repartitions around it.', diagram: sparkSqlDiagram,
  }),
  sourceSpark({
    id: 'src-sp-sql-temp-view', track: 'pyspark', level: 'Intermediate', language: 'sql', title: 'Source lab: query a Spark DataFrame with SQL',
    concept: 'Spark SQL and the DataFrame API build plans for the same execution engine; choose the expression style that makes the transformation clearest.',
    why: 'Data engineers should move comfortably between PySpark DataFrame syntax and SQL.',
    context: 'Assume the insurance DataFrame is registered as insurance. Return the 5 highest tiv_2012 policies.',
    task: 'Write Spark SQL selecting policyID, county, tiv_2012 and ordering descending.',
    starter: `SELECT
  # columns
FROM insurance
# order and limit`,
    solution: `SELECT
  policyID,
  county,
  tiv_2012
FROM insurance
ORDER BY tiv_2012 DESC
LIMIT 5`,
    hints: ['ORDER BY DESC then LIMIT 5.'],
    pitfall: 'Global ORDER BY requires distributed sorting; avoid it when you do not actually need a total order.', diagram: sparkSqlDiagram,
  }),
  sourceSpark({
    id: 'src-sp-topandas-boundary', track: 'pyspark', level: 'Intermediate', language: 'python', title: 'Source lab: keep toPandas at a safe boundary',
    concept: 'toPandas collects the entire Spark DataFrame into driver memory.',
    why: 'The uploaded tutorial explicitly warns to use toPandas only for small DataFrames; this is a common real-world failure mode.',
    context: 'You need a small 20-row summary for plotting, not the full fact table.',
    task: 'Aggregate in Spark, limit the result and only then convert the small summary to pandas.',
    starter: `pdf = large_fact.toPandas()
summary = pdf.groupby('county')['amount'].sum()`,
    solution: `from pyspark.sql import functions as F

summary = (
    large_fact
    .groupBy('county')
    .agg(F.sum('amount').alias('revenue'))
    .orderBy(F.col('revenue').desc())
    .limit(20)
)
pdf = summary.toPandas()`,
    hints: ['Reduce rows and columns before crossing to the driver.', 'toPandas is a driver-memory boundary.'],
    pitfall: 'A full toPandas can crash the driver even when the Spark cluster has plenty of aggregate memory.',
  }),
  sourceSpark({
    id: 'src-sp-titanic-clean', track: 'pyspark', level: 'Intermediate', language: 'python', title: 'Source lab: clean nulls and drop unused columns',
    concept: 'The advanced uploaded notebook cleans Titanic data before feature engineering: drop unused columns and treat missing values deliberately.',
    why: 'The mechanics transfer directly to production feature/staging pipelines even when the ML example itself is optional.',
    context: 'Use /labs/pyspark/titanic_sample.csv. Drop Cabin, Ticket, PassengerId. Fill numeric Age and categorical Embarked deliberately.',
    task: 'Return a cleaned DataFrame without the three unused columns and without null Age/Embarked values.',
    starter: `def replace_na(df):
    # drop unused columns
    # fill Age and Embarked
    return df`,
    solution: `def replace_na(df):
    age_mean = df.selectExpr('avg(Age) AS age_mean').first()['age_mean']
    return (
        df
        .drop('Cabin', 'Ticket', 'PassengerId')
        .na.fill({'Age': age_mean, 'Embarked': 'S'})
    )`,
    hints: ['Compute the Age statistic with Spark first.', 'Use na.fill with a dict for column-specific values.'],
    pitfall: 'Imputation values should come from a defined training/data contract; hardcoding them without provenance can leak or drift.',
  }),
]

const noSqlTrack = {
  id: 'nosql-optional', name: 'Optional — NoSQL (Redis + MongoDB)', short: 'NoSQL · Optional', icon: 'NS',
  description: 'Nice-to-have database breadth from the uploaded Redis/Mongo/OrientDB course. Keep after core SQL/modeling skills.',
  concepts: ['Redis strings/lists/sets/hashes', 'query cache', 'Mongo documents', 'filters', 'updates', 'embedded arrays', 'graph/document trade-offs'],
}

const noSqlLessons = [
  sourceNoSql({
    id: 'opt-redis-cache', track: 'nosql-optional', level: 'Beginner', language: 'python', title: 'Optional NoSQL: Redis query cache',
    concept: 'Redis is an in-memory key/value system commonly used for low-latency caching and ephemeral state.',
    why: 'Useful breadth, but not a replacement for core relational modeling skills.',
    context: 'Uploaded Redis notebook models a REST query cache identified by HTTP method + URL.',
    task: 'Cache a JSON response for GET /customers/42 with a 60-second TTL.',
    starter: `import redis, json
r = redis.Redis(host='localhost', port=6379)
key = # method + url
# store response with expiry`,
    solution: `import redis, json
r = redis.Redis(host='localhost', port=6379)
key = 'GET:/customers/42'
r.setex(key, 60, json.dumps({'customer_id': 42, 'status': 'active'}))`,
    hints: ['Use setex for value + expiry.'],
    pitfall: 'A cache needs an invalidation/TTL strategy; stale cached data is a correctness problem.', diagram: nosqlDiagram,
  }),
  sourceNoSql({
    id: 'opt-mongo-find', track: 'nosql-optional', level: 'Beginner', language: 'python', title: 'Optional NoSQL: MongoDB document query',
    concept: 'MongoDB stores JSON-like documents and queries fields using filter documents.',
    why: 'Recognize when nested/document-shaped data is natural and when relational constraints would be more valuable.',
    context: 'Uploaded MovieLens source contains movies with _id, title and genres. Site sample: /labs/nosql/movielens_movies_sample.json.',
    task: 'Find Comedy movies and return only title + genres.',
    starter: `movies = db.movies
cursor = movies.find(
    # filter,
    # projection
)`,
    solution: `movies = db.movies
cursor = movies.find(
    {'genres': {'$regex': 'Comedy'}},
    {'_id': 0, 'title': 1, 'genres': 1},
)`,
    hints: ['Use a filter document and a projection document.'],
    pitfall: 'Regex scans can become expensive; indexes and a better genre representation matter at scale.',
  }),
  sourceNoSql({
    id: 'opt-mongo-update', track: 'nosql-optional', level: 'Intermediate', language: 'python', title: 'Optional NoSQL: update one MongoDB document',
    concept: 'Document updates should target a stable identifier and use atomic update operators rather than rewriting the whole object unnecessarily.',
    why: 'The same idempotency and key-design concerns apply outside SQL.',
    context: 'Update movie _id=1 to add a reviewed flag without replacing its title/genres.',
    task: 'Use update_one with $set.',
    starter: `result = db.movies.update_one(
    # filter,
    # update
)`,
    solution: `result = db.movies.update_one(
    {'_id': 1},
    {'$set': {'reviewed': True}},
)`,
    hints: ['Use $set.'],
    pitfall: 'Replacing a whole document can accidentally remove fields you did not include.',
  }),
]

const genAiTrack = {
  id: 'genai-optional', name: 'Optional — GenAI for Data Engineers', short: 'GenAI · Optional', icon: 'AI',
  description: 'Optional breadth: embeddings, RAG, local LLM APIs and tool/agent architecture. Useful, but secondary to DE fundamentals.',
  concepts: ['embeddings', 'cosine similarity', 'RAG', 'vector store', 'Ollama/local API', 'MCP/tools', 'structured output'],
}

const genAiLessons = [
  sourceGenAi({
    id: 'opt-ai-embeddings', track: 'genai-optional', level: 'Beginner', language: 'python', title: 'Optional GenAI: embeddings + cosine similarity',
    concept: 'An embedding maps text to a vector so semantic relatedness can be approximated with vector similarity.',
    why: 'This is enough foundation to understand vector search without turning the DE trainer into an AI course.',
    context: 'Uploaded GenAI tutorial uses SentenceTransformers and cosine similarity between sentence embeddings.',
    task: 'Encode three sentences and compute similarity between the first two.',
    starter: `from sentence_transformers import SentenceTransformer, util
model = SentenceTransformer('all-MiniLM-L6-v2')
sentences = ['red cat', 'my red cat', 'warehouse partitioning']
# encode and compare`,
    solution: `from sentence_transformers import SentenceTransformer, util
model = SentenceTransformer('all-MiniLM-L6-v2')
sentences = ['red cat', 'my red cat', 'warehouse partitioning']
emb = model.encode(sentences)
score = util.cos_sim(emb[0], emb[1]).item()`,
    hints: ['model.encode returns vectors.', 'util.cos_sim compares vectors.'],
    pitfall: 'Embedding similarity is not a factuality guarantee and depends heavily on model/domain.',
  }),
  sourceGenAi({
    id: 'opt-ai-rag', track: 'genai-optional', level: 'Intermediate', language: 'python', title: 'Optional GenAI: understand the RAG pipeline',
    concept: 'RAG separates indexing from query-time retrieval: load → chunk → embed → store, then retrieve relevant context for generation.',
    why: 'For a data engineer, the useful angle is the data pipeline: ingestion, chunk metadata, index refresh, lineage and quality.',
    context: 'Uploaded tutorial uses local embeddings, Ollama and ChromaDB/LlamaIndex.',
    task: 'Complete the high-level query flow by retrieving context before calling the LLM.',
    starter: `query = 'What changed in the source document?'
query_vector = embed(query)
# retrieve relevant chunks
# call LLM with query + context`,
    solution: `query = 'What changed in the source document?'
query_vector = embed(query)
chunks = vector_store.search(query_vector, top_k=5)
context = '\n\n'.join(chunk.text for chunk in chunks)
answer = llm.generate(question=query, context=context)`,
    hints: ['Retrieval happens before generation.', 'Preserve document metadata with chunks.'],
    pitfall: 'A RAG system can still answer badly when retrieval is poor; evaluate retrieval separately from generation.', diagram: ragDiagram,
  }),
  sourceGenAi({
    id: 'opt-ai-local-api', track: 'genai-optional', level: 'Intermediate', language: 'python', title: 'Optional GenAI: local OpenAI-compatible endpoint',
    concept: 'Local runtimes can expose an OpenAI-compatible API, letting application code swap providers with minimal interface changes.',
    why: 'Useful for privacy/testing, but operational concerns like model memory, latency and versioning remain.',
    context: 'Uploaded tutorial demonstrates LMStudio/Ollama-style local endpoints.',
    task: 'Create a client pointing at a local endpoint and send one chat request.',
    starter: `from openai import OpenAI
client = OpenAI(
    base_url=#,
    api_key='local',
)
# request`,
    solution: `from openai import OpenAI
client = OpenAI(
    base_url='http://localhost:11434/v1',
    api_key='ollama',
)
response = client.chat.completions.create(
    model='mistral',
    messages=[{'role': 'user', 'content': 'Summarize this data-quality incident.'}],
)`,
    hints: ['Point base_url at the local compatible server.'],
    pitfall: 'API compatibility does not mean model capability, context limits or structured-output behavior are identical.',
  }),
  sourceGenAi({
    id: 'opt-ai-mcp', track: 'genai-optional', level: 'Expert', language: 'python', title: 'Optional GenAI: MCP tool-server architecture',
    concept: 'A tool protocol separates an agent from executable capabilities, similar to separating orchestration from services.',
    why: 'Nice-to-have architecture literacy after core API/data pipeline concepts.',
    context: 'Uploaded tutorial uses a FastMCP server plus an agent, then optionally deploys both behind Kubernetes Services.',
    task: 'Expose a typed add(a,b) tool from a small MCP server.',
    starter: `from fastmcp import FastMCP
mcp = FastMCP('Math Tools')

# define a tool`,
    solution: `from fastmcp import FastMCP
mcp = FastMCP('Math Tools')

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b`,
    hints: ['Decorate a typed Python function as a tool.'],
    pitfall: 'Tool access expands the security boundary; validate permissions, inputs and side effects.', diagram: ragDiagram,
  }),
]

const k8sLessons = [
  sourceK8s({
    id: 'opt-k8s-deploy-service', track: 'kubernetes', level: 'Beginner', language: 'yaml', title: 'Optional K8s: Deployment → Pods → Service',
    concept: 'A Deployment manages replica lifecycle; a Service gives a stable network endpoint over matching Pods.',
    why: 'This is the minimum Kubernetes mental model most data engineers need before deeper cluster topics.',
    context: 'Uploaded tutorial: Docker image api:0.1.0, three replicas, Service selects app=api.',
    task: 'Complete a Deployment with 3 replicas and a ClusterIP Service selecting app=api.',
    starter: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
spec:
  replicas: #
  selector:
    matchLabels: {app: api}
  template:
    metadata:
      labels: {app: api}
    spec:
      containers:
        - name: api
          image: api:0.1.0
---
apiVersion: v1
kind: Service
metadata:
  name: api-svc
spec:
  selector: #
  ports:
    - port: 8000`,
    solution: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
spec:
  replicas: 3
  selector:
    matchLabels: {app: api}
  template:
    metadata:
      labels: {app: api}
    spec:
      containers:
        - name: api
          image: api:0.1.0
---
apiVersion: v1
kind: Service
metadata:
  name: api-svc
spec:
  selector: {app: api}
  ports:
    - port: 8000
      targetPort: 8000`,
    hints: ['Deployment selectors must match template labels.', 'Service selectors must match Pod labels.'],
    pitfall: 'A Service with the wrong selector exists but routes to zero endpoints.', diagram: k8sDiagram,
  }),
  sourceK8s({
    id: 'opt-k8s-rollout', track: 'kubernetes', level: 'Intermediate', language: 'shell', title: 'Optional K8s: rolling update + rollback',
    concept: 'Deployments support controlled rollout and rollback of versioned container images.',
    why: 'Useful operational literacy when a data API or orchestration service is containerized.',
    context: 'Upgrade mlops-server from 0.1.0 to 0.2.0, watch rollout, then know the rollback command.',
    task: 'Write the three kubectl commands: set image, rollout status, rollout undo.',
    starter: `kubectl set image #
kubectl rollout status #
kubectl rollout undo #`,
    solution: `kubectl set image deployment/mlops-server mlops-server=mlops-server:0.2.0
kubectl rollout status deployment/mlops-server
kubectl rollout undo deployment/mlops-server`,
    hints: ['All commands target deployment/mlops-server.'],
    pitfall: 'Mutable image tags make rollback/debugging harder; immutable version/digest references are safer.', diagram: k8sDiagram,
  }),
  sourceK8s({
    id: 'opt-k8s-config', track: 'kubernetes', level: 'Intermediate', language: 'yaml', title: 'Optional K8s: ConfigMap vs Secret',
    concept: 'Configuration belongs outside the image; non-secret settings and credentials have different handling requirements.',
    why: 'The important DE lesson is separation of code/config/secrets, not memorizing every Kubernetes resource.',
    context: 'Inject API_NAME from a ConfigMap and API_KEY from a Secret into a container.',
    task: 'Complete the two env valueFrom references.',
    starter: `env:
  - name: API_NAME
    valueFrom:
      # config map reference
  - name: API_KEY
    valueFrom:
      # secret reference`,
    solution: `env:
  - name: API_NAME
    valueFrom:
      configMapKeyRef:
        name: api-config
        key: API_NAME
  - name: API_KEY
    valueFrom:
      secretKeyRef:
        name: api-secrets
        key: api-key`,
    hints: ['ConfigMapKeyRef and SecretKeyRef are separate references.'],
    pitfall: 'A Kubernetes Secret is not magically safe merely because it is called Secret; use proper RBAC/encryption/external secret management in real environments.',
  }),
]

function addTrack(track) {
  if (!tracks.some((item) => item.id === track.id)) tracks.push(track)
}

addTrack(noSqlTrack)
addTrack(genAiTrack)

for (const id of ['docker', 'kubernetes', 'mlops-practical']) {
  const track = tracks.find((item) => item.id === id)
  if (!track) continue
  if (!track.name.startsWith('Optional —')) track.name = `Optional — ${track.name.replace(/^Optional — /, '')}`
  if (!track.short.includes('Optional')) track.short = `${track.short} · Optional`
}

const existing = new Set(lessons.map((lesson) => lesson.id))
for (const lesson of [...pysparkLessons, ...noSqlLessons, ...genAiLessons, ...k8sLessons]) {
  if (!existing.has(lesson.id)) {
    lessons.push(lesson)
    existing.add(lesson.id)
  }
}
