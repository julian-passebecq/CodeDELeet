import { useEffect } from 'react'
import { lessons } from './curriculum'

const HUB_ID = 'pipeline-troubleshooting'
const HUB_LABEL = 'Pipeline Troubleshooting · Optimization'
const TRACK = 'pipeline-troubleshooting'

function items() {
  return lessons.filter((item) => item.track === TRACK)
}

function openHub() {
  window.dispatchEvent(new CustomEvent('de-open-learning-hub', { detail: HUB_ID }))
}

function openPractice() {
  const button = [...document.querySelectorAll('.track-nav button')]
    .find((node) => node.textContent?.replace(/\s+/g, ' ').includes('Troubleshoot'))
  if (button instanceof HTMLElement) button.click()
}

function ensureNavButton() {
  const nav = document.querySelector('.learning-extra-nav')
  if (!nav || nav.querySelector('[data-troubleshooting-hub-nav]')) return

  const button = document.createElement('button')
  button.type = 'button'
  button.dataset.troubleshootingHubNav = 'true'
  button.innerHTML = '<span>TR</span><div><strong>Pipeline Troubleshooting</strong><small>ETL errors, recovery, optimization, Airflow</small></div><span aria-hidden="true">›</span>'
  button.addEventListener('click', openHub)

  const storage = nav.querySelector('[data-storage-hub-nav]')
  const de = [...nav.querySelectorAll('button')].find((item) => item.textContent?.includes('Data Engineering'))
  if (storage?.nextSibling) nav.insertBefore(button, storage.nextSibling)
  else if (de) nav.insertBefore(button, de)
  else nav.appendChild(button)
}

function wireBreadcrumb() {
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  if (!title || !items().some((item) => item.title === title)) return

  const crumb = document.querySelector('.ide-breadcrumb span')
  if (!crumb) return
  if (crumb.textContent !== 'Troubleshoot') crumb.textContent = 'Troubleshoot'
  if (crumb.dataset.learningHubId !== HUB_ID) crumb.dataset.learningHubId = HUB_ID
  if (crumb.getAttribute('role') !== 'button') crumb.setAttribute('role', 'button')
  if (crumb.getAttribute('tabindex') !== '0') crumb.setAttribute('tabindex', '0')
  const titleText = `Open ${HUB_LABEL} learning hub`
  if (crumb.getAttribute('title') !== titleText) crumb.setAttribute('title', titleText)
}

function enhanceHub() {
  const page = [...document.querySelectorAll('.learning-hub-page')].find((node) =>
    node.querySelector('.learning-hub-header strong')?.textContent?.trim() === HUB_LABEL,
  )
  if (!page) return

  const count = items().length
  const meta = page.querySelector('.hub-header-meta span')
  if (meta && meta.textContent !== `${count} drills`) meta.textContent = `${count} drills`

  const sourceButton = [...page.querySelectorAll('.hub-five-part-nav button')]
    .find((node) => node.textContent?.includes('Source labs'))
  const sourceSmall = sourceButton?.querySelector('small')
  if (sourceSmall && sourceSmall.textContent !== `${count} mapped drills`) sourceSmall.textContent = `${count} mapped drills`

  const summary = page.querySelector('.hub-source-summary')
  const itemsRoot = page.querySelector('.hub-source-items')
  if (!summary || !itemsRoot) return

  const heading = summary.querySelector('h2')
  const number = summary.querySelector('strong')
  const copy = summary.querySelector('p')
  if (heading && heading.textContent !== 'Troubleshooting & optimization core labs') heading.textContent = 'Troubleshooting & optimization core labs'
  if (number && number.textContent !== String(count)) number.textContent = String(count)
  const copyText = 'Incident triage, reconciliation, late data, partitioning, Spark failures, Airflow, Polars/DuckDB and safe replay.'
  if (copy && copy.textContent !== copyText) copy.textContent = copyText

  if (!summary.querySelector('[data-troubleshooting-practice-button]')) {
    const button = document.createElement('button')
    button.type = 'button'
    button.dataset.troubleshootingPracticeButton = 'true'
    button.textContent = 'Open troubleshooting practice'
    button.addEventListener('click', openPractice)
    summary.appendChild(button)
  }

  if (!itemsRoot.dataset.troubleshootingFilled) {
    itemsRoot.replaceChildren()
    for (const item of items().slice(0, 12)) {
      const row = document.createElement('div')
      const level = document.createElement('span')
      const title = document.createElement('strong')
      const detail = document.createElement('small')
      level.textContent = item.level
      title.textContent = item.title
      detail.textContent = item.task
      row.append(level, title, detail)
      itemsRoot.appendChild(row)
    }
    itemsRoot.dataset.troubleshootingFilled = 'true'
  }
}

export default function TroubleshootingHubBridge() {
  useEffect(() => {
    const sync = () => {
      ensureNavButton()
      wireBreadcrumb()
      enhanceHub()
    }

    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [])

  return null
}
