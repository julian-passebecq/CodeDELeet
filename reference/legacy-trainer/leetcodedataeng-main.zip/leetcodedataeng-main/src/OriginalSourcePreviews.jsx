import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { Database, Table2 } from 'lucide-react'
import { lessons } from './curriculum'
import { sqlChallenges } from './sqlChallenges'
import { engineChallenges } from './engineLab'
import { pythonLabChallenges } from './pythonLab'
import { resolveOriginalSourcePreview } from './sourcePreviewData'

const allPracticeItems = [...lessons, ...sqlChallenges, ...engineChallenges, ...pythonLabChallenges]

function currentItem() {
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  if (!title) return null
  return allPracticeItems.find((item) => item.title === title) ?? null
}

function SourceTable({ table }) {
  return (
    <div className="original-preview-table">
      <strong>{table.name}</strong>
      <div className="original-preview-scroll">
        <table>
          <thead><tr>{table.columns.map((column) => <th key={column}>{column}</th>)}</tr></thead>
          <tbody>
            {table.rows.map((row, rowIndex) => (
              <tr key={`${table.name}-${rowIndex}`}>
                {row.map((value, columnIndex) => <td key={columnIndex}>{value == null ? <span className="original-null">NULL</span> : String(value)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function OriginalPreviewPanel({ preview }) {
  const [open, setOpen] = useState(true)
  return (
    <section className="practice-data-preview original-source-preview">
      <button className="practice-data-preview-header" onClick={() => setOpen((value) => !value)} aria-expanded={open}>
        <span><Database size={13} /><strong>Source data</strong><small>original notebook / file</small></span>
        <span>{open ? 'Collapse' : 'Open'}</span>
      </button>
      {open && (
        <div className="original-source-preview-body">
          <div className="original-source-meta">
            <div><Table2 size={14} /><span><strong>{preview.label}</strong><small>{preview.sourceFile}</small></span></div>
            <span className="source-derived-badge">SOURCE-DERIVED</span>
          </div>
          <div className="original-preview-tables">
            {preview.tables.map((table) => <SourceTable key={table.name} table={table} />)}
          </div>
          <p className="original-source-note">{preview.note} The site shows a small preview only; it does not pretend to execute the original notebook or reproduce every source row.</p>
        </div>
      )}
    </section>
  )
}

export default function OriginalSourcePreviews() {
  const [state, setState] = useState({ mount: null, key: '' })

  useEffect(() => {
    let frame = 0
    const sync = () => {
      const mount = document.querySelector('.leetcode-practice .data-preview-mount')
      const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim() ?? ''
      const variant = document.querySelector('.variant-select')?.value ?? ''
      const nextKey = `${title}|${variant}`
      setState((current) => current.mount === mount && current.key === nextKey ? current : { mount, key: nextKey })
    }
    const scheduleSync = () => {
      if (frame) return
      frame = window.requestAnimationFrame(() => {
        frame = 0
        sync()
      })
    }
    sync()
    const observer = new MutationObserver(scheduleSync)
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['value'] })
    document.addEventListener('change', scheduleSync, true)
    return () => {
      observer.disconnect()
      document.removeEventListener('change', scheduleSync, true)
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  const item = useMemo(() => currentItem(), [state.key])
  const preview = useMemo(() => resolveOriginalSourcePreview(item), [item])

  useEffect(() => {
    const pane = state.mount?.closest('.code-pane')
    if (!pane) return undefined
    pane.classList.toggle('original-source-preview-active', Boolean(preview))
    return () => pane.classList.remove('original-source-preview-active')
  }, [state.mount, preview])

  if (!state.mount || !preview) return null
  return createPortal(<OriginalPreviewPanel preview={preview} />, state.mount)
}
