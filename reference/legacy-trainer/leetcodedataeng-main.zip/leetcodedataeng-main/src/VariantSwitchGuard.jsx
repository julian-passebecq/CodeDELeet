import { useEffect, useRef } from 'react'
import { engineChallenges, getEngineVariant } from './engineLab'
import { sqlChallenges } from './sqlChallenges'
import { getSqlDialectChallenge } from './sqlDialects'
import { STORAGE_PREFIX } from './progressBackup'
import { shouldRestoreVariantStarter } from './variantDraftPolicy'

const DRAFTS_KEY = `${STORAGE_PREFIX}:drafts`

function readSavedDraft(draftKey) {
  if (!draftKey) return null
  try {
    const drafts = JSON.parse(localStorage.getItem(DRAFTS_KEY) ?? '{}')
    const value = drafts?.[draftKey]
    return typeof value === 'string' ? value : null
  } catch {
    return null
  }
}

function currentVariant() {
  const select = document.querySelector('.code-pane-actions .variant-select')
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  if (!(select instanceof HTMLSelectElement) || !title) return null

  const engine = engineChallenges.find((item) => item.title === title)
  if (engine?.variants?.[select.value]) {
    const variant = getEngineVariant(engine, select.value)
    const activeEngine = variant.engine ?? select.value
    return {
      fingerprint: `engine:${engine.id}:${activeEngine}`,
      draftKey: `${engine.id}:engine:${activeEngine}`,
      starter: variant.starter ?? '',
    }
  }

  const sql = sqlChallenges.find((item) => item.title === title)
  if (sql) {
    const variant = getSqlDialectChallenge(sql, select.value)
    return {
      fingerprint: `sql:${sql.id}:${select.value}`,
      draftKey: `${sql.id}:sql:${select.value}`,
      starter: variant.starter ?? '',
    }
  }

  return null
}

function codeTabIsActive() {
  const active = document.querySelector('.leetcode-tabs button.active')?.textContent?.trim().toLowerCase()
  return !active || active === 'code'
}

function editorText() {
  return document.querySelector('.leetcode-editor .view-lines')?.textContent?.trim() ?? ''
}

function resetStarter() {
  const reset = [...document.querySelectorAll('.code-pane-actions button')]
    .find((button) => button.textContent?.trim().toLowerCase() === 'reset')
  if (reset instanceof HTMLButtonElement) reset.click()
}

export default function VariantSwitchGuard() {
  const lastFingerprint = useRef('')
  const timers = useRef([])

  useEffect(() => {
    const clearScheduled = () => {
      for (const timer of timers.current) window.clearTimeout(timer)
      timers.current = []
    }

    const repair = () => {
      const variant = currentVariant()
      if (!variant || !codeTabIsActive()) return
      const savedDraft = readSavedDraft(variant.draftKey)
      if (editorText() === '' && shouldRestoreVariantStarter({ editorText: '', starter: variant.starter, savedDraft })) {
        resetStarter()
      }
    }

    const scheduleRepair = () => {
      clearScheduled()
      timers.current = [40, 120, 260].map((delay) => window.setTimeout(repair, delay))
    }

    const watchCurrentFingerprint = () => {
      const variant = currentVariant()
      if (!variant || variant.fingerprint === lastFingerprint.current) return
      lastFingerprint.current = variant.fingerprint
      scheduleRepair()
    }

    const onChange = (event) => {
      if (event.target instanceof HTMLSelectElement && event.target.classList.contains('variant-select')) {
        lastFingerprint.current = ''
        scheduleRepair()
      }
    }

    document.addEventListener('change', onChange, true)
    const observer = new MutationObserver(watchCurrentFingerprint)
    observer.observe(document.body, { childList: true, subtree: true })
    watchCurrentFingerprint()

    return () => {
      clearScheduled()
      observer.disconnect()
      document.removeEventListener('change', onChange, true)
    }
  }, [])

  return null
}
