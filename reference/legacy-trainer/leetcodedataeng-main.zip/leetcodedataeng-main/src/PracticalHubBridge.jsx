import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'

const projectsByHub = {
  dbt: [
    { label: 'dbt + DuckDB e-commerce ELT', track: 'Analytics Eng', first: 'dbt + DuckDB: local profile', note: 'profile → source → staging → mart → tests → incremental' },
  ],
  pandas: [
    { label: 'pandas analytics pipeline', track: 'Analytics Eng', first: 'pandas: parse the same access logs', note: 'parse logs → merge dimensions → revenue mart → quality gates' },
  ],
  pyspark: [
    { label: 'PySpark / Delta lakehouse pipeline', track: 'Analytics Eng', first: 'PySpark: Bronze → Silver event parsing', note: 'Bronze → Silver → Gold → idempotent Delta MERGE' },
  ],
  python: [
    { label: 'Python analytics project', track: 'Analytics Eng', first: 'pandas: parse the same access logs', note: 'Vectorized parsing and data-quality checks in a realistic pipeline.' },
  ],
  'data engineering': [
    { label: 'Docker-to-serving MLOps project', track: 'MLOps', first: 'Docker: run and inspect a Python container', note: 'Docker → FastAPI → MongoDB → Streamlit → MLflow → CI/CD → orchestration' },
  ],
}

function normalized(value = '') {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
}

function clickContaining(selector, text) {
  const wanted = normalized(text)
  const node = [...document.querySelectorAll(selector)].find((item) => normalized(item.textContent).includes(wanted))
  if (node instanceof HTMLElement) {
    node.click()
    return true
  }
  return false
}

function openLesson(project) {
  const close = document.querySelector('.learning-hub-header > button')
  if (close instanceof HTMLElement) close.click()
  window.setTimeout(() => {
    if (!clickContaining('.track-nav button', project.track)) return
    window.setTimeout(() => {
      if (!clickContaining('.ide-problems-button', 'Problems')) return
      window.setTimeout(() => clickContaining('.problem-drawer-list button', project.first), 60)
    }, 70)
  }, 40)
}

function HubProjects({ hubKey }) {
  const projects = projectsByHub[hubKey] ?? []
  if (!projects.length) return null
  return (
    <section className="hub-practical-projects">
      <div><span>PRACTICAL PROJECTS</span><h3>Build the workflow, not only isolated syntax.</h3></div>
      {projects.map((project) => (
        <button key={project.label} onClick={() => openLesson(project)}>
          <span>PROJECT</span>
          <strong>{project.label}</strong>
          <small>{project.note}</small>
        </button>
      ))}
    </section>
  )
}

export default function PracticalHubBridge() {
  const [mount, setMount] = useState(null)
  const [hubKey, setHubKey] = useState('')

  useEffect(() => {
    const sync = () => {
      const source = document.querySelector('.hub-source-layout')
      const label = document.querySelector('.learning-hub-header strong')?.textContent ?? ''
      const key = normalized(label)
      const matched = Object.keys(projectsByHub).find((candidate) => key === normalized(candidate) || key.includes(normalized(candidate))) ?? ''
      if (!(source instanceof HTMLElement) || !matched) {
        setMount(null)
        setHubKey('')
        return
      }
      let node = source.querySelector(':scope > .hub-practical-projects-mount')
      if (!node) {
        node = document.createElement('div')
        node.className = 'hub-practical-projects-mount'
        source.appendChild(node)
      }
      setMount(node)
      setHubKey(matched)
    }
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [])

  return mount && hubKey ? createPortal(<HubProjects hubKey={hubKey} />, mount) : null
}
