import { useEffect, useMemo, useRef, useState } from 'react'
import Editor, { DiffEditor } from '@monaco-editor/react'
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Code2,
  Database,
  Copy,
  Eraser,
  ExternalLink,
  Flag,
  Github,
  Home,
  Layers3,
  Lightbulb,
  Menu,
  RotateCcw,
  Search,
  TerminalSquare,
  X,
} from 'lucide-react'
import { lessons, levelOrder, sourceLinks, tracks } from './curriculum'
import { sqlChallenges, sqlChallengeTopics } from './sqlChallenges'
import { getSqlDialectChallenge, sqlDialects } from './sqlDialects'
import { engineChallenges, engineDefinitions, engineTopics, getEngineVariant } from './engineLab'
import { pythonLabChallenges, pythonLabTopics } from './pythonLab'

const STORAGE_PREFIX = 'de-coding-reset-v1'

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(`${STORAGE_PREFIX}:${key}`)
    return value ? JSON.parse(value) : fallback
  } catch {
    return fallback
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(`${STORAGE_PREFIX}:${key}`, JSON.stringify(value))
  } catch {
    // Storage can be unavailable or full. Keep the current session usable.
  }
}

function useStoredState(key, fallback) {
  const [value, setValue] = useState(() => readStorage(key, fallback))
  useEffect(() => {
    writeStorage(key, value)
  }, [key, value])
  return [value, setValue]
}

const languageLabels = {
  python: 'Python', sql: 'T-SQL', dax: 'DAX', csharp: 'C#', shell: 'Shell',
  powershell: 'PowerShell', dockerfile: 'Dockerfile', plaintext: 'Text', yaml: 'YAML',
}


function displayLanguage(item) {
  if (item?.dialectLabel) return item.dialectLabel
  if (item?.engineLabel) return item.engineLabel
  return languageLabels[item?.language] ?? item?.language ?? 'Code'
}

function modelExtension(language) {
  return {
    python: 'py', sql: 'sql', dax: 'dax', csharp: 'cs', shell: 'sh',
    powershell: 'ps1', dockerfile: 'Dockerfile', plaintext: 'txt', yaml: 'yml',
  }[language] ?? 'txt'
}

function normalizedCode(value = '') {
  return value.replace(/\s+/g, ' ').trim()
}

const patterns = [
  {
    title: 'Filter rows',
    idea: 'Keep only records matching a condition.',
    examples: [
      ['Python list', 'python', 'active = [x for x in rows if x["status"] == "ACTIVE"]'],
      ['pandas', 'python', 'active = df[df["status"] == "ACTIVE"]'],
      ['T-SQL', 'sql', 'SELECT *\nFROM dbo.customer\nWHERE status = \'ACTIVE\';'],
      ['PySpark', 'python', 'active = df.filter(F.col("status") == "ACTIVE")'],
    ],
  },
  {
    title: 'Group + aggregate',
    idea: 'Partition records by a key and summarize each group.',
    examples: [
      ['pandas', 'python', 'result = df.groupby("customer_id", as_index=False).agg(total=("amount", "sum"))'],
      ['T-SQL', 'sql', 'SELECT customer_id, SUM(amount) AS total\nFROM dbo.sales\nGROUP BY customer_id;'],
      ['BigQuery / DuckDB', 'sql', 'SELECT customer_id, SUM(amount) AS total\nFROM sales\nGROUP BY customer_id;'],
      ['PySpark', 'python', 'result = df.groupBy("customer_id").agg(F.sum("amount").alias("total"))'],
      ['DAX', 'dax', 'Total Sales =\nSUM(Sales[Amount])'],
    ],
  },
  {
    title: 'Latest row per key',
    idea: 'Rank within each business key by timestamp, then keep rank 1.',
    examples: [
      ['T-SQL', 'sql', 'ROW_NUMBER() OVER (\n  PARTITION BY customer_id\n  ORDER BY updated_at DESC\n) AS rn'],
      ['BigQuery / DuckDB', 'sql', 'SELECT * FROM history\nQUALIFY ROW_NUMBER() OVER (\n  PARTITION BY customer_id\n  ORDER BY updated_at DESC\n) = 1'],
      ['PySpark', 'python', 'w = Window.partitionBy("customer_id").orderBy(F.col("updated_at").desc())\nlatest = df.withColumn("rn", F.row_number().over(w)).filter("rn = 1")'],
      ['pandas', 'python', 'latest = df.sort_values("updated_at").drop_duplicates("customer_id", keep="last")'],
    ],
  },
  {
    title: 'Loop over small control data',
    idea: 'Use loops for metadata/control flow, not for row-by-row processing of distributed datasets.',
    examples: [
      ['Python', 'python', 'for table in tables:\n    load_table(table)'],
      ['C# / Tabular Editor', 'csharp', 'foreach (var measure in Selected.Measures)\n{\n    measure.DisplayFolder = "KPIs";\n}'],
      ['PowerShell', 'powershell', 'Get-ChildItem C:\\ETL | ForEach-Object {\n    $_.Name\n}'],
      ['Bash', 'shell', 'for file in *.csv; do\n  echo "$file"\ndone'],
    ],
  },
]

function registerLanguages(monaco) {
  const known = monaco.languages.getLanguages().map((l) => l.id)
  if (!known.includes('dax')) {
    monaco.languages.register({ id: 'dax' })
    monaco.languages.setMonarchTokensProvider('dax', {
      ignoreCase: true,
      defaultToken: '',
      keywords: ['VAR', 'RETURN', 'TRUE', 'FALSE', 'BLANK'],
      functions: [
        'SUM', 'SUMX', 'AVERAGE', 'COUNT', 'COUNTROWS', 'DISTINCTCOUNT', 'MIN', 'MAX',
        'CALCULATE', 'CALCULATETABLE', 'FILTER', 'ALL', 'REMOVEFILTERS', 'VALUES', 'SELECTEDVALUE',
        'DIVIDE', 'IF', 'SWITCH', 'RELATED', 'DATEADD', 'TOTALYTD', 'SAMEPERIODLASTYEAR', 'COALESCE',
      ],
      tokenizer: {
        root: [
          [/\/\/.*$/, 'comment'],
          [/--.*$/, 'comment'],
          [/'[^']*'/, 'type.identifier'],
          [/\[[^\]]+\]/, 'variable'],
          [/"([^"\\]|\\.)*$/, 'string.invalid'],
          [/"([^"\\]|\\.)*"/, 'string'],
          [/\b\d+(\.\d+)?\b/, 'number'],
          [/[a-zA-Z_][\w]*/, {
            cases: {
              '@keywords': 'keyword',
              '@functions': 'predefined',
              '@default': 'identifier',
            },
          }],
          [/[=><!~?:&|+\-*\/\^%]+/, 'operator'],
        ],
      },
    })
  }
}

function Pill({ children, tone = 'default' }) {
  return <span className={`pill pill-${tone}`}>{children}</span>
}

function App() {
  const [view, setView] = useState('home')
  const [selectedTrack, setSelectedTrack] = useStoredState('selectedTrack', 'foundations')
  const [selectedLessonId, setSelectedLessonId] = useStoredState('selectedLesson', 'f-variables')
  const [selectedSqlTopic, setSelectedSqlTopic] = useStoredState('selectedSqlTopic', 'lab-cross')
  const [selectedSqlChallengeId, setSelectedSqlChallengeId] = useStoredState('selectedSqlChallenge', 'lab-cross-size-brand')
  const [sqlDialect, setSqlDialect] = useStoredState('sqlDialect', 'tsql')
  const [selectedEngineTopic, setSelectedEngineTopic] = useStoredState('selectedEngineTopic', 'eng-transfer')
  const [selectedEngineChallengeId, setSelectedEngineChallengeId] = useStoredState('selectedEngineChallenge', 'eng-filter-active')
  const [selectedEngine, setSelectedEngine] = useStoredState('selectedEngine', 'pyspark')
  const [selectedPythonTopic, setSelectedPythonTopic] = useStoredState('selectedPythonTopic', 'py-func-basics')
  const [selectedPythonChallengeId, setSelectedPythonChallengeId] = useStoredState('selectedPythonChallenge', 'pyf-first-function')
  const [drafts, setDrafts] = useStoredState('drafts', {})
  const [flags, setFlags] = useStoredState('flags', [])
  const [mastered, setMastered] = useStoredState('mastered', [])
  const [notes, setNotes] = useStoredState('notes', {})
  const [level, setLevel] = useState('All')
  const [search, setSearch] = useState('')
  const [hintCount, setHintCount] = useState(0)
  const [editorMode, setEditorMode] = useState('write')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  // v1.3 briefly reused the core `sp-withcolumn` id in the engine lab.
  // Migrate only state that is unambiguous; shared flag/mastery/note state cannot be safely attributed.
  useEffect(() => {
    if (selectedEngineChallengeId === 'sp-withcolumn') {
      setSelectedEngineChallengeId('eng-sp-withcolumn')
    }
    setDrafts((old) => {
      const legacyKey = 'sp-withcolumn:engine:pyspark'
      const currentKey = 'eng-sp-withcolumn:engine:pyspark'
      if (!old[legacyKey] || old[currentKey]) return old
      return { ...old, [currentKey]: old[legacyKey] }
    })
  }, [])

  const track = tracks.find((t) => t.id === selectedTrack) ?? tracks[0]
  const selectedLesson = lessons.find((l) => l.id === selectedLessonId && l.track === track.id)
    ?? lessons.find((l) => l.track === track.id)
    ?? lessons[0]
  const currentCode = drafts[selectedLesson.id] ?? selectedLesson.starter

  const sqlTopic = sqlChallengeTopics.find((t) => t.id === selectedSqlTopic) ?? sqlChallengeTopics[0]
  const selectedSqlChallenge = sqlChallenges.find((l) => l.id === selectedSqlChallengeId && l.track === sqlTopic.id)
    ?? sqlChallenges.find((l) => l.track === sqlTopic.id)
    ?? sqlChallenges[0]
  const safeSqlDialect = sqlDialects.some((dialect) => dialect.id === sqlDialect) ? sqlDialect : 'tsql'
  const selectedSqlVariant = getSqlDialectChallenge(selectedSqlChallenge, safeSqlDialect)
  const sqlDraftKey = `${selectedSqlChallenge.id}:sql:${safeSqlDialect}`
  const currentSqlCode = drafts[sqlDraftKey] ?? selectedSqlVariant.starter

  const engineTopic = engineTopics.find((t) => t.id === selectedEngineTopic) ?? engineTopics[0]
  const selectedEngineBase = engineChallenges.find((l) => l.id === selectedEngineChallengeId && l.track === engineTopic.id)
    ?? engineChallenges.find((l) => l.track === engineTopic.id)
    ?? engineChallenges[0]
  const selectedEngineVariant = getEngineVariant(selectedEngineBase, selectedEngine)
  const activeEngine = selectedEngineVariant.engine
  const engineDraftKey = `${selectedEngineBase.id}:engine:${activeEngine}`
  const currentEngineCode = drafts[engineDraftKey] ?? selectedEngineVariant.starter

  const pythonTopic = pythonLabTopics.find((t) => t.id === selectedPythonTopic) ?? pythonLabTopics[0]
  const selectedPythonChallenge = pythonLabChallenges.find((l) => l.id === selectedPythonChallengeId && l.track === pythonTopic.id)
    ?? pythonLabChallenges.find((l) => l.track === pythonTopic.id)
    ?? pythonLabChallenges[0]
  const currentPythonCode = drafts[selectedPythonChallenge.id] ?? selectedPythonChallenge.starter

  const trackLessons = useMemo(() => {
    const q = search.trim().toLowerCase()
    return lessons.filter((lesson) => {
      if (lesson.track !== track.id) return false
      if (level !== 'All' && lesson.level !== level) return false
      if (!q) return true
      return [lesson.title, lesson.concept, lesson.task, lesson.why].join(' ').toLowerCase().includes(q)
    })
  }, [track.id, level, search])

  const coreMasteredCount = lessons.filter((l) => mastered.includes(l.id)).length
  const sqlMasteredCount = sqlChallenges.filter((l) => mastered.includes(l.id)).length
  const engineMasteredCount = engineChallenges.filter((l) => mastered.includes(l.id)).length
  const pythonMasteredCount = pythonLabChallenges.filter((l) => mastered.includes(l.id)).length
  const overallProgress = Math.round((coreMasteredCount / lessons.length) * 100)
  const sqlProgress = Math.round((sqlMasteredCount / sqlChallenges.length) * 100)
  const engineProgress = Math.round((engineMasteredCount / engineChallenges.length) * 100)
  const pythonProgress = Math.round((pythonMasteredCount / pythonLabChallenges.length) * 100)
  const flaggedLessons = [...lessons, ...sqlChallenges, ...engineChallenges, ...pythonLabChallenges].filter((l) => flags.includes(l.id))

  const sqlTrackChallenges = useMemo(() => {
    const q = search.trim().toLowerCase()
    return sqlChallenges.filter((challenge) => {
      if (challenge.track !== sqlTopic.id) return false
      if (level !== 'All' && challenge.level !== level) return false
      if (!q) return true
      return [challenge.title, challenge.concept, challenge.task, challenge.context, challenge.sourcePack].join(' ').toLowerCase().includes(q)
    })
  }, [sqlTopic.id, level, search])

  const engineTrackChallenges = useMemo(() => {
    const q = search.trim().toLowerCase()
    return engineChallenges.filter((challenge) => {
      if (challenge.track !== engineTopic.id) return false
      if (level !== 'All' && challenge.level !== level) return false
      if (!q) return true
      return [challenge.title, challenge.concept, challenge.task, challenge.context].join(' ').toLowerCase().includes(q)
    })
  }, [engineTopic.id, level, search])

  const pythonTrackChallenges = useMemo(() => {
    const q = search.trim().toLowerCase()
    return pythonLabChallenges.filter((challenge) => {
      if (challenge.track !== pythonTopic.id) return false
      if (level !== 'All' && challenge.level !== level) return false
      if (!q) return true
      return [challenge.title, challenge.concept, challenge.task].join(' ').toLowerCase().includes(q)
    })
  }, [pythonTopic.id, level, search])

  useEffect(() => {
    setHintCount(0)
    setEditorMode('write')
    setCopied(false)
  }, [selectedLessonId, selectedSqlChallengeId, selectedEngineChallengeId, selectedPythonChallengeId, sqlDialect, activeEngine, view])

  function resetProblemFilters() {
    setLevel('All')
    setSearch('')
  }

  function openTrack(trackId) {
    resetProblemFilters()
    setSelectedTrack(trackId)
    const first = lessons.find((l) => l.track === trackId)
    if (first) setSelectedLessonId(first.id)
    setView('practice')
    setSidebarOpen(false)
  }

  function openLesson(lesson) {
    setSelectedTrack(lesson.track)
    setSelectedLessonId(lesson.id)
    setView('practice')
    setSidebarOpen(false)
  }

  function openSqlTopic(topicId) {
    resetProblemFilters()
    setSelectedSqlTopic(topicId)
    const first = sqlChallenges.find((l) => l.track === topicId)
    if (first) setSelectedSqlChallengeId(first.id)
    setView('sql-practice')
    setSidebarOpen(false)
  }

  function openSqlChallenge(challenge) {
    setSelectedSqlTopic(challenge.track)
    setSelectedSqlChallengeId(challenge.id)
    setView('sql-practice')
    setSidebarOpen(false)
  }

  function openEngineTopic(topicId) {
    resetProblemFilters()
    setSelectedEngineTopic(topicId)
    const first = engineChallenges.find((l) => l.track === topicId)
    if (first) {
      setSelectedEngineChallengeId(first.id)
      const available = Object.keys(first.variants)
      if (!available.includes(selectedEngine)) setSelectedEngine(available[0])
    }
    setView('engine-practice')
    setSidebarOpen(false)
  }

  function openEngineChallenge(challenge) {
    setSelectedEngineTopic(challenge.track)
    setSelectedEngineChallengeId(challenge.id)
    const available = Object.keys(challenge.variants)
    if (!available.includes(selectedEngine)) setSelectedEngine(available[0])
    setView('engine-practice')
    setSidebarOpen(false)
  }

  function openPythonTopic(topicId) {
    resetProblemFilters()
    setSelectedPythonTopic(topicId)
    const first = pythonLabChallenges.find((l) => l.track === topicId)
    if (first) setSelectedPythonChallengeId(first.id)
    setView('python-practice')
    setSidebarOpen(false)
  }

  function openPythonChallenge(challenge) {
    setSelectedPythonTopic(challenge.track)
    setSelectedPythonChallengeId(challenge.id)
    setView('python-practice')
    setSidebarOpen(false)
  }

  function openAnyLesson(item) {
    if (item.collection === 'sql-lab') openSqlChallenge(item)
    else if (item.collection === 'engine-lab') openEngineChallenge(item)
    else if (item.collection === 'python-lab') openPythonChallenge(item)
    else openLesson(item)
  }

  function toggleFlagFor(id) {
    setFlags((old) => old.includes(id) ? old.filter((item) => item !== id) : [...old, id])
  }

  function toggleMasteredFor(id) {
    setMastered((old) => old.includes(id) ? old.filter((item) => item !== id) : [...old, id])
  }

  function nextLesson(delta) {
    const list = lessons.filter((l) => l.track === track.id)
    const index = list.findIndex((l) => l.id === selectedLesson.id)
    const next = list[index + delta]
    if (next) setSelectedLessonId(next.id)
  }

  function nextSqlChallenge(delta) {
    const list = sqlChallenges.filter((l) => l.track === sqlTopic.id)
    const index = list.findIndex((l) => l.id === selectedSqlChallenge.id)
    const next = list[index + delta]
    if (next) setSelectedSqlChallengeId(next.id)
  }

  function nextEngineChallenge(delta) {
    const list = engineChallenges.filter((l) => l.track === engineTopic.id)
    const index = list.findIndex((l) => l.id === selectedEngineBase.id)
    const next = list[index + delta]
    if (next) {
      setSelectedEngineChallengeId(next.id)
      const available = Object.keys(next.variants)
      if (!available.includes(selectedEngine)) setSelectedEngine(available[0])
    }
  }

  function nextPythonChallenge(delta) {
    const list = pythonLabChallenges.filter((l) => l.track === pythonTopic.id)
    const index = list.findIndex((l) => l.id === selectedPythonChallenge.id)
    const next = list[index + delta]
    if (next) setSelectedPythonChallengeId(next.id)
  }

  async function copySolutionFor(item) {
    const text = item.solution ?? ''
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard API unavailable')
      await navigator.clipboard.writeText(text)
    } catch {
      const textarea = document.createElement('textarea')
      textarea.value = text
      textarea.setAttribute('readonly', '')
      textarea.style.position = 'fixed'
      textarea.style.opacity = '0'
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      textarea.remove()
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 1200)
  }

  return (
    <div className={`app-shell ${['practice', 'sql-practice', 'engine-practice', 'python-practice'].includes(view) ? 'practice-mode' : ''}`}>
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="brand" onClick={() => { setView('home'); setSidebarOpen(false) }}>
          <div className="brand-mark"><Code2 size={20} /></div>
          <div>
            <strong>Coding Reset</strong>
            <span>Data Engineering Lab</span>
          </div>
        </div>

        <nav className="main-nav">
          <button className={view === 'home' ? 'active' : ''} onClick={() => { setView('home'); setSidebarOpen(false) }}><Home size={17} /> Dashboard</button>
          <button className={view === 'patterns' ? 'active' : ''} onClick={() => { setView('patterns'); setSidebarOpen(false) }}><Layers3 size={17} /> Pattern bridge</button>
          <button className={view === 'sql-lab' || view === 'sql-practice' ? 'active' : ''} onClick={() => { setView('sql-lab'); setSidebarOpen(false) }}><Database size={17} /> SQL Dialect Lab <span className="nav-count">{sqlChallenges.length}</span></button>
          <button className={view === 'engine-lab' || view === 'engine-practice' ? 'active' : ''} onClick={() => { setView('engine-lab'); setSidebarOpen(false) }}><Layers3 size={17} /> Multi-Engine Lab <span className="nav-count">{engineChallenges.length}</span></button>
          <button className={view === 'python-lab' || view === 'python-practice' ? 'active' : ''} onClick={() => { setView('python-lab'); setSidebarOpen(false) }}><Code2 size={17} /> Python Syntax Gym <span className="nav-count">{pythonLabChallenges.length}</span></button>
          <button className={view === 'flagged' ? 'active' : ''} onClick={() => { setView('flagged'); setSidebarOpen(false) }}><Flag size={17} /> Flagged <span className="nav-count">{flaggedLessons.length}</span></button>
          <button className={view === 'sources' ? 'active' : ''} onClick={() => { setView('sources'); setSidebarOpen(false) }}><BookOpen size={17} /> Sources</button>
        </nav>

        <div className="sidebar-label">CORE CURRICULUM</div>
        <div className="track-nav">
          {tracks.map((t) => {
            const count = lessons.filter((l) => l.track === t.id).length
            const done = lessons.filter((l) => l.track === t.id && mastered.includes(l.id)).length
            return (
              <button key={t.id} className={selectedTrack === t.id && view === 'practice' ? 'active' : ''} onClick={() => openTrack(t.id)}>
                <span className="track-icon">{t.icon}</span>
                <span className="track-nav-text"><strong>{t.short}</strong><small>{done}/{count} mastered</small></span>
                <ChevronRight size={14} />
              </button>
            )
          })}
        </div>
        <div className="sidebar-footer">
          <div className="progress-line"><span style={{ width: `${overallProgress}%` }} /></div>
          <div><span>{overallProgress}% complete</span><span>{coreMasteredCount}/{lessons.length}</span></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="mobile-header">
          <button onClick={() => setSidebarOpen(true)}><Menu size={20} /></button>
          <strong>Coding Reset Lab</strong>
        </header>
        {sidebarOpen && <button className="overlay" aria-label="Close menu" onClick={() => setSidebarOpen(false)} />}

        {view === 'home' && <HomeView overallProgress={overallProgress} coreMasteredCount={coreMasteredCount} sqlProgress={sqlProgress} sqlMasteredCount={sqlMasteredCount} engineProgress={engineProgress} engineMasteredCount={engineMasteredCount} pythonProgress={pythonProgress} pythonMasteredCount={pythonMasteredCount} mastered={mastered} flags={flaggedLessons} drafts={drafts} openTrack={openTrack} openSqlLab={() => setView('sql-lab')} openEngineLab={() => setView('engine-lab')} openPythonLab={() => setView('python-lab')} />}
        {view === 'patterns' && <PatternsView openLesson={openLesson} />}
        {view === 'sql-lab' && <SqlLabView mastered={mastered} flags={flags} openSqlTopic={openSqlTopic} sqlDialect={sqlDialect} setSqlDialect={setSqlDialect} />}
        {view === 'engine-lab' && <EngineLabView mastered={mastered} flags={flags} openTopic={openEngineTopic} />}
        {view === 'python-lab' && <PythonLabView mastered={mastered} flags={flags} openTopic={openPythonTopic} />}
        {view === 'flagged' && <FlaggedView items={flaggedLessons} openLesson={openAnyLesson} />}
        {view === 'sources' && <SourcesView />}
        {view === 'practice' && (
          <PracticeView
            track={track}
            trackLessons={trackLessons}
            allItems={lessons.filter((l) => l.track === track.id)}
            collectionLabel="Core Curriculum"
            selectedLesson={selectedLesson}
            selectedLessonId={selectedLesson.id}
            currentCode={currentCode}
            setCode={(value) => setDrafts((old) => ({ ...old, [selectedLesson.id]: value ?? '' }))}
            flags={flags}
            mastered={mastered}
            toggleFlag={() => toggleFlagFor(selectedLesson.id)}
            toggleMastered={() => toggleMasteredFor(selectedLesson.id)}
            notes={notes}
            setNotes={setNotes}
            hintCount={hintCount}
            setHintCount={setHintCount}
            editorMode={editorMode}
            setEditorMode={setEditorMode}
            openLesson={openLesson}
            level={level}
            setLevel={setLevel}
            search={search}
            setSearch={setSearch}
            erase={() => setDrafts((old) => ({ ...old, [selectedLesson.id]: '' }))}
            reset={() => setDrafts((old) => ({ ...old, [selectedLesson.id]: selectedLesson.starter }))}
            nextLesson={nextLesson}
            copySolution={() => copySolutionFor(selectedLesson)}
            copied={copied}
            modelPath={`file:///coding-reset/core/${selectedLesson.id}.${modelExtension(selectedLesson.language)}`}
            onExit={() => setView('home')}
          />
        )}
        {view === 'sql-practice' && (
          <PracticeView
            track={sqlTopic}
            trackLessons={sqlTrackChallenges}
            allItems={sqlChallenges.filter((l) => l.track === sqlTopic.id)}
            collectionLabel="SQL Dialect Lab"
            selectedLesson={selectedSqlVariant}
            selectedLessonId={selectedSqlChallenge.id}
            currentCode={currentSqlCode}
            setCode={(value) => setDrafts((old) => ({ ...old, [sqlDraftKey]: value ?? '' }))}
            flags={flags}
            mastered={mastered}
            toggleFlag={() => toggleFlagFor(selectedSqlChallenge.id)}
            toggleMastered={() => toggleMasteredFor(selectedSqlChallenge.id)}
            notes={notes}
            setNotes={setNotes}
            hintCount={hintCount}
            setHintCount={setHintCount}
            editorMode={editorMode}
            setEditorMode={setEditorMode}
            openLesson={openSqlChallenge}
            level={level}
            setLevel={setLevel}
            search={search}
            setSearch={setSearch}
            erase={() => setDrafts((old) => ({ ...old, [sqlDraftKey]: '' }))}
            reset={() => setDrafts((old) => ({ ...old, [sqlDraftKey]: selectedSqlVariant.starter }))}
            nextLesson={nextSqlChallenge}
            copySolution={() => copySolutionFor(selectedSqlVariant)}
            copied={copied}
            modelPath={`file:///coding-reset/sql/${selectedSqlChallenge.id}/${safeSqlDialect}.sql`}
            variantOptions={sqlDialects.map((d) => ({ value: d.id, label: d.label }))}
            variantValue={safeSqlDialect}
            onVariantChange={setSqlDialect}
            variantNote={selectedSqlVariant.dialectNote}
            onExit={() => setView('sql-lab')}
          />
        )}
        {view === 'engine-practice' && (
          <PracticeView
            track={engineTopic}
            trackLessons={engineTrackChallenges}
            allItems={engineChallenges.filter((l) => l.track === engineTopic.id)}
            collectionLabel="Multi-Engine Lab"
            selectedLesson={selectedEngineVariant}
            selectedLessonId={selectedEngineBase.id}
            currentCode={currentEngineCode}
            setCode={(value) => setDrafts((old) => ({ ...old, [engineDraftKey]: value ?? '' }))}
            flags={flags}
            mastered={mastered}
            toggleFlag={() => toggleFlagFor(selectedEngineBase.id)}
            toggleMastered={() => toggleMasteredFor(selectedEngineBase.id)}
            notes={notes}
            setNotes={setNotes}
            hintCount={hintCount}
            setHintCount={setHintCount}
            editorMode={editorMode}
            setEditorMode={setEditorMode}
            openLesson={openEngineChallenge}
            level={level}
            setLevel={setLevel}
            search={search}
            setSearch={setSearch}
            erase={() => setDrafts((old) => ({ ...old, [engineDraftKey]: '' }))}
            reset={() => setDrafts((old) => ({ ...old, [engineDraftKey]: selectedEngineVariant.starter }))}
            nextLesson={nextEngineChallenge}
            copySolution={() => copySolutionFor(selectedEngineVariant)}
            copied={copied}
            modelPath={`file:///coding-reset/engine/${selectedEngineBase.id}/${activeEngine}.${modelExtension(selectedEngineVariant.language)}`}
            variantOptions={selectedEngineVariant.availableEngines.map((id) => ({ value: id, label: engineDefinitions[id]?.label ?? id }))}
            variantValue={activeEngine}
            onVariantChange={setSelectedEngine}
            variantNote={`Practice this transformation as ${selectedEngineVariant.engineLabel}. Switch engines without losing the draft for each engine.`}
            onExit={() => setView('engine-lab')}
          />
        )}
        {view === 'python-practice' && (
          <PracticeView
            track={pythonTopic}
            trackLessons={pythonTrackChallenges}
            allItems={pythonLabChallenges.filter((l) => l.track === pythonTopic.id)}
            collectionLabel="Python Syntax Gym"
            selectedLesson={selectedPythonChallenge}
            selectedLessonId={selectedPythonChallenge.id}
            currentCode={currentPythonCode}
            setCode={(value) => setDrafts((old) => ({ ...old, [selectedPythonChallenge.id]: value ?? '' }))}
            flags={flags}
            mastered={mastered}
            toggleFlag={() => toggleFlagFor(selectedPythonChallenge.id)}
            toggleMastered={() => toggleMasteredFor(selectedPythonChallenge.id)}
            notes={notes}
            setNotes={setNotes}
            hintCount={hintCount}
            setHintCount={setHintCount}
            editorMode={editorMode}
            setEditorMode={setEditorMode}
            openLesson={openPythonChallenge}
            level={level}
            setLevel={setLevel}
            search={search}
            setSearch={setSearch}
            erase={() => setDrafts((old) => ({ ...old, [selectedPythonChallenge.id]: '' }))}
            reset={() => setDrafts((old) => ({ ...old, [selectedPythonChallenge.id]: selectedPythonChallenge.starter }))}
            nextLesson={nextPythonChallenge}
            copySolution={() => copySolutionFor(selectedPythonChallenge)}
            copied={copied}
            modelPath={`file:///coding-reset/python/${selectedPythonChallenge.id}.py`}
            onExit={() => setView('python-lab')}
          />
        )}
      </main>
    </div>
  )
}

function HomeView({ overallProgress, coreMasteredCount, sqlProgress, sqlMasteredCount, engineProgress, engineMasteredCount, pythonProgress, pythonMasteredCount, mastered, flags, drafts, openTrack, openSqlLab, openEngineLab, openPythonLab }) {
  const starterTracks = tracks.slice(0, 5)
  return (
    <div className="page home-page">
      <section className="hero">
        <div>
          <Pill tone="accent">DATA ENGINEERING CODING TRAINER</Pill>
          <h1>Rebuild coding fluency from the syntax up.</h1>
          <p>Not LeetCode for its own sake. Practice the code you need to write as a data engineer: Python, T-SQL, pandas, PySpark, DAX, Tabular Editor C#, orchestration, terminal, Git, containers, and cloud CLIs.</p>
          <div className="hero-actions">
            <button className="primary" onClick={() => openTrack('foundations')}><Code2 size={17} /> Start from fundamentals</button>
            <button className="secondary" onClick={() => openTrack('sql')}><TerminalSquare size={17} /> Guided T-SQL basics</button>
            <button className="secondary" onClick={openSqlLab}><Database size={17} /> SQL Dialect Lab</button>
            <button className="secondary" onClick={openEngineLab}><Layers3 size={17} /> Multi-Engine Lab</button>
            <button className="secondary" onClick={openPythonLab}><Code2 size={17} /> Python Syntax Gym</button>
          </div>
        </div>
        <div className="hero-console" aria-label="Example code">
          <div className="console-bar"><span></span><span></span><span></span><small>syntax_reset.py</small></div>
          <pre><code><span className="kw">def</span> <span className="fn">load_table</span>(table, mode=<span className="str">"append"</span>):{`\n`}    <span className="kw">for</span> batch <span className="kw">in</span> batches:{`\n`}        write(batch, mode=mode){`\n`}    <span className="kw">return</span> <span className="str">"done"</span></code></pre>
          <div className="console-note">Goal: syntax becomes automatic enough that you can focus on data logic.</div>
        </div>
      </section>

      <section className="stats-grid">
        <Stat label="Core progress" value={`${overallProgress}%`} sub={`${coreMasteredCount}/${lessons.length} core drills mastered`} />
        <Stat label="Needs review" value={flags.length} sub="Flag anything that still feels shaky" />
        <Stat label="Drafts saved" value={Object.keys(drafts).length} sub="Local browser storage" />
        <Stat label="SQL Dialect Lab" value={sqlChallenges.length} sub={`${sqlMasteredCount} mastered · 3 dialect modes`} />
        <Stat label="Multi-Engine Lab" value={engineChallenges.length} sub={`${engineMasteredCount} mastered · ${engineProgress}% complete`} />
        <Stat label="Python Syntax Gym" value={pythonLabChallenges.length} sub={`${pythonMasteredCount} mastered · ${pythonProgress}% complete`} />
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span>RECOMMENDED ORDER</span><h2>Build the floor before the ceiling.</h2></div></div>
        <div className="path-row">
          {['Foundations', 'Algorithms', 'Python', 'T-SQL', 'pandas / PySpark', 'Orchestration + Ops'].map((step, i) => (
            <div className="path-step" key={step}><span>{i + 1}</span><strong>{step}</strong>{i < 5 && <ArrowRight size={15} />}</div>
          ))}
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span>STARTER TRACKS</span><h2>Write first. Read the solution second.</h2></div><p>Each drill has a blank or partial editor, hints, a solution, reset/erase, compare view, notes, flags, and mastery tracking.</p></div>
        <div className="track-card-grid">
          {starterTracks.map((t) => <TrackCard key={t.id} track={t} openTrack={openTrack} />)}
        </div>
      </section>

      <section className="split-section">
        <div className="info-card">
          <div className="icon-box"><Code2 size={19} /></div>
          <h3>VS Code-style editor</h3>
          <p>The practice area uses Monaco—the same editor engine that powers VS Code—with real syntax coloring for Python, SQL, C#, shell, PowerShell, Dockerfile and a custom DAX grammar.</p>
        </div>
        <div className="info-card">
          <div className="icon-box"><BookOpen size={19} /></div>
          <h3>Why no notebook execution in v1?</h3>
          <p>You said execution is optional. This version optimizes for typing and recalling syntax. JupyterLite can be embedded later for in-browser Python execution without turning the whole app into Streamlit.</p>
        </div>
        <div className="info-card">
          <div className="icon-box"><TerminalSquare size={19} /></div>
          <h3>Operator literacy included</h3>
          <p>SSH, Bash, PowerShell, Git, cron, Docker, kubectl, Azure CLI, gcloud, Fabric CLI, and Power BI gateway operations are treated as first-class DE skills.</p>
        </div>
      </section>
    </div>
  )
}

function Stat({ label, value, sub }) {
  return <div className="stat-card"><span>{label}</span><strong>{value}</strong><small>{sub}</small></div>
}

function TrackCard({ track, openTrack }) {
  const count = lessons.filter((l) => l.track === track.id).length
  return (
    <button className="track-card" onClick={() => openTrack(track.id)}>
      <div className="track-card-top"><span className="track-icon large">{track.icon}</span><Pill>{count} drills</Pill></div>
      <h3>{track.name}</h3>
      <p>{track.description}</p>
      <div className="concept-cloud">{track.concepts.slice(0, 5).map((c) => <span key={c}>{c}</span>)}</div>
      <div className="card-link">Open track <ArrowRight size={15} /></div>
    </button>
  )
}

function PracticeView(props) {
  const {
    track, trackLessons, allItems, collectionLabel, selectedLesson, selectedLessonId, currentCode, setCode,
    flags, mastered, toggleFlag, toggleMastered, notes, setNotes, hintCount, setHintCount,
    editorMode, setEditorMode, openLesson, level, setLevel, search, setSearch,
    erase, reset, nextLesson, copySolution, copied, onExit, modelPath,
    variantOptions = [], variantValue, onVariantChange, variantNote,
  } = props
  const [problemListOpen, setProblemListOpen] = useState(false)
  const [problemTab, setProblemTab] = useState('description')
  const [reviewOpen, setReviewOpen] = useState(false)
  const [reviewTab, setReviewTab] = useState('hint')
  const [flaggedOnly, setFlaggedOnly] = useState(false)
  const [splitPct, setSplitPct] = useState(43)
  const gridRef = useRef(null)
  const allTrackLessons = allItems
  const index = allTrackLessons.findIndex((l) => l.id === selectedLessonId)
  const isFlagged = flags.includes(selectedLesson.id)
  const isMastered = mastered.includes(selectedLesson.id)
  const visibleLessons = flaggedOnly ? trackLessons.filter((l) => flags.includes(l.id)) : trackLessons
  const selectedVariantLabel = variantOptions.find((option) => option.value === variantValue)?.label
  const activeLanguageLabel = selectedLesson.dialectLabel ?? selectedLesson.engineLabel ?? selectedVariantLabel ?? displayLanguage(selectedLesson)
  const isAttempted = Boolean(currentCode.trim()) && normalizedCode(currentCode) !== normalizedCode(selectedLesson.starter)

  useEffect(() => {
    setProblemTab('description')
    setReviewOpen(false)
  }, [selectedLessonId, variantValue])

  useEffect(() => {
    if (!problemListOpen) return undefined
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setProblemListOpen(false)
    }
    window.addEventListener('keydown', closeOnEscape)
    return () => window.removeEventListener('keydown', closeOnEscape)
  }, [problemListOpen])

  function clampSplit(value) {
    return Math.max(30, Math.min(63, value))
  }

  function startSplitDrag(event) {
    if (window.innerWidth < 900) return
    event.preventDefault()
    const rect = gridRef.current?.getBoundingClientRect()
    if (!rect?.width) return
    document.body.classList.add('resizing-panes')
    const move = (e) => {
      const pct = ((e.clientX - rect.left) / rect.width) * 100
      setSplitPct(clampSplit(pct))
    }
    const stop = () => {
      document.body.classList.remove('resizing-panes')
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', stop)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', stop)
  }

  function resizeWithKeyboard(event) {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
    event.preventDefault()
    setSplitPct((value) => clampSplit(value + (event.key === 'ArrowRight' ? 3 : -3)))
  }

  const editorOptions = {
    minimap: { enabled: false },
    fontSize: 14,
    lineHeight: 22,
    fontFamily: "'Cascadia Code', 'SFMono-Regular', Consolas, 'Liberation Mono', monospace",
    padding: { top: 14 },
    scrollBeyondLastLine: false,
    wordWrap: 'on',
    tabSize: 4,
    insertSpaces: true,
    automaticLayout: true,
    renderLineHighlight: 'line',
    bracketPairColorization: { enabled: true },
  }

  return (
    <div className="leetcode-practice">
      <header className="ide-nav">
        <div className="ide-nav-left">
          <button className="ide-icon-button" onClick={onExit} title="Back to dashboard"><Home size={17} /></button>
          <button className="ide-problems-button" onClick={() => setProblemListOpen(true)}><Menu size={16} /> Problems</button>
          <div className="ide-breadcrumb"><span>{track.short}</span><ChevronRight size={13} /><strong>{selectedLesson.title}</strong></div>
        </div>
        <div className="ide-nav-center">
          <button disabled={index <= 0} onClick={() => nextLesson(-1)} title="Previous problem"><ArrowLeft size={16} /></button>
          <span>{index + 1} / {allTrackLessons.length}</span>
          <button disabled={index >= allTrackLessons.length - 1} onClick={() => nextLesson(1)} title="Next problem"><ArrowRight size={16} /></button>
        </div>
        <div className="ide-nav-right">
          <button className={isFlagged ? 'flag-on' : ''} onClick={toggleFlag} aria-pressed={isFlagged}><Flag size={15} /> <span>{isFlagged ? 'Flagged' : 'Flag'}</span></button>
          <button className={isMastered ? 'mastered-on' : ''} onClick={toggleMastered} aria-pressed={isMastered}><CheckCircle2 size={15} /> <span>{isMastered ? 'Mastered' : 'Master'}</span></button>
        </div>
      </header>

      {problemListOpen && (
        <>
          <button className="problem-drawer-backdrop" aria-label="Close problems" onClick={() => setProblemListOpen(false)} />
          <aside className="problem-drawer">
            <div className="problem-drawer-header">
              <div><span>{collectionLabel}</span><strong>{track.name}</strong></div>
              <button onClick={() => setProblemListOpen(false)} aria-label="Close problem list"><X size={18} /></button>
            </div>
            <div className="problem-drawer-tools">
              <div className="search-box"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search problems" /></div>
              <div className="level-filter">
                {['All', ...levelOrder].map((item) => <button key={item} className={level === item ? 'active' : ''} onClick={() => setLevel(item)}>{item}</button>)}
              </div>
              <button className={`flag-filter ${flaggedOnly ? 'active' : ''}`} onClick={() => setFlaggedOnly((v) => !v)} aria-pressed={flaggedOnly}><Flag size={13} /> Flagged only</button>
            </div>
            <div className="problem-drawer-list">
              {visibleLessons.length ? visibleLessons.map((lesson) => {
                const lessonIndex = allTrackLessons.findIndex((item) => item.id === lesson.id)
                return (
                  <button key={lesson.id} className={lesson.id === selectedLessonId ? 'active' : ''} onClick={() => { openLesson(lesson); setProblemListOpen(false) }}>
                    <span className="problem-number">{String(lessonIndex + 1).padStart(2, '0')}</span>
                    <div><strong>{lesson.title}</strong><small>{lesson.collection === 'engine-lab' ? 'Multi-engine' : (collectionLabel === 'SQL Dialect Lab' ? (selectedVariantLabel ?? 'SQL') : displayLanguage(lesson))} · {lesson.level}</small></div>
                    <span className="problem-status-icons">
                      {flags.includes(lesson.id) && <Flag size={12} className="flagged" />}
                      {mastered.includes(lesson.id) && <CheckCircle2 size={13} className="mastered" />}
                    </span>
                  </button>
                )
              }) : <div className="empty-small">No problems match this filter.</div>}
            </div>
          </aside>
        </>
      )}

      <div
        ref={gridRef}
        className="leetcode-grid"
        style={{ gridTemplateColumns: `minmax(330px, ${splitPct}%) 6px minmax(430px, 1fr)` }}
      >
        <section className="problem-pane">
          <div className="pane-tabs">
            <button className={problemTab === 'description' ? 'active' : ''} onClick={() => setProblemTab('description')}><BookOpen size={14} /> Description</button>
            <button className={problemTab === 'hints' ? 'active' : ''} onClick={() => setProblemTab('hints')}><Lightbulb size={14} /> Hints</button>
            <button className={problemTab === 'notes' ? 'active' : ''} onClick={() => setProblemTab('notes')}><CircleHelp size={14} /> Notes</button>
          </div>

          <div className="problem-scroll">
            {problemTab === 'description' && (
              <article className="problem-description">
                <div className="problem-kicker">Problem {index + 1} of {allTrackLessons.length}</div>
                <h1>{selectedLesson.title}</h1>
                <div className="problem-meta"><Pill tone={selectedLesson.level.toLowerCase()}>{selectedLesson.level}</Pill><Pill>{activeLanguageLabel}</Pill>{isAttempted && <Pill tone="accent">Attempted</Pill>}{selectedLesson.sourcePack && <Pill tone="accent">Imported · {selectedLesson.sourcePack}</Pill>}{isFlagged && <Pill tone="accent">Review</Pill>}</div>
                {variantNote && <div className="variant-note"><Layers3 size={15} /><span>{variantNote}</span></div>}

                <section className="problem-section">
                  <h3>Concept</h3>
                  <p>{selectedLesson.concept}</p>
                </section>
                {selectedLesson.context && (
                  <section className="problem-context">
                    <h3>Data / schema</h3>
                    <code>{selectedLesson.context}</code>
                  </section>
                )}
                <section className="problem-task-card">
                  <div><Code2 size={17} /><strong>Your task</strong></div>
                  <p>{selectedLesson.task}</p>
                </section>
                <section className="problem-section">
                  <h3>Why this matters for data engineering</h3>
                  <p>{selectedLesson.why}</p>
                </section>
                <section className="problem-section practice-rule">
                  <h3>Practice rule</h3>
                  <p>{selectedLesson.collection === 'sql-lab' || selectedLesson.collection === 'engine-lab' ? 'Do not open Solution first. Write the transformation from the task, use progressive hints only when blocked, then reveal the reference answer and explanation. Switch dialect/engine only after making a real attempt.' : 'Type the structure from memory first. Use a hint only when blocked, then compare against the reference solution. You do not need to execute code for this drill.'}</p>
                </section>
              </article>
            )}

            {problemTab === 'hints' && (
              <article className="problem-description">
                <div className="problem-kicker">PROGRESSIVE HINTS</div>
                <h2>Reveal only what you need.</h2>
                <p className="tab-intro">The point is recall. Each click exposes one more clue without immediately showing the solution.</p>
                <button className="reveal-hint" onClick={() => setHintCount((n) => Math.min(n + 1, selectedLesson.hints.length))} disabled={hintCount >= selectedLesson.hints.length}><Lightbulb size={15} /> Reveal next hint</button>
                {hintCount === 0 ? <div className="hint-placeholder">No hints revealed yet.</div> : (
                  <ol className="hint-list">{selectedLesson.hints.slice(0, hintCount).map((hint, i) => <li key={i}><span>{i + 1}</span><p>{hint}</p></li>)}</ol>
                )}
                <div className="trap-box"><AlertTriangle size={17} /><div><strong>Common trap</strong><p>{selectedLesson.pitfall}</p></div></div>
              </article>
            )}

            {problemTab === 'notes' && (
              <article className="problem-description">
                <div className="problem-kicker">PERSONAL REVIEW NOTE</div>
                <h2>Record exactly what went wrong.</h2>
                <p className="tab-intro">Useful notes are specific: “forgot the colon after for”, “confused parameter with argument”, or “need to redo Window.partitionBy”.</p>
                <textarea
                  className="leetcode-notes"
                  value={notes[selectedLesson.id] ?? ''}
                  onChange={(e) => setNotes((old) => ({ ...old, [selectedLesson.id]: e.target.value }))}
                  placeholder="What did you forget or confuse?"
                />
                <div className="note-actions">
                  <button className={isFlagged ? 'danger-active' : ''} onClick={toggleFlag}><Flag size={14} /> {isFlagged ? 'Keep in review queue' : 'Add to review queue'}</button>
                  <button className={isMastered ? 'success-active' : ''} onClick={toggleMastered}><Check size={14} /> {isMastered ? 'Mastered' : 'Mark mastered'}</button>
                </div>
              </article>
            )}
          </div>
        </section>

        <div
          className="pane-resizer"
          role="separator"
          aria-label="Resize problem and editor panes"
          aria-orientation="vertical"
          aria-valuemin={30}
          aria-valuemax={63}
          aria-valuenow={Math.round(splitPct)}
          tabIndex={0}
          onPointerDown={startSplitDrag}
          onKeyDown={resizeWithKeyboard}
          title="Drag to resize panes; use Left/Right arrows when focused"
        ><span /></div>

        <section className="code-pane">
          <div className="code-pane-toolbar">
            <div className="mode-tabs leetcode-tabs">
              <button className={editorMode === 'write' ? 'active' : ''} onClick={() => setEditorMode('write')}>Code</button>
              <button className={editorMode === 'solution' ? 'active' : ''} onClick={() => setEditorMode('solution')}>{editorMode === 'write' ? 'Reveal solution' : 'Solution'}</button>
              <button className={editorMode === 'compare' ? 'active' : ''} onClick={() => setEditorMode('compare')}>Compare</button>
            </div>
            <div className="code-pane-actions">
              {variantOptions.length > 0 && (
                <select className="variant-select" value={variantValue} onChange={(e) => onVariantChange?.(e.target.value)} aria-label="Practice variant">
                  {variantOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              )}
              <span className="language-chip">{activeLanguageLabel}</span>
              <button onClick={erase} title="Erase all code"><Eraser size={14} /> Erase</button>
              <button onClick={reset} title="Restore starter code"><RotateCcw size={14} /> Reset</button>
              {editorMode !== 'write' && <button onClick={copySolution}><Copy size={14} /> {copied ? 'Copied' : 'Copy'}</button>}
            </div>
          </div>

          {editorMode !== 'write' && selectedLesson.solutionExplanation && (
            <div className="solution-explanation">
              <div><Lightbulb size={15} /><strong>Why this works</strong></div>
              <p>{selectedLesson.solutionExplanation}</p>
            </div>
          )}

          <div className="editor-wrap leetcode-editor">
            {editorMode === 'write' && (
              <Editor
                height="100%"
                language={selectedLesson.language}
                path={modelPath}
                value={currentCode}
                onChange={setCode}
                beforeMount={registerLanguages}
                theme="vs-dark"
                options={editorOptions}
              />
            )}
            {editorMode === 'solution' && (
              <Editor
                height="100%"
                language={selectedLesson.language}
                path={`${modelPath}-solution`}
                value={selectedLesson.solution}
                beforeMount={registerLanguages}
                theme="vs-dark"
                options={{ ...editorOptions, readOnly: true }}
              />
            )}
            {editorMode === 'compare' && (
              <DiffEditor
                height="100%"
                originalLanguage={selectedLesson.language}
                modifiedLanguage={selectedLesson.language}
                originalModelPath={`${modelPath}-diff-solution`}
                modifiedModelPath={`${modelPath}-diff-attempt`}
                original={selectedLesson.solution}
                modified={currentCode}
                beforeMount={registerLanguages}
                theme="vs-dark"
                options={{ ...editorOptions, readOnly: true, renderSideBySide: true, originalEditable: false }}
              />
            )}
          </div>

          <div className={`review-console ${reviewOpen ? 'open' : ''}`}>
            <div className="review-console-bar">
              <div className="review-console-tabs">
                <button className={reviewTab === 'hint' ? 'active' : ''} onClick={() => { setReviewTab('hint'); setReviewOpen(true) }}>Hint</button>
                <button className={reviewTab === 'trap' ? 'active' : ''} onClick={() => { setReviewTab('trap'); setReviewOpen(true) }}>Common trap</button>
                <button className={reviewTab === 'note' ? 'active' : ''} onClick={() => { setReviewTab('note'); setReviewOpen(true) }}>Note</button>
              </div>
              <div className="review-console-right"><span>Draft saved locally</span><button onClick={() => setReviewOpen((v) => !v)}>{reviewOpen ? 'Collapse' : 'Open review'}</button></div>
            </div>
            {reviewOpen && (
              <div className="review-console-content">
                {reviewTab === 'hint' && (
                  <div className="console-hint"><Lightbulb size={16} /><div><strong>{hintCount ? `Hint ${hintCount}` : 'Need a hint?'}</strong><p>{hintCount ? selectedLesson.hints[Math.max(0, hintCount - 1)] : 'Try once from memory, then reveal the smallest useful clue.'}</p></div><button onClick={() => setHintCount((n) => Math.min(n + 1, selectedLesson.hints.length))} disabled={hintCount >= selectedLesson.hints.length}>Reveal next</button></div>
                )}
                {reviewTab === 'trap' && <div className="console-hint trap"><AlertTriangle size={16} /><div><strong>Common trap</strong><p>{selectedLesson.pitfall}</p></div></div>}
                {reviewTab === 'note' && <textarea value={notes[selectedLesson.id] ?? ''} onChange={(e) => setNotes((old) => ({ ...old, [selectedLesson.id]: e.target.value }))} placeholder="Write a short review note..." />}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  )
}

function SqlLabView({ mastered, flags, openSqlTopic, sqlDialect, setSqlDialect }) {
  const masteredCount = sqlChallenges.filter((item) => mastered.includes(item.id)).length
  const progress = Math.round((masteredCount / sqlChallenges.length) * 100)
  return (
    <div className="page sql-lab-page">
      <section className="page-intro sql-lab-hero">
        <Pill tone="accent">SEPARATE PRACTICE COLLECTION</Pill>
        <h1>SQL Dialect Lab</h1>
        <p>The 60 imported notebook challenges are preserved as a separate practice collection. Choose Microsoft T-SQL, DuckDB/source style, or BigQuery GoogleSQL, then attempt the problem before revealing the dialect-specific solution.</p>
        <div className="dialect-picker">
          {sqlDialects.map((dialect) => (
            <button key={dialect.id} className={sqlDialect === dialect.id ? 'active' : ''} onClick={() => setSqlDialect(dialect.id)}>
              <strong>{dialect.label}</strong><span>{dialect.short}</span>
            </button>
          ))}
        </div>
        <div className="sql-lab-summary">
          <div><strong>{sqlChallenges.length}</strong><span>challenges</span></div>
          <div><strong>{sqlChallengeTopics.length}</strong><span>source categories</span></div>
          <div><strong>3</strong><span>SQL dialect modes</span></div>
          <div><strong>{masteredCount}</strong><span>mastered</span></div>
          <div><strong>{progress}%</strong><span>complete</span></div>
        </div>
      </section>

      <section className="source-note lab-note">
        <Database size={18} />
        <div><strong>Why this is separate</strong><p>Your core drills teach syntax progressively. This lab preserves the harder uploaded packs and now lets you compare dialects without turning one syntax into the only “correct” answer. Drafts are saved separately per dialect.</p></div>
      </section>

      <div className="sql-topic-grid">
        {sqlChallengeTopics.map((topic) => {
          const items = sqlChallenges.filter((item) => item.track === topic.id)
          const done = items.filter((item) => mastered.includes(item.id)).length
          const flagged = items.filter((item) => flags.includes(item.id)).length
          return (
            <button className="sql-topic-card" key={topic.id} onClick={() => openSqlTopic(topic.id)}>
              <div className="sql-topic-top"><span className="sql-topic-icon">{topic.icon}</span><Pill>{items.length} problems</Pill></div>
              <h2>{topic.name}</h2>
              <p>{topic.description}</p>
              <div className="sql-topic-meta"><span>{done}/{items.length} mastered</span><span>{flagged ? `${flagged} flagged` : 'No flags'}</span></div>
              <div className="progress-line"><span style={{ width: `${items.length ? (done / items.length) * 100 : 0}%` }} /></div>
              <span className="sql-topic-open">Open challenge set <ArrowRight size={14} /></span>
            </button>
          )
        })}
      </div>
    </div>
  )
}


function EngineLabView({ mastered, flags, openTopic }) {
  const masteredCount = engineChallenges.filter((item) => mastered.includes(item.id)).length
  const progress = Math.round((masteredCount / engineChallenges.length) * 100)
  return (
    <div className="page sql-lab-page">
      <section className="page-intro sql-lab-hero">
        <Pill tone="accent">TRANSLATION PRACTICE</Pill>
        <h1>Multi-Engine Data Lab</h1>
        <p>Practice one data-engineering operation in several tools. Cross-engine problems can be switched between T-SQL, DuckDB, BigQuery, pandas, and PySpark; focused sections then teach engine-specific patterns that do not translate cleanly.</p>
        <div className="sql-lab-summary">
          <div><strong>{engineChallenges.length}</strong><span>challenges</span></div>
          <div><strong>5</strong><span>engines</span></div>
          <div><strong>{masteredCount}</strong><span>mastered</span></div>
          <div><strong>{progress}%</strong><span>complete</span></div>
        </div>
      </section>
      <section className="source-note lab-note">
        <Layers3 size={18} />
        <div><strong>How to use it</strong><p>Do a transformation first in the tool you know best. Then switch to another engine and write it again from memory. Your draft is saved separately for each engine.</p></div>
      </section>
      <div className="sql-topic-grid">
        {engineTopics.map((topic) => {
          const items = engineChallenges.filter((item) => item.track === topic.id)
          const done = items.filter((item) => mastered.includes(item.id)).length
          const flagged = items.filter((item) => flags.includes(item.id)).length
          return (
            <button className="sql-topic-card" key={topic.id} onClick={() => openTopic(topic.id)}>
              <div className="sql-topic-top"><span className="sql-topic-icon">{topic.icon}</span><Pill>{items.length} problems</Pill></div>
              <h2>{topic.name}</h2><p>{topic.description}</p>
              <div className="sql-topic-meta"><span>{done}/{items.length} mastered</span><span>{flagged ? `${flagged} flagged` : 'No flags'}</span></div>
              <div className="progress-line"><span style={{ width: `${items.length ? (done / items.length) * 100 : 0}%` }} /></div>
              <span className="sql-topic-open">Open engine set <ArrowRight size={14} /></span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function PythonLabView({ mastered, flags, openTopic }) {
  const masteredCount = pythonLabChallenges.filter((item) => mastered.includes(item.id)).length
  const progress = Math.round((masteredCount / pythonLabChallenges.length) * 100)
  return (
    <div className="page sql-lab-page">
      <section className="page-intro sql-lab-hero">
        <Pill tone="accent">SYNTAX MUSCLE MEMORY</Pill>
        <h1>Python Functions & Lambda Gym</h1>
        <p>Short blank-editor drills for the Python syntax that usually causes hesitation: functions, parameters vs arguments, return values, lists/dicts inside functions, lambda keys, comprehensions, enumerate/zip, generators, *args/**kwargs, and small pipeline utilities.</p>
        <div className="sql-lab-summary">
          <div><strong>{pythonLabChallenges.length}</strong><span>short drills</span></div>
          <div><strong>{pythonLabTopics.length}</strong><span>practice groups</span></div>
          <div><strong>{masteredCount}</strong><span>mastered</span></div>
          <div><strong>{progress}%</strong><span>complete</span></div>
        </div>
      </section>
      <section className="source-note lab-note">
        <Code2 size={18} />
        <div><strong>This is intentionally repetitive</strong><p>These are not “build a calculator” exercises. The examples use table names, metadata, configs, paths, validations, and pipeline-style helpers so basic Python becomes automatic in a data-engineering context.</p></div>
      </section>
      <div className="sql-topic-grid">
        {pythonLabTopics.map((topic) => {
          const items = pythonLabChallenges.filter((item) => item.track === topic.id)
          const done = items.filter((item) => mastered.includes(item.id)).length
          const flagged = items.filter((item) => flags.includes(item.id)).length
          return (
            <button className="sql-topic-card" key={topic.id} onClick={() => openTopic(topic.id)}>
              <div className="sql-topic-top"><span className="sql-topic-icon">{topic.icon}</span><Pill>{items.length} drills</Pill></div>
              <h2>{topic.name}</h2><p>{topic.description}</p>
              <div className="sql-topic-meta"><span>{done}/{items.length} mastered</span><span>{flagged ? `${flagged} flagged` : 'No flags'}</span></div>
              <div className="progress-line"><span style={{ width: `${items.length ? (done / items.length) * 100 : 0}%` }} /></div>
              <span className="sql-topic-open">Open syntax set <ArrowRight size={14} /></span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function PatternsView({ openLesson }) {
  return (
    <div className="page">
      <section className="page-intro">
        <Pill tone="accent">PATTERN BRIDGE</Pill>
        <h1>One data idea, several syntaxes.</h1>
        <p>The goal is to stop treating Python, SQL, pandas, PySpark, DAX, and C# as six unrelated worlds. The syntax changes; the underlying operation often does not.</p>
      </section>
      <div className="pattern-list">
        {patterns.map((pattern) => (
          <section className="pattern-card" key={pattern.title}>
            <div className="pattern-title"><div><span>TRANSFERABLE PATTERN</span><h2>{pattern.title}</h2><p>{pattern.idea}</p></div></div>
            <div className="pattern-code-grid">
              {pattern.examples.map(([label, language, code]) => (
                <div className="mini-code" key={label}>
                  <div className="mini-code-label">{label}</div>
                  <Editor height="150px" language={language} value={code} beforeMount={registerLanguages} theme="vs-dark" options={{ readOnly: true, minimap: { enabled: false }, lineNumbers: 'off', folding: false, fontSize: 12, wordWrap: 'on', scrollBeyondLastLine: false, automaticLayout: true, padding: { top: 10 } }} />
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
      <div className="callout">
        <div><strong>Recommended drill</strong><p>Do the T-SQL `ROW_NUMBER`, pandas dedupe, and PySpark Window exercises back-to-back. That is exactly the kind of translation fluency a data engineer needs.</p></div>
        <button className="primary" onClick={() => openLesson(lessons.find((l) => l.id === 'sql-row-number'))}>Open window drill <ArrowRight size={16} /></button>
      </div>
    </div>
  )
}

function FlaggedView({ items, openLesson }) {
  return (
    <div className="page">
      <section className="page-intro">
        <Pill tone="accent">REVIEW QUEUE</Pill>
        <h1>Flag the syntax that still breaks under pressure.</h1>
        <p>This list is stored in your browser. Use it as your personal weak-point queue rather than rereading every topic.</p>
      </section>
      {items.length === 0 ? (
        <div className="empty-state"><Flag size={28} /><h2>No flagged drills yet</h2><p>Flag a drill whenever you needed the solution or still cannot write it cleanly from memory.</p></div>
      ) : (
        <div className="review-grid">
          {items.map((lesson) => (
            <button key={lesson.id} className="review-card" onClick={() => openLesson(lesson)}>
              <div><Pill tone={lesson.level.toLowerCase()}>{lesson.level}</Pill><Pill>{lesson.collection === 'engine-lab' ? 'Multi-engine' : (languageLabels[lesson.language] ?? lesson.language)}</Pill>{lesson.collection === 'sql-lab' && <Pill tone="accent">SQL Lab</Pill>}{lesson.collection === 'engine-lab' && <Pill tone="accent">Engine Lab</Pill>}{lesson.collection === 'python-lab' && <Pill tone="accent">Python Gym</Pill>}</div>
              <h3>{lesson.title}</h3><p>{lesson.task}</p><span>Practice again <ArrowRight size={14} /></span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function SourcesView() {
  return (
    <div className="page">
      <section className="page-intro">
        <Pill tone="accent">REFERENCE BASE</Pill>
        <h1>Official documentation behind the curriculum.</h1>
        <p>Use this trainer to build recall; use vendor/project documentation when you need exact flags, version-specific behavior, or production constraints.</p>
      </section>
      <div className="sources-grid">
        {sourceLinks.map((source) => (
          <a className="source-card" href={source.url} key={source.url} target="_blank" rel="noreferrer">
            <div><BookOpen size={18} /><strong>{source.label}</strong></div>
            <p>{source.note}</p>
            <span>Open documentation <ExternalLink size={14} /></span>
          </a>
        ))}
      </div>
      <section className="source-note">
        <AlertTriangle size={18} />
        <div><strong>Version-sensitive areas</strong><p>Airflow authoring APIs, cloud CLIs, Fabric CLI, gateway requirements, Docker/Kubernetes flags, and vendor product behavior can evolve. The course focuses on stable mental models and common current syntax, but production work should always check the relevant official docs.</p></div>
      </section>
    </div>
  )
}

export default App
