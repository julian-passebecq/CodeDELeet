import { lessons } from './curriculum.js'

const diagrams = {
  'cdc-log-vs-polling': `architecture-beta
    service db(database)[OLTP database]
    service log(disk)[Transaction log]
    service cdc(server)[CDC connector]
    service stream(server)[Change stream]
    service lake(database)[Lakehouse]
    service offset(disk)[Connector offset]

    db:R --> L:log
    log:R --> L:cdc
    cdc:R --> L:stream
    stream:R --> L:lake
    offset:T --> B:cdc`,

  'cdc-envelope-upsert-delete': `architecture-beta
    service db(database)[OLTP database]
    service log(disk)[Transaction log]
    service cdc(server)[CDC connector]
    service stream(server)[Change envelopes]
    service sink(database)[Upsert / delete sink]
    service offset(disk)[Source position]

    db:R --> L:log
    log:R --> L:cdc
    cdc:R --> L:stream
    stream:R --> L:sink
    offset:T --> B:cdc`,

  'fabric-mirroring-vs-etl': `architecture-beta
    service source(database)[Operational source]
    service mirror(server)[Fabric Mirroring]
    service onelake(disk)[OneLake Delta]
    service sql(database)[SQL endpoint]
    service spark(server)[Spark / Lakehouse]
    service bi(server)[Power BI / consumers]

    source:R --> L:mirror
    mirror:R --> L:onelake
    onelake:R --> L:sql
    onelake:B --> T:spark
    sql:B --> T:bi`,

  'fabric-mirroring-troubleshoot': `architecture-beta
    service source(database)[Source changes]
    service replication(server)[Replication status]
    service onelake(disk)[OneLake Delta]
    service sql(database)[SQL metadata]
    service consumer(server)[Consumer query]

    source:R --> L:replication
    replication:R --> L:onelake
    onelake:R --> L:sql
    sql:R --> L:consumer`,

  'modern-format-table-engine-catalog': `architecture-beta
    service files(disk)[Parquet / Avro / JSON]
    service table(database)[Delta / Iceberg table]
    service catalog(server)[Catalog / metadata]
    service engine(server)[DuckDB / Spark engine]

    files:R --> L:table
    catalog:B --> T:table
    table:R --> L:engine`,

  'lineage-impact-debugging': `architecture-beta
    service raw(database)[raw.customer_status]
    service spark(server)[Spark transform]
    service silver(database)[silver.customer]
    service dbt(server)[dbt model]
    service dim(database)[dim_customer]
    service bi(server)[BI consumer]
    service lineage(server)[OpenLineage backend]
    service impact(server)[Impact / replay scope]

    raw:R --> L:spark
    spark:R --> L:silver
    silver:R --> L:dbt
    dbt:R --> L:dim
    dim:R --> L:bi
    spark:B --> T:lineage
    dbt:B --> T:lineage
    lineage:R --> L:impact`,

  'ae-dbt-revenue-mart': `architecture-beta
    service logs(disk)[Raw access logs]
    service products(database)[Product catalog]
    service staging(server)[dbt staging]
    service facts(database)[Event facts]
    service mart(database)[Daily revenue mart]
    service bi(server)[BI / analysis]

    logs:R --> L:staging
    products:B --> T:staging
    staging:R --> L:facts
    facts:R --> L:mart
    products:R --> L:mart
    mart:R --> L:bi`,

  'ae-spark-delta-merge': `architecture-beta
    service bronze(disk)[Bronze events]
    service spark(server)[PySpark transform]
    service silver(database)[Silver Delta]
    service merge(server)[MERGE by business key]
    service gold(database)[Gold Delta mart]

    bronze:R --> L:spark
    spark:R --> L:silver
    silver:R --> L:merge
    merge:R --> L:gold`,
}

for (const [id, diagram] of Object.entries(diagrams)) {
  const lesson = lessons.find((item) => item.id === id)
  if (lesson) lesson.diagram = diagram
}

export { diagrams as architectureVisualDiagrams }
