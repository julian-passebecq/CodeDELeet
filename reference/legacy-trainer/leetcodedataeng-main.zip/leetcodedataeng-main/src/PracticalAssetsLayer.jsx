import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { lessons } from './curriculum'

function ensureMount() {
  const description = document.querySelector('.problem-description')
  if (!description) return null
  let mount = description.querySelector(':scope > .practical-assets-mount')
  if (!mount) {
    mount = document.createElement('div')
    mount.className = 'practical-assets-mount'
    const context = description.querySelector('.problem-context')
    if (context) context.insertAdjacentElement('afterend', mount)
    else description.querySelector('.problem-meta')?.insertAdjacentElement('afterend', mount)
  }
  return mount
}

function AssetCard({ lesson }) {
  if (lesson.track !== 'analytics-engineering') return null
  return (
    <section className="practical-assets-card">
      <div><span>LAB FILES</span><strong>Concrete local sample data</strong><small>Small trainer sample; use the generator from the original TD when you want larger volumes.</small></div>
      <div className="practical-assets-links">
        <a href="/labs/ecommerce/access.log" target="_blank" rel="noreferrer">access.log</a>
        <a href="/labs/ecommerce/products.csv" target="_blank" rel="noreferrer">products.csv</a>
      </div>
    </section>
  )
}

export default function PracticalAssetsLayer() {
  const [mount, setMount] = useState(null)
  const [lesson, setLesson] = useState(null)

  useEffect(() => {
    const sync = () => {
      const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
      const current = lessons.find((item) => item.title === title && item.track === 'analytics-engineering')
      if (!current) {
        setLesson(null)
        setMount(null)
        return
      }
      setLesson(current)
      setMount(ensureMount())
    }
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [])

  return mount && lesson ? createPortal(<AssetCard lesson={lesson} />, mount) : null
}
