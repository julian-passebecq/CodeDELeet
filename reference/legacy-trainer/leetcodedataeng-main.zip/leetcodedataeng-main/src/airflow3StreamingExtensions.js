import { lessons } from './curriculum.js'
import { cheatSheets } from './cheatSheets.js'
import { hubExtensions } from './learningHubContent.js'

const OFFICIAL = {
  airflowPublic: { label: 'Apache Airflow · public interface', url: 'https://airflow.apache.org/docs/apache-airflow/stable/public-airflow-interface.html' },
  airflowAssets: { label: 'Apache Airflow · asset scheduling', url: 'https://airflow.apache.org/docs/apache-airflow/stable/authoring-and-scheduling/asset-scheduling.html' },
  airflowUpgrade: { label: 'Apache Airflow · upgrade to Airflow 3', url: 'https://airflow.apache.org/docs/apache-airflow/stable/installation/upgrading_to_airflow3.html' },
  sparkStreaming: { label: 'Apache Spark · Structured Streaming', url: 'https://spark.apache.org/docs/latest/streaming/apis-on-dataframes-and-datasets.html' },
  sparkState: { label: 'Apache Spark · streaming state data source', url: 'https://spark.apache.org/docs/latest/streaming/structured-streaming-state-data-source.html' },
}

const airflow3Diagram = `flowchart LR
  D[Dag file / Task SDK] --> P[Dag processor]
  P --> M[(Metadata DB)]
  S[Scheduler] --> M
  S --> E[Executor / workers]
  E --> T[Task code]
  A[API server] --> M
  T --> X[Data systems]
  X --> AS[Asset update]
  AS --> S`

const streamingDiagram = `flowchart LR
  SRC[Streaming source] --> MB[Micro-batches]
  MB --> ET[Event-time transforms]
  ET --> WM[Watermark / bounded state]
  WM --> SNK[Sink]
  MB --> CP[(Checkpoint: offsets + state)]
  CP --> R[Restart / recovery]
  R --> MB`

const joinDiagram = `flowchart LR
  L[Orders stream] --> LW[Watermark orders event time]
  R[Payments stream] --> RW[Watermark payments event time]
  LW --> J[Join key + event-time range]
  RW --> J
  J --> O[Matched output]
  LW -. old unmatched state .-> C[State cleanup]
  RW -. old unmatched state .-> C`

const W = (x) => ({ sourcePack: 'Web verified · Airflow 3 + Spark Structured Streaming · Sep 2026', ...x })

export const airflow3StreamingLessons = [
  W({
    id: 'af3-task-sdk', track: 'airflow', level: 'Intermediate', language: 'python', title: 'Airflow 3: author DAGs through airflow.sdk',
    concept: 'Airflow 3 exposes the supported DAG-authoring interface through airflow.sdk; legacy internal/decorator import paths are deprecated.',
    why: 'Interview and production examples should teach the public API rather than an import path already on the migration path out.',
    context: 'Modernize an older TaskFlow DAG that imports dag/task from airflow.decorators.',
    task: 'Rewrite the imports and create a daily TaskFlow DAG with an idempotent extract task and retries.',
    starter: `from airflow.decorators import dag, task\nfrom datetime import datetime\n\n@dag(schedule='0 6 * * *', start_date=datetime(2026, 1, 1), catchup=False)\ndef sales_pipeline():\n    @task(retries=2)\n    def extract():\n        return 'landing/sales'\n    extract()\n\nsales_pipeline()`,
    solution: `from airflow.sdk import dag, task\nimport pendulum\n\n@dag(\n    schedule='0 6 * * *',\n    start_date=pendulum.datetime(2026, 1, 1, tz='UTC'),\n    catchup=False,\n)\ndef sales_pipeline():\n    @task(retries=2)\n    def extract():\n        return 'landing/sales'\n\n    extract()\n\nsales_pipeline()`,
    hints: ['Airflow 3 DAG authors should prefer airflow.sdk.', 'Use a timezone-aware start date.'],
    pitfall: 'Do not treat every old import as instantly broken: many legacy imports are deprecated first, but new trainer code should target the public SDK.',
    officialSources: [OFFICIAL.airflowPublic, OFFICIAL.airflowUpgrade],
  }),
  W({
    id: 'af3-asset-scheduling', track: 'airflow', level: 'Intermediate', language: 'python', title: 'Airflow 3: schedule a DAG from an Asset',
    concept: 'Airflow Assets model logical data dependencies. In Airflow 3 the concept previously called Dataset is named Asset.',
    why: 'Data-aware scheduling can express producer/consumer dependencies without hard-coding a clock time between pipelines.',
    context: 'A consumer DAG should run after the logical silver orders asset is updated successfully.',
    task: 'Declare an Asset and use it as the consumer DAG schedule.',
    starter: `from airflow.sdk import Asset, DAG\nimport pendulum\n\norders_ready = #(\"s3://lake/silver/orders\")\n\nwith DAG(\n    dag_id='orders_consumer',\n    schedule=#,\n    start_date=pendulum.datetime(2026, 1, 1, tz='UTC'),\n    catchup=False,\n):\n    ...`,
    solution: `from airflow.sdk import Asset, DAG\nimport pendulum\n\norders_ready = Asset('s3://lake/silver/orders')\n\nwith DAG(\n    dag_id='orders_consumer',\n    schedule=[orders_ready],\n    start_date=pendulum.datetime(2026, 1, 1, tz='UTC'),\n    catchup=False,\n):\n    ...`,
    hints: ['The Airflow 3 name is Asset.', 'Asset schedules are lists of Asset objects.'],
    pitfall: 'An Asset URI is a logical identifier, not a glob pattern or a promise that Airflow understands the underlying file contents.',
    diagram: `flowchart LR\n  P[Producer task succeeds] --> A[Asset updated]\n  A --> S[Scheduler sees asset event]\n  S --> C[Consumer DAG run]`,
    officialSources: [OFFICIAL.airflowAssets, OFFICIAL.airflowPublic],
  }),
  W({
    id: 'af3-upgrade-map', track: 'airflow', level: 'Expert', language: 'plaintext', title: 'Airflow 2 → 3: map the breaking concepts',
    concept: 'Airflow 3 changes both authoring interfaces and deployment architecture: Task SDK/public imports, Assets, API server, independent DAG processor and API v2 are key examples.',
    why: 'Senior orchestration troubleshooting requires knowing whether a failure is DAG logic, migration compatibility or platform architecture.',
    context: 'You inherit an Airflow 2.x deployment that uses airflow.decorators, Dataset, the webserver command, REST /api/v1 and SLA callbacks.',
    task: 'Map each legacy concept to its Airflow 3 direction and list the migration checks you would run before upgrading.',
    starter: 'airflow.decorators →\nDataset →\nwebserver →\nREST /api/v1 →\nSLA →\n\nPRE-UPGRADE CHECKS:\n1.\n2.\n3.',
    solution: 'airflow.decorators / internal authoring imports → airflow.sdk public interface\nDataset → Asset\nwebserver process → api-server\nREST /api/v1 → stable /api/v2\nSLA → Deadline Alerts\n\nPRE-UPGRADE CHECKS:\n1. Upgrade to a supported recent 2.x baseline (Airflow docs require at least 2.7 before Airflow 3).\n2. Back up and clean the metadata DB, then validate DAG serialization.\n3. Run the Airflow/Ruff migration checks and review removed/deprecated features before DB migration.\n4. Plan the independently running dag-processor and API-server components.',
    hints: ['Separate DAG-source migration from deployment-component migration.', 'A database backup is part of the upgrade plan, not an optional afterthought.'],
    pitfall: 'Do not perform a major Airflow upgrade as a blind pip install while the metadata DB and DAG compatibility are unverified.',
    diagram: airflow3Diagram,
    officialSources: [OFFICIAL.airflowUpgrade, OFFICIAL.airflowPublic],
  }),
  W({
    id: 'stream-watermark-window', track: 'pyspark', level: 'Intermediate', language: 'python', title: 'Structured Streaming: bound state with an event-time watermark',
    concept: 'Watermarks tell Structured Streaming how late event-time data may arrive so stateful operations can eventually retire old state.',
    why: 'Without a bounded state strategy, long-running aggregations can retain increasingly large state and become slow or unstable.',
    context: 'events contains event_time, customer_id and amount. Compute 10-minute revenue windows while allowing events up to 20 minutes late.',
    task: 'Add a watermark and windowed aggregation.',
    starter: `from pyspark.sql import functions as F\n\nsummary = (events\n    .#('event_time', '20 minutes')\n    .groupBy(#)\n    .agg(F.sum('amount').alias('revenue'))\n)`,
    solution: `from pyspark.sql import functions as F\n\nsummary = (events\n    .withWatermark('event_time', '20 minutes')\n    .groupBy(\n        F.window('event_time', '10 minutes'),\n        F.col('customer_id'),\n    )\n    .agg(F.sum('amount').alias('revenue'))\n)`,
    hints: ['Use withWatermark before the stateful aggregation.', 'Window on the same event-time column.'],
    pitfall: 'A watermark is not a business SLA or ingestion-time timeout; it is part of event-time/state management.',
    diagram: streamingDiagram,
    officialSources: [OFFICIAL.sparkStreaming],
  }),
  W({
    id: 'stream-checkpoint-recovery', track: 'pyspark', level: 'Intermediate', language: 'python', title: 'Structured Streaming: recover from a durable checkpoint',
    concept: 'Structured Streaming stores progress and state in the configured checkpoint so a compatible query can continue after a failure/restart.',
    why: 'A production stream needs a recovery contract, not just a writeStream.start() call.',
    context: 'Write curated orders to a table and recover offsets/state after a driver restart.',
    task: 'Configure a durable checkpoint location on the streaming writer.',
    starter: `(curated.writeStream\n    .outputMode('append')\n    .option(#, #)\n    .toTable('silver.orders_stream'))`,
    solution: `(curated.writeStream\n    .outputMode('append')\n    .option('checkpointLocation', 'abfss://checkpoints/orders_stream')\n    .toTable('silver.orders_stream'))`,
    hints: ['checkpointLocation belongs on the streaming writer.', 'Use storage that survives the driver/process.'],
    pitfall: 'Deleting a checkpoint to make an error disappear changes recovery semantics and can cause reprocessing or lost state.',
    diagram: streamingDiagram,
    officialSources: [OFFICIAL.sparkStreaming],
  }),
  W({
    id: 'stream-foreachbatch-idempotent', track: 'pyspark', level: 'Expert', language: 'python', title: 'Structured Streaming: make foreachBatch writes idempotent',
    concept: 'foreachBatch gives custom logic per micro-batch and is at-least-once by default; the batch ID can be used to deduplicate output when the sink supports that design.',
    why: 'A retry can execute a micro-batch write again, so external side effects need their own idempotency contract.',
    context: 'Each micro-batch is sent to a custom sink that records processed batch IDs.',
    task: 'Use batch_id to skip an already committed micro-batch.',
    starter: `def write_batch(batch_df, batch_id):\n    if #:\n        return\n    write_to_sink(batch_df)\n    #\n\nquery = (events.writeStream\n    .foreachBatch(write_batch)\n    .option('checkpointLocation', 'abfss://checkpoints/custom_sink')\n    .start())`,
    solution: `def write_batch(batch_df, batch_id):\n    if sink_has_batch(batch_id):\n        return\n\n    write_to_sink(batch_df)\n    mark_batch_committed(batch_id)\n\nquery = (events.writeStream\n    .foreachBatch(write_batch)\n    .option('checkpointLocation', 'abfss://checkpoints/custom_sink')\n    .start())\n\n# In a real sink, commit the data + batch marker atomically/transactionally when possible.`,
    hints: ['Spark passes a unique micro-batch ID to foreachBatch.', 'The sink must make the dedupe check and commit reliable.'],
    pitfall: 'Checkpointing alone does not magically make arbitrary external foreachBatch side effects exactly-once.',
    officialSources: [OFFICIAL.sparkStreaming],
  }),
  W({
    id: 'stream-stream-join-watermarks', track: 'pyspark', level: 'Expert', language: 'python', title: 'Structured Streaming: bound a stream-stream join',
    concept: 'Stateful stream-stream joins need event-time constraints and watermarks so Spark can determine when old join state no longer needs to be retained.',
    why: 'An unbounded join can accumulate state indefinitely while waiting for a matching event that may never arrive.',
    context: 'Join orders to payments on order_id. A payment may arrive up to one hour after its order.',
    task: 'Watermark both streams and add a one-hour event-time range to the join condition.',
    starter: `from pyspark.sql import functions as F\n\no = orders.#('order_time', '2 hours').alias('o')\np = payments.#('payment_time', '2 hours').alias('p')\n\njoined = o.join(p, #, 'inner')`,
    solution: `from pyspark.sql import functions as F\n\no = orders.withWatermark('order_time', '2 hours').alias('o')\np = payments.withWatermark('payment_time', '2 hours').alias('p')\n\njoined = o.join(\n    p,\n    F.expr(\n        "o.order_id = p.order_id AND "\n        "p.payment_time >= o.order_time AND "\n        "p.payment_time <= o.order_time + INTERVAL 1 HOUR"\n    ),\n    'inner',\n)`,
    hints: ['Both event-time streams need watermarks for bounded state reasoning.', 'The join condition needs an event-time range, not only the business key.'],
    pitfall: 'A watermark on one stream plus an equality key alone is not a complete state-cleanup strategy for this join.',
    diagram: joinDiagram,
    officialSources: [OFFICIAL.sparkStreaming],
  }),
  W({
    id: 'stream-checkpoint-evolution', track: 'pyspark', level: 'Expert', language: 'plaintext', title: 'Structured Streaming: know when a checkpoint cannot be reused',
    concept: 'Checkpoint state encodes assumptions about sources and stateful operators. Some query changes are incompatible with restarting from the same checkpoint.',
    why: 'A common production incident is deploying a seemingly harmless streaming-code change that conflicts with persisted state.',
    context: 'A running query groups by customer_id and day. A release changes grouping keys and the state schema but points to the old checkpoint.',
    task: 'Decide whether to reuse the checkpoint and design a safe migration plan.',
    starter: 'REUSE OLD CHECKPOINT?\n\nWHY:\n\nSAFE MIGRATION:\n1.\n2.\n3.',
    solution: 'REUSE OLD CHECKPOINT?\n- No, not blindly for an incompatible stateful-operator/schema change.\n\nWHY:\n- The checkpoint contains persisted progress and state whose schema/partitioning must remain compatible with the restarted query.\n\nSAFE MIGRATION:\n1. Read the Spark recovery compatibility rules for the exact change.\n2. Deploy a new query/checkpoint when state is incompatible, with an explicit cutover/replay boundary.\n3. Reconcile old/new outputs before retiring the previous query.\n4. Keep the old checkpoint until rollback risk has passed.',
    hints: ['Stateful grouping/aggregate schema changes are particularly sensitive.', 'Treat a new checkpoint as a data migration/cutover, not a cache clear.'],
    pitfall: 'Never delete production streaming state as the first troubleshooting step just because the restarted query fails.',
    diagram: streamingDiagram,
    officialSources: [OFFICIAL.sparkStreaming, OFFICIAL.sparkState],
  }),
]

const existingIds = new Set(lessons.map((item) => item.id))
for (const lesson of airflow3StreamingLessons) if (!existingIds.has(lesson.id)) lessons.push(lesson)

const airflow = cheatSheets.find((item) => item.id === 'airflow')
if (airflow) {
  airflow.subtitle = 'Airflow 3 DAG scheduling, Assets and orchestration'
  airflow.useFor = ['pipeline scheduling', 'task dependencies', 'Assets/data-aware scheduling', 'retries', 'backfills and orchestration']

  const replaceSection = (title, content) => {
    const index = airflow.sections.findIndex(([existing]) => existing === title)
    if (index >= 0) airflow.sections[index] = [title, content]
    else airflow.sections.push([title, content])
  }

  replaceSection('TaskFlow DAG', `from airflow.sdk import dag, task\nimport pendulum\n\n@dag(\n    schedule='0 6 * * *',\n    start_date=pendulum.datetime(2026, 1, 1, tz='UTC'),\n    catchup=False,\n)\ndef sales_pipeline():\n    @task(retries=2)\n    def extract():\n        return 'landing/sales'\n    extract()\n\nsales_pipeline()`)
  replaceSection('Airflow 3 Assets', `from airflow.sdk import Asset, DAG\n\norders_ready = Asset('s3://lake/silver/orders')\n\nwith DAG(\n    dag_id='consumer',\n    schedule=[orders_ready],\n    ...,\n):\n    ...\n\n# Airflow 2 "Dataset" terminology became "Asset" in Airflow 3.`)
  replaceSection('Airflow 3 architecture', 'Dag authoring → airflow.sdk public interface\nDag parsing → independent dag-processor\nScheduling → scheduler\nUI/API → api-server\nExecution → executor/workers\nData dependency → Asset events')

  airflow.starter = `from airflow.sdk import dag, task\nimport pendulum\n\n# Build extract -> transform -> load with retries on load\n`

  for (const model of [
    'Airflow 3 DAG authors should target airflow.sdk, the documented public Task SDK interface.',
    'Asset events model logical data dependencies; Airflow orchestrates metadata/events rather than moving the dataset itself.',
    'Airflow 3 separates DAG processing and API serving more explicitly, so queued/parsing/UI incidents are different failure classes.',
  ]) if (!airflow.mentalModels.includes(model)) airflow.mentalModels.push(model)

  for (const topic of ['airflow.sdk public interface', 'Dataset → Asset migration', 'Airflow 3 api-server + dag-processor architecture']) {
    if (!airflow.interview.includes(topic)) airflow.interview.push(topic)
  }
}

const sparkHub = hubExtensions.pyspark
if (sparkHub) {
  const addPattern = (title, description) => {
    if (!sparkHub.algorithms.some(([existing]) => existing === title)) sparkHub.algorithms.push([title, description])
  }
  addPattern('Event time + watermark', 'Bound long-running streaming state using event-time semantics rather than processing-time guesses.')
  addPattern('Checkpoint + idempotent sink', 'Checkpoint offsets/state for recovery, then separately make custom sink side effects retry-safe.')

  const addInterview = (card) => {
    if (!sparkHub.interviewCards.some(([existing]) => existing === card[0])) sparkHub.interviewCards.push(card)
  }
  addInterview(['Watermark vs checkpoint', 'A watermark bounds event-time state; a checkpoint persists streaming progress/state for recovery. They solve different problems.', "events.withWatermark('event_time', '20 minutes')\n\nevents.writeStream.option('checkpointLocation', path)", 'If a stream is checkpointed, why might you still need a watermark?', 'Checkpointing makes progress/state recoverable; it does not decide how long stateful event-time operators should retain old keys/windows.', 'Design recovery and state-retention settings for a late-event aggregation.'])
  addInterview(['foreachBatch semantics', 'foreachBatch is custom micro-batch output logic and is at-least-once by default; use batch ID plus sink-side idempotency/transactions when exactly-once effects are required.', 'def write_batch(df, batch_id):\n    ...', 'Does checkpointLocation make an arbitrary REST call in foreachBatch exactly-once?', 'No. Spark can replay a micro-batch. The external side effect needs its own idempotency key/transaction/deduplication contract.', 'Design a retry-safe foreachBatch sink.'])
}
