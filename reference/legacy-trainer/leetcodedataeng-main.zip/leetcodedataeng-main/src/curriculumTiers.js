export const CORE_TRACK_ORDER = [
  'foundations',
  'algorithms',
  'python',
  'pandas',
  'sql',
  'storage-performance',
  'pyspark',
  'pipeline-troubleshooting',
  'analytics-engineering',
  'seniority',
  'dax',
]

export const SUPPORTING_TRACK_ORDER = [
  'airflow',
  'git',
  'cloud',
  'powershell',
  'bash',
  'cron',
  'csharp',
  'gateway',
]

export const OPTIONAL_TRACK_ORDER = [
  'docker',
  'kubernetes',
  'mlops-practical',
  'nosql-optional',
  'genai-optional',
]

export const CORE_TRACK_IDS = new Set(CORE_TRACK_ORDER)
export const SUPPORTING_TRACK_IDS = new Set(SUPPORTING_TRACK_ORDER)
export const OPTIONAL_TRACK_IDS = new Set(OPTIONAL_TRACK_ORDER)

export const TIER_META = {
  core: {
    label: 'CORE PATH',
    heading: 'Build these first',
    description: 'Primary interview and production data-engineering skills.',
  },
  supporting: {
    label: 'SUPPORTING TOOLS',
    heading: 'Useful around the core stack',
    description: 'Useful operator, orchestration and BI-adjacent tooling.',
  },
  optional: {
    label: 'OPTIONAL BREADTH',
    heading: 'Explore after the core path',
    description: 'Keep available without competing with the core path.',
  },
}

export function tierForTrack(track) {
  if (!track) return 'supporting'
  if (CORE_TRACK_IDS.has(track.id)) return 'core'
  if (OPTIONAL_TRACK_IDS.has(track.id)) return 'optional'
  if (SUPPORTING_TRACK_IDS.has(track.id)) return 'supporting'
  if (track.short?.includes('Optional') || track.name?.startsWith('Optional —')) return 'optional'
  return 'supporting'
}

export function orderForTrack(track, allTracks = []) {
  const tier = tierForTrack(track)
  const preferred = tier === 'core' ? CORE_TRACK_ORDER : tier === 'optional' ? OPTIONAL_TRACK_ORDER : SUPPORTING_TRACK_ORDER
  const preferredIndex = preferred.indexOf(track.id)
  if (preferredIndex >= 0) return preferredIndex
  const fallbackIndex = allTracks.findIndex((item) => item.id === track.id)
  return preferred.length + Math.max(0, fallbackIndex)
}

export function isCoreTrackId(id) {
  return CORE_TRACK_IDS.has(id)
}
