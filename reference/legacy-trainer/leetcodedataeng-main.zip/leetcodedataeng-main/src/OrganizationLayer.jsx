import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { ChevronRight } from 'lucide-react'
import { lessons, tracks } from './curriculum'
import {
  CORE_TRACK_IDS,
  OPTIONAL_TRACK_IDS,
  TIER_META,
  orderForTrack,
  tierForTrack,
} from './curriculumTiers'

function groupedTracks() {
  return ['core', 'supporting', 'optional'].map((tier) => ({
    tier,
    ...TIER_META[tier],
    tracks: tracks.filter((track) => tierForTrack(track) === tier).sort((a, b) => orderForTrack(a, tracks) - orderForTrack(b, tracks)),
  }))
}

function ensureMount(parent, className, before = null) {
  if (!parent) return null
  let mount = parent.querySelector(`:scope > .${className}`)
  if (!mount) {
    mount = document.createElement('div')
    mount.className = className
    if (before) parent.insertBefore(mount, before)
    else parent.appendChild(mount)
  }
  return mount
}

function clickTrack(short) {
  const button = [...document.querySelectorAll('.track-nav > button')]
    .find((node) => node.querySelector('strong')?.textContent?.trim() === short)
  if (button instanceof HTMLElement) button.click()
}

function OrganizedFullCurriculum({ groups }) {
  return (
    <div className="organized-full-curriculum">
      {groups.map((group) => (
        <section className={`organized-curriculum-group ${group.tier}`} key={group.tier}>
          <div className="organized-curriculum-heading">
            <div><span>{group.label}</span><h3>{group.heading}</h3></div>
            <p>{group.description}</p>
          </div>
          <div className="organized-curriculum-grid">
            {group.tracks.map((track) => {
              const count = lessons.filter((lesson) => lesson.track === track.id).length
              return (
                <button key={track.id} onClick={() => clickTrack(track.short)}>
                  <span className="full-curriculum-icon">{track.icon}</span>
                  <div><strong>{track.name}</strong><small>{count} drills</small><p>{track.description}</p></div>
                  <ChevronRight size={14} />
                </button>
              )
            })}
          </div>
        </section>
      ))}
    </div>
  )
}

export default function OrganizationLayer() {
  const groups = useMemo(() => groupedTracks(), [])
  const [curriculumMount, setCurriculumMount] = useState(null)

  useEffect(() => {
    document.body.classList.add('organization-ready')
    let frame = 0

    const sync = () => {
      const sidebar = document.querySelector('.sidebar')
      const brand = sidebar?.querySelector('.brand')
      if (brand instanceof HTMLElement && brand.title !== 'Home') brand.title = 'Home'

      const dashboard = [...(sidebar?.querySelectorAll('.main-nav > button') ?? [])]
        .find((button) => button.textContent?.replace(/\s+/g, ' ').trim().startsWith('Dashboard'))
      dashboard?.classList.add('organization-home-duplicate')

      const fullGrid = document.querySelector('.full-curriculum-grid')
      const fullSection = fullGrid?.closest('.full-curriculum-section') ?? null
      const mount = ensureMount(fullSection, 'organized-curriculum-mount', fullGrid)
      if (mount && fullGrid) fullGrid.classList.add('organization-source-hidden')
      setCurriculumMount((current) => current === mount ? current : mount)
    }

    const scheduleSync = () => {
      if (frame) return
      frame = window.requestAnimationFrame(() => {
        frame = 0
        sync()
      })
    }

    sync()
    const observer = new MutationObserver(scheduleSync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => {
      observer.disconnect()
      if (frame) window.cancelAnimationFrame(frame)
      document.body.classList.remove('organization-ready')
    }
  }, [])

  return curriculumMount ? createPortal(<OrganizedFullCurriculum groups={groups} />, curriculumMount) : null
}

export { CORE_TRACK_IDS, OPTIONAL_TRACK_IDS, tierForTrack }
