import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { ArrowRight, BookOpen, Boxes, CheckCircle2, Code2, Database, Flag, GraduationCap, Layers3, Sparkles, TrendingUp } from 'lucide-react'
import TechnologyMark from './TechnologyMark'
import { lessons } from './curriculum'
import { sqlChallenges } from './sqlChallenges'
import { engineChallenges } from './engineLab'
import { pythonLabChallenges } from './pythonLab'
import { CORE_TRACK_IDS } from './curriculumTiers'
import { STORAGE_PREFIX } from './progressBackup'

function readStoredValue(key, fallback) {
  try {
    const raw = localStorage.getItem(`${STORAGE_PREFIX}:${key}`)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

function clickMatchingButton(selector, text) {
  const button = [...document.querySelectorAll(selector)].find((item) => item.textContent?.replace(/\s+/g, ' ').includes(text))
  if (button instanceof HTMLElement) {
    button.click()
    window.scrollTo({ top: 0, behavior: 'instant' })
    return true
  }
  return false
}

function openCoreTrack(shortLabel) {
  clickMatchingButton('.track-nav button', shortLabel)
}

function openLab(label) {
  clickMatchingButton('.main-nav button', label)
}

function openLearningHub(label) {
  if (clickMatchingButton('.learning-extra-nav button', label)) return
  clickMatchingButton('.reference-nav button', label)
}

function ModeCard({ icon, eyebrow, title, description, detail, action, onClick, primary = false }) {
  return (
    <button className={`simple-mode-card ${primary ? 'primary-mode' : ''}`} onClick={onClick}>
      <div className="simple-mode-icon">{icon}</div>
      <div className="simple-mode-copy">
        <span>{eyebrow}</span>
        <h2>{title}</h2>
        <p>{description}</p>
        <small>{detail}</small>
      </div>
      <div className="simple-mode-action">{action} <ArrowRight size={15} /></div>
    </button>
  )
}

function FocusCard({ label, title, text, onClick, optional = false }) {
  return (
    <button className={`focus-card ${optional ? 'optional-focus-card' : ''}`} onClick={onClick}>
      <div className="focus-card-head">
        <TechnologyMark label={title} className="focus-card-icon" />
        <span className="focus-card-eyebrow">{label}</span>
      </div>
      <strong>{title}</strong>
      <p>{text}</p>
      <ArrowRight size={14} />
    </button>
  )
}

export default function FrontPageGuide() {
  const [homeRoot, setHomeRoot] = useState(null)

  useEffect(() => {
    let frame = 0
    const sync = () => {
      const next = document.querySelector('.home-page')
      setHomeRoot((current) => current === next ? current : next)
    }
    const scheduleSync = () => {
      if (frame) return
      frame = window.requestAnimationFrame(() => {
        frame = 0
        sync()
      })
    }
    sync()
    const observer = new MutationObserver(scheduleSync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => {
      observer.disconnect()
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  useEffect(() => {
    if (!homeRoot) return undefined
    homeRoot.classList.add('home-simplified')
    return () => homeRoot.classList.remove('home-simplified')
  }, [homeRoot])

  const progress = useMemo(() => {
    if (!homeRoot) return null
    const mastered = readStoredValue('mastered', [])
    const flags = readStoredValue('flags', [])
    const drafts = readStoredValue('drafts', {})
    const coreLessons = lessons.filter((lesson) => CORE_TRACK_IDS.has(lesson.track))
    const validCoreIds = new Set(coreLessons.map((lesson) => lesson.id))
    const coreMastered = mastered.filter((id) => validCoreIds.has(id)).length
    return {
      coreMastered,
      coreTotal: coreLessons.length,
      corePercent: Math.round((coreMastered / Math.max(coreLessons.length, 1)) * 100),
      flags: flags.length,
      drafts: Object.keys(drafts).length,
    }
  }, [homeRoot])

  if (!homeRoot || !progress) return null

  const algorithmCount = lessons.filter((lesson) => lesson.track === 'algorithms').length
  const seniorityCount = lessons.filter((lesson) => lesson.track === 'seniority').length
  const analyticsCount = lessons.filter((lesson) => lesson.track === 'analytics-engineering').length
  const storageCount = lessons.filter((lesson) => lesson.track === 'storage-performance').length
  const troubleshootingCount = lessons.filter((lesson) => lesson.track === 'pipeline-troubleshooting').length

  return createPortal(
    <div className="simple-home">
      <section className="simple-hero">
        <div className="simple-hero-copy">
          <span className="simple-eyebrow">DATA ENGINEERING INTERVIEW + PRACTICE</span>
          <h1>Focus on the skills that move you from coding to production data engineering.</h1>
          <p>Core first: SQL, Python, PySpark, storage design, troubleshooting, dbt/analytics engineering, modeling, data quality and reliable pipelines. Docker, Kubernetes, MLOps, NoSQL and GenAI stay available as optional breadth.</p>
          <div className="simple-hero-actions">
            <button className="simple-primary" onClick={() => openCoreTrack('Analytics Eng')}><TrendingUp size={16} /> Analytics Engineering</button>
            <button className="simple-secondary" onClick={() => openCoreTrack('Troubleshoot')}><GraduationCap size={16} /> Troubleshoot Pipelines</button>
          </div>
        </div>
        <div className="simple-progress-card">
          <span>YOUR CORE DE PROGRESS</span>
          <strong>{progress.corePercent}%</strong>
          <p>{progress.coreMastered} of {progress.coreTotal} core drills mastered</p>
          <div className="simple-progress-line"><span style={{ width: `${progress.corePercent}%` }} /></div>
          <div className="simple-progress-meta">
            <span><Flag size={13} /> {progress.flags} review</span>
            <span><CheckCircle2 size={13} /> {progress.drafts} saved drafts</span>
          </div>
        </div>
      </section>

      <section className="focus-tier core-focus-tier">
        <div className="focus-tier-heading">
          <div><span>CORE FOCUS</span><h2>Prioritize these for data / analytics engineering interviews</h2></div>
          <p>Complete these before spending serious time on infrastructure or GenAI.</p>
        </div>
        <div className="focus-card-grid">
          <FocusCard label={`${analyticsCount} PRACTICAL LABS`} title="Analytics Engineering" text="dbt + DuckDB, marts, tests, lineage, pandas/PySpark equivalents." onClick={() => openCoreTrack('Analytics Eng')} />
          <FocusCard label="DISTRIBUTED DATA" title="PySpark" text="DataFrames, Spark SQL, joins, shuffles, partitions, Delta and source-course labs." onClick={() => openCoreTrack('Spark')} />
          <FocusCard label="FOUNDATIONAL" title="SQL / T-SQL" text="Joins, windows, dedupe, keys, SCD2 and interview queries." onClick={() => openCoreTrack('T-SQL')} />
          <FocusCard label="CONTROL CODE" title="Python" text="Collections, files, APIs, retries, batching and pipeline utilities." onClick={() => openCoreTrack('Python')} />
          <FocusCard label={`${storageCount} CORE DRILLS`} title="Storage · Formats · Performance" text="Parquet, Avro, JSON, Delta, DuckDB, pruning, partitions, clustering, indexes and compaction." onClick={() => openLearningHub('Storage & Performance')} />
          <FocusCard label={`${troubleshootingCount} INCIDENT LABS`} title="Pipeline Troubleshooting" text="Broken ETL, row loss, duplicates, late data, skew/OOM, partitioning, Airflow, Polars vs DuckDB vs Spark." onClick={() => openLearningHub('Pipeline Troubleshooting')} />
          <FocusCard label="TRANSFORMATION ENGINEERING" title="dbt" text="ref/source, tests, incremental models, snapshots, CI and late data." onClick={() => openLearningHub('dbt')} />
          <FocusCard label={`${seniorityCount} COMPARISONS`} title="Junior → Senior" text="Same problem, two good implementations: local/simple vs production-aware." onClick={() => openCoreTrack('Junior vs Senior')} />
          <FocusCard label="THEORY + ARCHITECTURE" title="Data Engineering Interview" text="Keys, indexes, modeling, quality, idempotency, cloud, physical storage and scaling questions." onClick={() => openLearningHub('Data Engineering')} />
          <FocusCard label="SERVING / BUSINESS" title="BI · DAX · KPIs" text="Star schemas, P&L, margins, operational KPIs and DAX/SQL/pandas equivalents." onClick={() => openLearningHub('BI · Finance')} />
        </div>
      </section>

      <section className="simple-section">
        <div className="simple-section-heading">
          <div><span>CHOOSE ONE PRACTICE MODE</span><h2>Use the specialized labs when you need repetition</h2></div>
          <p>The labs complement the core path; they are not separate courses you must complete first.</p>
        </div>
        <div className="simple-mode-grid">
          <ModeCard
            primary
            icon={<BookOpen size={20} />}
            eyebrow="GUIDED CURRICULUM"
            title="Core Problems"
            description="Move through programming, algorithms, SQL, Python, PySpark, storage, troubleshooting and production-oriented data engineering concepts."
            detail={`${progress.coreTotal} core-priority drills`}
            action="Start Foundations"
            onClick={() => openCoreTrack('Start here')}
          />
          <ModeCard
            icon={<Database size={20} />}
            eyebrow="SQL PRACTICE"
            title="SQL Challenges"
            description="Solve interview-style SQL problems and switch concepts between T-SQL, DuckDB and BigQuery."
            detail={`${sqlChallenges.length} challenge concepts · 3 dialects`}
            action="Open SQL Lab"
            onClick={() => openLab('SQL Dialect Lab')}
          />
          <ModeCard
            icon={<Layers3 size={20} />}
            eyebrow="TRANSLATION PRACTICE"
            title="Multi-Engine Lab"
            description="Rewrite the same transformation in SQL, pandas and PySpark to learn the shared data-engineering pattern."
            detail={`${engineChallenges.length} cross-engine challenges`}
            action="Open Multi-Engine"
            onClick={() => openLab('Multi-Engine Lab')}
          />
          <ModeCard
            icon={<Code2 size={20} />}
            eyebrow="SHORT RECALL DRILLS"
            title="Python Syntax Gym"
            description="Fast exercises for functions, arguments, lambdas, comprehensions and syntax that should become automatic."
            detail={`${pythonLabChallenges.length} short drills`}
            action="Open Python Gym"
            onClick={() => openLab('Python Syntax Gym')}
          />
        </div>
      </section>

      <section className="simple-section simple-path-section">
        <div className="simple-section-heading compact">
          <div><span>RECOMMENDED PATH</span><h2>Interview-first order</h2></div>
        </div>
        <div className="simple-path extended-path">
          {[
            ['01', 'Foundations', 'Start here'],
            ['02', 'Algorithms', 'Algorithms'],
            ['03', 'Python', 'Python'],
            ['04', 'SQL', 'T-SQL'],
            ['05', 'Storage', 'Storage / Perf'],
            ['06', 'PySpark', 'Spark'],
            ['07', 'Troubleshoot', 'Troubleshoot'],
            ['08', 'Analytics Eng', 'Analytics Eng'],
            ['09', 'Junior → Senior', 'Junior vs Senior'],
          ].map(([number, label, target]) => (
            <button key={label} onClick={() => openCoreTrack(target)}>
              <span>{number}</span>
              <strong>{label}</strong>
              <ArrowRight size={14} />
            </button>
          ))}
        </div>
      </section>

      <section className="algorithm-callout">
        <div>
          <span>CLASSICAL ALGORITHMS</span>
          <h2>{algorithmCount} practical algorithm drills</h2>
          <p>Search, hashing, dedupe, sorting, two pointers, sliding windows, prefix sums, heaps, graph traversal, topological sort, intervals and batching—kept in data-engineering context.</p>
        </div>
        <button onClick={() => openCoreTrack('Algorithms')}>Open Algorithms <ArrowRight size={15} /></button>
      </section>

      <section className="focus-tier optional-focus-tier">
        <div className="focus-tier-heading">
          <div><span>OPTIONAL BREADTH</span><h2>Useful after the core DE path</h2></div>
          <p>Keep these as supporting knowledge. They should not crowd out SQL, PySpark, dbt, modeling or pipeline reliability.</p>
        </div>
        <div className="optional-card-grid">
          <FocusCard optional label="NICE TO HAVE" title="Docker" text="Images, Dockerfiles, volumes and container basics." onClick={() => openCoreTrack('Docker · Optional')} />
          <FocusCard optional label="NICE TO HAVE" title="Kubernetes" text="Deployment → Pods → Service, rollout, config and troubleshooting." onClick={() => openCoreTrack('K8s · Optional')} />
          <FocusCard optional label="NICE TO HAVE" title="MLOps" text="FastAPI, MLflow, registry, CI/CD and orchestration examples." onClick={() => openCoreTrack('MLOps · Optional')} />
          <FocusCard optional label="DATABASE BREADTH" title="NoSQL" text="Redis cache + MongoDB documents from the uploaded practical course." onClick={() => openCoreTrack('NoSQL · Optional')} />
          <FocusCard optional label="AI BREADTH" title="GenAI" text="Embeddings, RAG, local model APIs and MCP/tool architecture." onClick={() => openCoreTrack('GenAI · Optional')} />
        </div>
        <div className="optional-note"><Boxes size={15} /><span>These tracks remain available in the full curriculum, but they are deliberately excluded from the Core DE progress percentage.</span><Sparkles size={15} /></div>
      </section>
    </div>,
    homeRoot,
  )
}
