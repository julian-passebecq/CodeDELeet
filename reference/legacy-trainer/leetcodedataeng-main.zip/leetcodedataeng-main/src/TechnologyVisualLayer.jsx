import { useEffect } from 'react'
import {
  GLYPHS,
  OFFICIAL_ASSETS,
  fallbackGlyphFor,
  technologySpecFor,
} from './technologyVisualRegistry'

function normalizedText(node) {
  const host = node.closest('button, header, .track-card') ?? node.parentElement
  const variant = host?.matches?.('.variant-button-row button')
    ? host.querySelector('small')?.textContent
    : null
  const primary = host?.querySelector('strong')?.textContent
  return (variant || primary || host?.getAttribute?.('title') || host?.textContent || node.textContent || '')
    .replace(/\s+/g, ' ')
    .trim()
}

function renderInto(node, spec) {
  if (!(node instanceof HTMLElement) || !spec) return
  if (node.dataset.techVisual === spec.kind) return
  node.dataset.techVisual = spec.kind
  node.classList.add('technology-visual-icon')
  node.setAttribute('aria-hidden', 'true')
  node.removeAttribute('title')

  if (spec.official) {
    const asset = OFFICIAL_ASSETS[spec.official]
    node.innerHTML = `<img alt="" src="${asset.src}">${asset.trademark ? '<sup class="technology-trademark">™</sup>' : ''}`
    const img = node.querySelector('img')
    img?.addEventListener('error', () => {
      node.classList.add('technology-visual-fallback')
      node.innerHTML = GLYPHS[fallbackGlyphFor(spec)] ?? GLYPHS.book
    }, { once: true })
    return
  }

  node.innerHTML = GLYPHS[spec.glyph] ?? GLYPHS.book
}

function normalizeSlot(node) {
  if (!(node instanceof HTMLElement)) return null
  if (node.tagName === 'IMG') {
    const replacement = document.createElement('span')
    replacement.className = node.className
    node.replaceWith(replacement)
    return replacement
  }
  return node
}

function decorateNode(node) {
  const slot = normalizeSlot(node)
  if (!slot) return
  const spec = technologySpecFor(normalizedText(slot))
  if (spec) renderInto(slot, spec)
}

function decorateAll() {
  const selectors = [
    '.reference-nav-icon',
    '.reference-page-header > div > span:first-child',
    '.full-curriculum-icon',
    '.learning-extra-nav button > span:first-child',
    '.learning-hub-header > div > span:first-child',
    '.track-card .track-icon',
    '.variant-button-row button > :first-child',
  ]
  document.querySelectorAll(selectors.join(',')).forEach(decorateNode)

  const curriculum = document.querySelector('.organized-full-curriculum')
  if (curriculum && !curriculum.parentElement?.querySelector(':scope > .technology-visual-attribution')) {
    const note = document.createElement('p')
    note.className = 'technology-visual-attribution'
    note.textContent = 'Python and the Python Logo are trademarks of the Python Software Foundation; Coding Reset is not affiliated with the PSF. Microsoft Fabric and Power BI icons are shown only as training/reference identifiers.'
    curriculum.insertAdjacentElement('afterend', note)
  }
}

export default function TechnologyVisualLayer() {
  useEffect(() => {
    let frame = 0
    const schedule = () => {
      if (frame) return
      frame = window.requestAnimationFrame(() => {
        frame = 0
        decorateAll()
      })
    }

    decorateAll()
    const observer = new MutationObserver(schedule)
    observer.observe(document.body, { childList: true, subtree: true, characterData: true })
    return () => {
      observer.disconnect()
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  return null
}
