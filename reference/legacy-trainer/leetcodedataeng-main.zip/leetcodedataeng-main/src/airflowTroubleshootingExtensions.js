import { cheatSheets } from './cheatSheets.js'

const airflow = cheatSheets.find((item) => item.id === 'airflow')

if (airflow) {
  const addSection = (title, code) => {
    if (!airflow.sections.some(([existing]) => existing === title)) airflow.sections.push([title, code])
  }

  addSection('Task-state troubleshooting', 'FAILED → read task log + validate input contract\nUP_FOR_RETRY → is failure actually transient?\nQUEUED too long → pools / executor slots / concurrency / scheduler\nSCHEDULED too long → dependencies / scheduler health\nSensor stuck → timeout / poke vs reschedule / external dependency')
  addSection('Retries + backoff', "@task(\n    retries=3,\n    retry_exponential_backoff=True,\n    max_retry_delay=timedelta(minutes=15),\n)\ndef extract_api():\n    ...\n\n# Do not retry deterministic schema/data-contract failures blindly.")
  addSection('Pools + concurrency', "# Use pools for scarce dependencies, e.g. an API/database.\n@task(pool='partner_api', pool_slots=1)\ndef extract_customer(customer_id):\n    ...\n\n# Also inspect max_active_runs / task concurrency before assuming workers are broken.")
  addSection('Backfill checklist', '1. Make target writes idempotent\n2. Start with one date/partition\n3. Limit parallelism\n4. Reconcile counts + business KPIs\n5. Expand date range\n6. Keep rollback/restore path until validation passes')

  for (const model of [
    'Airflow orchestrates work; it should not hide deterministic data errors behind repeated retries.',
    'Queued and failed are different incident classes: a queued task may never have executed user code.',
    'Backfills are production changes. Bound concurrency and validate each partition before widening the replay.',
  ]) {
    if (!airflow.mentalModels.includes(model)) airflow.mentalModels.push(model)
  }

  for (const topic of ['task states + incident triage', 'pools / executor slots', 'retry classification', 'safe backfill / replay']) {
    if (!airflow.interview.includes(topic)) airflow.interview.push(topic)
  }
}
