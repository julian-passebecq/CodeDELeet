import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { Database, Table2 } from 'lucide-react'
import { lessons } from './curriculum'

const insurance = {
  label: 'FL insurance sample', sourceFile: 'pyspark-tutorial-master/FL_insurance_sample.csv',
  note: 'Rows are copied from the uploaded PySpark course and intentionally truncated for the browser trainer.',
  tables: [{
    name: 'FL_insurance_sample.csv',
    columns: ['policyID', 'county', 'tiv_2011', 'tiv_2012', 'line', 'construction'],
    rows: [
      [119736, 'CLAY COUNTY', 498960, 792148.9, 'Residential', 'Masonry'],
      [448094, 'CLAY COUNTY', 1322376.3, 1438163.57, 'Residential', 'Masonry'],
      [206893, 'CLAY COUNTY', 190724.4, 192476.78, 'Residential', 'Wood'],
      [333743, 'CLAY COUNTY', 79520.76, 86854.48, 'Residential', 'Wood'],
      [172534, 'CLAY COUNTY', 254281.5, 246144.49, 'Residential', 'Wood'],
      [995932, 'CLAY COUNTY', 19260000, 20610000, 'Commercial', 'Reinforced Concrete'],
    ],
  }],
}

const titanic = {
  label: 'Titanic cleaning sample', sourceFile: 'pyspark-tutorial-master/titanic.csv',
  note: 'This is source-derived sample data from the uploaded advanced Spark notebook; the trainer uses it only for DataFrame cleaning practice.',
  tables: [{
    name: 'titanic_sample.csv',
    columns: ['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'Fare', 'Cabin', 'Embarked'],
    rows: [
      [1, 0, 3, 'Braund, Mr. Owen Harris', 'male', 22, 7.25, null, 'S'],
      [2, 1, 1, 'Cumings, Mrs. John Bradley', 'female', 38, 71.2833, 'C85', 'C'],
      [3, 1, 3, 'Heikkinen, Miss. Laina', 'female', 26, 7.925, null, 'S'],
      [6, 0, 3, 'Moran, Mr. James', 'male', null, 8.4583, null, 'Q'],
    ],
  }],
}

const movies = {
  label: 'MovieLens document sample', sourceFile: 'lyon2-nosql-main/data/movielens_movies.json',
  note: 'Rows are copied from the uploaded NoSQL course. The full source file is much larger; this browser preview is intentionally small.',
  tables: [{
    name: 'movielens_movies_sample.json',
    columns: ['_id', 'title', 'genres'],
    rows: [
      [1, 'Toy Story (1995)', "Animation|Children's|Comedy"],
      [2, 'Jumanji (1995)', "Adventure|Children's|Fantasy"],
      [3, 'Grumpier Old Men (1995)', 'Comedy|Romance'],
      [4, 'Waiting to Exhale (1995)', 'Comedy|Drama'],
      [6, 'Heat (1995)', 'Action|Crime|Thriller'],
      [10, 'GoldenEye (1995)', 'Action|Adventure|Thriller'],
    ],
  }],
}

function resolve(item) {
  if (!item) return null
  if (item.id === 'src-sp-titanic-clean') return titanic
  if (item.id.startsWith('src-sp-')) return insurance
  if (item.id === 'opt-mongo-find' || item.id === 'opt-mongo-update') return movies
  return null
}

function Table({ table }) {
  return <div className="original-preview-table"><strong>{table.name}</strong><div className="original-preview-scroll"><table><thead><tr>{table.columns.map((column) => <th key={column}>{column}</th>)}</tr></thead><tbody>{table.rows.map((row, i) => <tr key={i}>{row.map((value, j) => <td key={j}>{value == null ? <span className="original-null">NULL</span> : String(value)}</td>)}</tr>)}</tbody></table></div></div>
}

function Panel({ preview }) {
  const [open, setOpen] = useState(true)
  return <section className="practice-data-preview original-source-preview"><button className="practice-data-preview-header" onClick={() => setOpen((value) => !value)} aria-expanded={open}><span><Database size={13} /><strong>Source data</strong><small>uploaded course sample</small></span><span>{open ? 'Collapse' : 'Open'}</span></button>{open && <div className="original-source-preview-body"><div className="original-source-meta"><div><Table2 size={14} /><span><strong>{preview.label}</strong><small>{preview.sourceFile}</small></span></div><span className="source-derived-badge">SOURCE-DERIVED</span></div><div className="original-preview-tables">{preview.tables.map((table) => <Table key={table.name} table={table} />)}</div><p className="original-source-note">{preview.note}</p></div>}</section>
}

export default function CourseSourcePreviews() {
  const [state, setState] = useState({ mount: null, title: '' })
  useEffect(() => {
    let frame = 0
    const sync = () => {
      const mount = document.querySelector('.leetcode-practice .data-preview-mount')
      const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim() ?? ''
      setState((old) => old.mount === mount && old.title === title ? old : { mount, title })
    }
    const scheduleSync = () => {
      if (frame) return
      frame = window.requestAnimationFrame(() => {
        frame = 0
        sync()
      })
    }
    sync()
    const observer = new MutationObserver(scheduleSync)
    observer.observe(document.body, { childList: true, subtree: true, characterData: true })
    return () => {
      observer.disconnect()
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  const item = useMemo(() => lessons.find((lesson) => lesson.title === state.title) ?? null, [state.title])
  const preview = useMemo(() => resolve(item), [item])

  useEffect(() => {
    const pane = state.mount?.closest('.code-pane')
    if (!pane) return undefined
    pane.classList.toggle('course-source-preview-active', Boolean(preview))
    return () => pane.classList.remove('course-source-preview-active')
  }, [state.mount, preview])

  if (!state.mount || !preview) return null
  return createPortal(<Panel preview={preview} />, state.mount)
}
