import { useEffect } from 'react'
import { lessons } from './curriculum'

const HUB_ID = 'storage-performance'
const HUB_LABEL = 'Storage · Formats · Performance'
const TRACK = 'storage-performance'

function storageLessons() {
  return lessons.filter((item) => item.track === TRACK)
}

function openStorageHub() {
  window.dispatchEvent(new CustomEvent('de-open-learning-hub', { detail: HUB_ID }))
}

function openStoragePractice() {
  const button = [...document.querySelectorAll('.track-nav button')]
    .find((node) => node.textContent?.replace(/\s+/g, ' ').includes('Storage / Perf'))
  if (button instanceof HTMLElement) button.click()
}

function ensureNavButton() {
  const nav = document.querySelector('.learning-extra-nav')
  if (!nav || nav.querySelector('[data-storage-hub-nav]')) return

  const button = document.createElement('button')
  button.type = 'button'
  button.dataset.storageHubNav = 'true'
  button.innerHTML = '<span>ST</span><div><strong>Storage & Performance</strong><small>Parquet, Delta, partitions, indexes</small></div><span aria-hidden="true">›</span>'
  button.addEventListener('click', openStorageHub)

  const before = [...nav.querySelectorAll('button')].find((item) => item.textContent?.includes('Data Engineering'))
  if (before) nav.insertBefore(button, before)
  else nav.appendChild(button)
}

function wireBreadcrumb() {
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  if (!title || !storageLessons().some((item) => item.title === title)) return

  const crumb = document.querySelector('.ide-breadcrumb span')
  if (!crumb) return
  if (crumb.textContent !== 'Storage / Perf') crumb.textContent = 'Storage / Perf'
  crumb.dataset.learningHubId = HUB_ID
  crumb.setAttribute('role', 'button')
  crumb.setAttribute('tabindex', '0')
  crumb.setAttribute('title', `Open ${HUB_LABEL} learning hub`)
}

function setText(node, text) {
  if (node && node.textContent !== text) node.textContent = text
}

function enhanceStorageHub() {
  const page = [...document.querySelectorAll('.learning-hub-page')].find((node) =>
    node.querySelector('.learning-hub-header strong')?.textContent?.trim() === HUB_LABEL,
  )
  if (!page) return

  const count = storageLessons().length
  setText(page.querySelector('.hub-header-meta span'), `${count} drills`)

  const sourceButton = [...page.querySelectorAll('.hub-five-part-nav button')]
    .find((node) => node.textContent?.includes('Source labs'))
  setText(sourceButton?.querySelector('small'), `${count} mapped drills`)

  const summary = page.querySelector('.hub-source-summary')
  const itemsRoot = page.querySelector('.hub-source-items')
  if (!summary || !itemsRoot) return

  setText(summary.querySelector('h2'), 'Storage & Performance core labs')
  setText(summary.querySelector('strong'), String(count))
  setText(summary.querySelector('p'), 'Core drills for formats, Python/PySpark I/O, Delta, DuckDB and physical query design.')

  if (!summary.querySelector('[data-storage-practice-button]')) {
    const button = document.createElement('button')
    button.type = 'button'
    button.dataset.storagePracticeButton = 'true'
    button.textContent = 'Open storage practice'
    button.addEventListener('click', openStoragePractice)
    summary.appendChild(button)
  }

  if (!itemsRoot.dataset.storageFilled) {
    itemsRoot.replaceChildren()
    for (const item of storageLessons().slice(0, 10)) {
      const row = document.createElement('div')
      const level = document.createElement('span')
      const title = document.createElement('strong')
      const task = document.createElement('small')
      level.textContent = item.level
      title.textContent = item.title
      task.textContent = item.task
      row.append(level, title, task)
      itemsRoot.appendChild(row)
    }
    itemsRoot.dataset.storageFilled = 'true'
  }
}

export default function StorageHubBridge() {
  useEffect(() => {
    const sync = () => {
      ensureNavButton()
      wireBreadcrumb()
      enhanceStorageHub()
    }

    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [])

  return null
}
