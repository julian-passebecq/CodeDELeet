import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import TechnologyMark from './TechnologyMark'
import { lessons } from './curriculum'

let mermaidPromise

function loadMermaid() {
  if (window.mermaid) return Promise.resolve(window.mermaid)
  if (mermaidPromise) return mermaidPromise

  mermaidPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-de-mermaid]')
    if (existing) {
      if (window.mermaid) resolve(window.mermaid)
      else {
        existing.addEventListener('load', () => resolve(window.mermaid), { once: true })
        existing.addEventListener('error', reject, { once: true })
      }
      return
    }
    const script = document.createElement('script')
    script.src = 'https://cdn.jsdelivr.net/npm/mermaid@11.17.2/dist/mermaid.min.js'
    script.async = true
    script.dataset.deMermaid = 'true'
    script.onload = () => resolve(window.mermaid)
    script.onerror = reject
    document.head.appendChild(script)
  })
  return mermaidPromise
}

function ensureMount() {
  const description = document.querySelector('.problem-description')
  if (!description) return null
  let mount = description.querySelector(':scope > .practice-diagram-mount')
  if (!mount) {
    mount = document.createElement('div')
    mount.className = 'practice-diagram-mount'
    const context = description.querySelector('.problem-context')
    if (context) context.insertAdjacentElement('afterend', mount)
    else description.querySelector('.problem-meta')?.insertAdjacentElement('afterend', mount)
  }
  return mount
}

function stableRenderId(value) {
  let hash = 2166136261
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index)
    hash = Math.imul(hash, 16777619)
  }
  return `de-mermaid-${(hash >>> 0).toString(36)}`
}

function MermaidDiagram({ source, title }) {
  const [svg, setSvg] = useState('')
  const [failed, setFailed] = useState(false)
  const architecture = /^\s*architecture-beta\b/.test(source)
  const renderId = useMemo(() => stableRenderId(`${title}\n${source}`), [source, title])

  useEffect(() => {
    let cancelled = false
    setSvg('')
    setFailed(false)
    loadMermaid().then(async (mermaid) => {
      if (!mermaid || cancelled) throw new Error('Mermaid unavailable')
      mermaid.initialize({
        startOnLoad: false,
        securityLevel: 'strict',
        theme: 'neutral',
        fontFamily: 'Inter, system-ui, sans-serif',
        architecture: {
          seed: 1,
          randomize: false,
          iconSize: 64,
          fontSize: 14,
          nodeSeparation: 70,
          idealEdgeLengthMultiplier: 1.6,
        },
      })
      const result = await mermaid.render(renderId, source)
      if (!cancelled) setSvg(result.svg)
    }).catch(() => {
      if (!cancelled) setFailed(true)
    })
    return () => { cancelled = true }
  }, [source, renderId])

  const kind = architecture ? 'architecture' : 'flow'
  return (
    <section className="practice-diagram-card" data-diagram-kind={kind}>
      <div className="practice-diagram-heading">
        <TechnologyMark label={title} className="practice-diagram-topic-icon" />
        <span>{architecture ? 'ARCHITECTURE' : 'FLOW'}</span>
        <strong>{title}</strong>
      </div>
      {svg ? (
        <div className="practice-mermaid-svg" role="img" aria-label={`${title} ${architecture ? 'architecture' : 'flow'} diagram`} dangerouslySetInnerHTML={{ __html: svg }} />
      ) : failed ? (
        <pre className="practice-diagram-fallback">{source}</pre>
      ) : (
        <div className="practice-diagram-loading">Loading diagram…</div>
      )}
    </section>
  )
}

export default function PracticeDiagramLayer() {
  const [mount, setMount] = useState(null)
  const [lesson, setLesson] = useState(null)

  useEffect(() => {
    let frame = 0
    const sync = () => {
      frame = 0
      const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
      const current = lessons.find((item) => item.title === title && item.diagram)
      if (!current) {
        setLesson(null)
        setMount(null)
        return
      }
      setLesson((old) => old?.id === current.id && old?.diagram === current.diagram ? old : current)
      const nextMount = ensureMount()
      setMount((old) => old === nextMount ? old : nextMount)
    }
    const schedule = () => {
      if (frame) return
      frame = window.requestAnimationFrame(sync)
    }

    sync()
    const observer = new MutationObserver(schedule)
    observer.observe(document.body, { childList: true, subtree: true, characterData: true })
    return () => {
      observer.disconnect()
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  if (!mount || !lesson?.diagram) return null
  return createPortal(<MermaidDiagram source={lesson.diagram} title={lesson.title} />, mount)
}
