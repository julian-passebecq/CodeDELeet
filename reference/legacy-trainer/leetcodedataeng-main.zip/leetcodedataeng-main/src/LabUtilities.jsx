import { Component, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Download, Palette, RefreshCcw, Settings2, Upload, X } from 'lucide-react'
import { collectProgressBackup, restoreProgressBackup, STORAGE_PREFIX } from './progressBackup'

const EDITOR_APPEARANCE_KEY = `${STORAGE_PREFIX}:setting:editorAppearance`
const EDITOR_APPEARANCES = [
  { id: 'gray', label: 'Gray', short: 'Gray', note: 'Light neutral workspace' },
  { id: 'black', label: 'Black', short: 'Black', note: 'High-contrast dark' },
  { id: 'light', label: 'Light', short: 'Light', note: 'White code workspace' },
]

function readEditorAppearance() {
  try {
    const stored = JSON.parse(localStorage.getItem(EDITOR_APPEARANCE_KEY) ?? 'null')
    return EDITOR_APPEARANCES.some((option) => option.id === stored) ? stored : 'gray'
  } catch {
    return 'gray'
  }
}

function isTypingTarget(target) {
  if (!(target instanceof Element)) return false
  return Boolean(target.closest('input, textarea, select, [contenteditable="true"], .monaco-editor'))
}

function ensureInlineThemeMount() {
  const actions = document.querySelector('.code-pane-actions')
  if (!actions) return null
  let mount = actions.querySelector(':scope > .inline-theme-mount')
  if (!mount) {
    mount = document.createElement('span')
    mount.className = 'inline-theme-mount'
    actions.insertBefore(mount, actions.firstChild)
  }
  return mount
}

function InlineThemePicker({ value, onChange }) {
  return (
    <div className="inline-theme-picker" role="group" aria-label="Editor background">
      <Palette size={13} aria-hidden="true" />
      {EDITOR_APPEARANCES.map((option) => (
        <button
          key={option.id}
          type="button"
          className={value === option.id ? 'active' : ''}
          onClick={() => onChange(option.id)}
          aria-pressed={value === option.id}
          title={`${option.label} editor background`}
        >
          <span className={`inline-theme-dot inline-theme-dot-${option.id}`} aria-hidden="true" />
          {option.short}
        </button>
      ))}
    </div>
  )
}

export function LabUtilities({ children }) {
  const [panelOpen, setPanelOpen] = useState(false)
  const [editorAppearance, setEditorAppearance] = useState(readEditorAppearance)
  const [status, setStatus] = useState('')
  const [toolbarMount, setToolbarMount] = useState(null)
  const fileInputRef = useRef(null)

  useEffect(() => {
    const safeAppearance = EDITOR_APPEARANCES.some((option) => option.id === editorAppearance) ? editorAppearance : 'gray'
    document.documentElement.dataset.editorAppearance = safeAppearance
    try {
      localStorage.setItem(EDITOR_APPEARANCE_KEY, JSON.stringify(safeAppearance))
    } catch {
      // Appearance still works for the current session when storage is unavailable.
    }
    window.dispatchEvent(new CustomEvent('de-editor-appearance', { detail: safeAppearance }))
  }, [editorAppearance])

  useEffect(() => {
    const sync = () => setToolbarMount((current) => {
      const next = ensureInlineThemeMount()
      return current === next ? current : next
    })
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })

    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        setPanelOpen(false)
        return
      }
      if (isTypingTarget(event.target)) return
      if (event.key === '/' && document.querySelector('.leetcode-practice')) {
        event.preventDefault()
        const search = document.querySelector('.problem-drawer .search-box input')
        if (search) {
          search.focus()
        } else {
          document.querySelector('.ide-problems-button')?.click()
          window.setTimeout(() => document.querySelector('.problem-drawer .search-box input')?.focus(), 0)
        }
      }
    }

    const clearResizeState = () => document.body.classList.remove('resizing-panes')
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('pointercancel', clearResizeState)
    window.addEventListener('blur', clearResizeState)
    return () => {
      observer.disconnect()
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('pointercancel', clearResizeState)
      window.removeEventListener('blur', clearResizeState)
    }
  }, [])

  function exportProgress() {
    try {
      const backup = collectProgressBackup(localStorage)
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      const stamp = new Date().toISOString().slice(0, 10)
      anchor.href = url
      anchor.download = `coding-reset-progress-${stamp}.json`
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      URL.revokeObjectURL(url)
      setStatus(`Backup exported (${Object.keys(backup.entries).length} saved entries).`)
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Could not export progress.')
    }
  }

  async function importProgress(event) {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    if (file.size > 2_000_000) {
      setStatus('Backup is too large. Expected a small JSON progress file.')
      return
    }
    try {
      const count = restoreProgressBackup(localStorage, await file.text(), { replace: true })
      setStatus(`Restored exact backup snapshot (${count} saved entries). Reloading…`)
      window.setTimeout(() => window.location.reload(), 250)
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Could not restore this backup.')
    }
  }

  return (
    <>
      {children}

      {toolbarMount && createPortal(
        <InlineThemePicker value={editorAppearance} onChange={setEditorAppearance} />,
        toolbarMount,
      )}

      <button className="lab-utility-button" onClick={() => setPanelOpen((value) => !value)} aria-label="Open trainer utilities" aria-expanded={panelOpen}>
        <Settings2 size={17} />
        <span>Lab tools</span>
      </button>

      {panelOpen && (
        <aside className="lab-utility-panel" aria-label="Trainer utilities">
          <div className="lab-utility-heading">
            <div><span>LOCAL TRAINER TOOLS</span><strong>Practice settings</strong></div>
            <button onClick={() => setPanelOpen(false)} aria-label="Close trainer utilities"><X size={17} /></button>
          </div>

          <div className="lab-utility-section lab-theme-section">
            <strong>Editor appearance</strong>
            <p>The same controls are now always visible in the editor toolbar. Gray is a genuinely light-gray workspace, Black is dark, and Light is white.</p>
            <div className="lab-theme-grid" role="group" aria-label="Editor appearance">
              {EDITOR_APPEARANCES.map((option) => (
                <button
                  key={option.id}
                  className={editorAppearance === option.id ? 'active' : ''}
                  onClick={() => setEditorAppearance(option.id)}
                  aria-pressed={editorAppearance === option.id}
                >
                  <span className={`lab-theme-swatch lab-theme-swatch-${option.id}`} aria-hidden="true" />
                  <span><strong>{option.label}</strong><small>{option.note}</small></span>
                </button>
              ))}
            </div>
          </div>

          <div className="lab-utility-section">
            <strong>Progress backup</strong>
            <p>Drafts, flags, mastery, notes, selections and lab settings stay in your browser. Export a JSON backup before clearing site data or switching browsers. Restore replaces the trainer's current saved state with the selected snapshot, so stale entries do not survive.</p>
            <div className="lab-utility-actions">
              <button onClick={exportProgress}><Download size={14} /> Export</button>
              <button onClick={() => fileInputRef.current?.click()}><Upload size={14} /> Restore</button>
            </div>
            <input ref={fileInputRef} className="lab-hidden-input" type="file" accept="application/json,.json" onChange={importProgress} />
          </div>

          <div className="lab-shortcut"><kbd>/</kbd><span>Open Problems and focus search while you are outside the code editor.</span></div>
          {status && <div className="lab-utility-status" role="status">{status}</div>}
        </aside>
      )}
    </>
  )
}

export class LabErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { error: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    console.error('Coding Reset UI error', error, info)
  }

  render() {
    if (!this.state.error) return this.props.children
    return (
      <main className="lab-error-state">
        <div>
          <RefreshCcw size={24} />
          <h1>The trainer hit a UI error.</h1>
          <p>Your drafts and progress are stored separately in the browser. Reload the app first; if the error repeats, export a backup from Lab tools after recovery.</p>
          <button onClick={() => window.location.reload()}><RefreshCcw size={15} /> Reload trainer</button>
        </div>
      </main>
    )
  }
}
