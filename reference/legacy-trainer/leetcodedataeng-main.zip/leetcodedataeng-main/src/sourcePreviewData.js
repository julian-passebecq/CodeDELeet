const table = (name, columns, rows) => ({ name, columns, rows })

const retailJoinTables = [
  table('df_orders', ['order_id', 'customer_id'], [
    [1, 101], [2, 102], [3, 103], [4, 104], [5, 105],
  ]),
  table('df_customers', ['customer_id', 'customer_name'], [
    [101, 'Toufik'], [102, 'Daniel'], [103, 'Tancrède'], [104, 'Kaouter'], [105, 'Jean-Nicolas'], [106, 'David'],
  ]),
  table('df_products', ['product_id', 'product_name', 'product_price'], [
    [101, 'Laptop', 800], [103, 'Ipad', 400], [104, 'Livre', 30], [105, 'Petitos', 2],
  ]),
  table('df_order_details', ['order_id', 'product_id', 'quantity'], [
    [1, 102, 2], [2, 104, 1], [3, 101, 3], [4, 103, 2], [5, 105, 1],
  ]),
]

const fullOuterTables = [
  table('df_customers', ['customer_id', 'customer_name'], [
    [11, 'Zeinaba'], [12, 'Tancrède'], [13, 'Israel'], [14, 'Kaouter'], [15, 'Alan'],
  ]),
  table('df_stores', ['store_id', 'customer_id'], [[1, 11], [2, 12], [3, 13], [4, 15]]),
  table('df_store_products', ['store_id', 'product_id'], [[1, 101], [1, 103], [1, 105], [2, 101], [2, 103], [3, 104], [4, 105]]),
  table('df_products', ['product_id', 'product_name', 'product_price'], [[100, 'Cherry coke', 3], [101, 'Laptop', 800], [103, 'Ipad', 400], [104, 'Livre', 30]]),
]

const selfJoinEmployees = [
  table('df_employees', ['employee_id', 'employee_name', 'manager_id'], [
    [11, 'Sophie', 13], [12, 'Sylvie', null], [13, 'Daniel', 12], [14, 'Kaouter', 13], [15, 'David', 11],
  ]),
]

const consecutiveOrders = [
  table('df_sales', ['order_id', 'customer_id', 'date'], [
    [1110, 11, 1], [1111, 11, 1], [1112, 13, 2], [1113, 13, 2], [1114, 12, 2],
    [1115, 12, 3], [1116, 14, 3], [1117, 11, 3], [1118, 14, 4], [1119, 11, 4],
  ]),
]

const meetingRows = [
  table('meetings_with_duration', ['meeting_id', 'person_name', 'duration_minutes'], [
    [0, 'Benjamin', 36], [1, 'Florian', 84], [1, 'Alice', 84], [1, 'Sirine', 84], [2, 'Alice', 44],
    [3, 'Benjamin', 39], [3, 'Sirine', 39], [3, 'Bob', 39], [3, 'Alice', 39], [3, 'Tarik', 39],
  ]),
]

const sizeBrand = [
  table('size', ['size'], [['XS'], ['M'], ['L'], ['XL']]),
  table('trademark', ['trademark'], [['Nike'], ['Asphalte'], ['Abercrombie'], ['Lewis']]),
]

const beveragesFood = [
  table('beverages', ['beverage', 'price'], [['orange juice', 2.5], ['Expresso', 2.0], ['Tea', 3.0]]),
  table('food_items', ['food_item', 'food_price'], [['cookie juice', 2.5], ['chocolatine', 2.0], ['muffin', 3.0]]),
]

const retailGrid = [
  table('weights_turnover_retail.csv', ['store_name', 'month', 'day_of_week', 'market_type', 'quarterhour', 'turnover_weight', 'n_lines'], [
    ['Lesquin', 1, 1, 'fruits et légumes', '08:45', 0.000006, 3],
    ['Lesquin', 1, 1, 'fruits et légumes', '09:00', 0.000034, 16],
    ['Lesquin', 1, 1, 'fruits et légumes', '09:15', 0.000155, 46],
    ['Lesquin', 1, 1, 'fruits et légumes', '09:30', 0.000267, 81],
    ['Lesquin', 1, 1, 'fruits et légumes', '09:45', 0.000480, 123],
    ['Lesquin', 1, 1, 'fruits et légumes', '10:00', 0.000316, 88],
  ]),
]

const wages = [
  table('wages', ['name', 'wage', 'department'], [
    ['Toufik', 60000, 'IT'], ['Jean-Nicolas', 75000, 'HR'], ['Daniel', 55000, 'SALES'],
    ['Kaouter', 80000, 'IT'], ['Sylvie', 70000, 'IT'], ['Sebastien', 90000, 'HR'],
    ['Diane', 65000, 'SALES'], ['Romain', 72000, 'IT'], ['François', 68000, 'HR'], ['Anna', 85000, 'SALES'],
  ]),
]

const discountedOrders = [
  table('orders', ['order_id', 'product_id', 'quantity', 'price_per_unit', 'discount_code'], [
    [1, 101, 5, 10.0, null], [2, 102, 3, 25.0, 'DISCOUNT10'], [3, 101, 2, 10.0, 'DISCOUNT20'],
    [4, 103, 4, 8.0, null], [5, 102, 6, 25.0, null], [6, 103, 2, 8.0, 'UNKNOWN'],
  ]),
]

const lilleMatches = [
  table('season-1011_csv.csv · Lille sample', ['Div', 'Date', 'HomeTeam', 'AwayTeam', 'FTHG', 'FTAG', 'FTR'], [
    ['F1', '07/08/10', 'Rennes', 'Lille', 1, 1, 'D'],
    ['F1', '15/08/10', 'Lille', 'Paris SG', 0, 0, 'D'],
    ['F1', '22/08/10', 'Sochaux', 'Lille', 0, 0, 'D'],
    ['F1', '29/08/10', 'Lille', 'Nice', 1, 1, 'D'],
    ['F1', '11/09/10', 'Lens', 'Lille', 1, 4, 'A'],
    ['F1', '19/09/10', 'Lille', 'Auxerre', 1, 0, 'H'],
    ['F1', '26/09/10', 'Toulouse', 'Lille', 1, 1, 'D'],
    ['F1', '03/10/10', 'Lille', 'Montpellier', 3, 1, 'H'],
  ]),
]

const neighborhoodSales = [
  table('ventes_immo', ['flat_id', 'neighborhood', 'price'], [
    [0, 'vieux_lille', 460000], [1, 'vieux_lille', 430000], [2, 'vieux_lille', 450000], [3, null, 470000],
    [4, 'vieux_lille', 440000], [10, 'gambetta', 336000], [11, null, 333000], [12, 'gambetta', 335000],
  ]),
]

const basketSales = [
  table('ventes', ['montant', 'client'], [
    [110, 'Oussama'], [49, 'Julie'], [65, 'Chris'], [23, 'Tom'], [24, 'Jean-Nicolas'], [3.99, 'Aline'],
    [29, 'Ben'], [48.77, 'Toufik'], [44, 'Sylvie'], [10, 'David'],
  ]),
]

const realEstate = [
  table('appartements_nord_pdc.csv', ['Date mutation', 'valeur_fonciere', 'Commune', 'Surface Carrez du 1er lot', 'Nombre pieces principales'], [
    ['04/01/2022', 208000, 'MARCQ EN BAROEUL', '57,69', 3],
    ['04/01/2022', 113000, 'SECLIN', '45,72', 3],
    ['03/01/2022', 185000, 'LILLE', '62,83', 3],
    ['04/01/2022', 120350, 'LILLE', '43,64', 2],
    ['04/01/2022', 149000, "VILLENEUVE-D'ASCQ", '59,02', 2],
    ['06/01/2022', 154000, 'ERQUINGHEM-LYS', '62,15', 3],
  ]),
]

const redbullSales = [
  table('df', ['store_id', 'product_name', 'amount'], [
    ['Armentieres', 'redbull', 45], ['Armentieres', 'chips', 60], ['Armentieres', 'wine', 60], ['Armentieres', 'redbull', 45],
    ['Lille', 'redbull', 100], ['Lille', 'chips', 140], ['Lille', 'wine', 190], ['Lille', 'icecream', 170],
    ['Douai', 'redbull', 55], ['Douai', 'chips', 70], ['Douai', 'wine', 20], ['Douai', 'icecream', 45],
  ]),
]

const population = [
  table('department population · 2016', ['region', 'departement', 'year', 'population'], [
    ['HDF', '59', 2016, 2603723], ['HDF', '62', 2016, 1470725], ['IDF', '75', 2016, 2190327],
    ['IDF', '95', 2016, 1221923], ['PACA', '83', 2016, 1055821], ['PACA', '84', 2016, 559014],
  ]),
]

const health = [
  table('health reimbursements · notebook sample', ['type_contrat', 'sexe', 'type_acte', 'groupe_age', 'annee', 'montant_rembourse'], [
    ['senior', 'homme', 'hospitalisation', '25-45', 2017, 3247.451445],
    ['jeunes', 'homme', 'radio', '18-25', 2019, 1501.571247],
    ['famille', 'homme', 'pharmacie', '18-25', 2017, 9.558023],
    ['jeunes', 'homme', 'radio', '25-45', 2019, 978.555936],
    ['salarié', 'femme', 'consultation_generaliste', '65+', 2019, 32.544643],
  ]),
]

const capteurs = [
  table('capteur_a_retrail.csv', ['date', 'capteur_id', 'visiteurs_count', 'weekday', 'moyenne_du_mois', 'threshold_twenty_pct'], [
    ['2023-08-01', 'porte_a', 4200, 3, 4920, 3936], ['2023-08-02', 'porte_a', 5300, 4, 4920, 3936],
    ['2023-08-03', 'porte_a', 4400, 5, 4920, 3936], ['2023-08-04', 'porte_a', 5500, 6, 4920, 3936],
    ['2023-08-05', 'porte_a', 6000, 7, 4920, 3936], ['2023-08-07', 'porte_a', 4200, 2, 4920, 3936],
  ]),
]

function pack(label, sourceFile, tables, note) {
  return { label, sourceFile, tables, note }
}

export function resolveOriginalSourcePreview(item) {
  if (!item) return null
  const source = item.sourcePack ?? ''
  const title = item.title ?? ''
  const context = item.context ?? ''
  const text = `${title} ${context}`

  if (/Inner Joins|Left Joins/i.test(source)) {
    return pack('Original notebook data', 'inner_joins / left_joins · examples and exercises', retailJoinTables, 'These rows are copied from the DataFrame definitions in the uploaded notebooks.')
  }
  if (/Full Outer Joins/i.test(source)) {
    return pack('Original notebook data', 'full_outer_joins · examples and exercises', fullOuterTables, 'Includes the unmatched customer, store and catalog-product cases used to explain FULL OUTER JOIN.')
  }
  if (/Self Join order-delay/i.test(source)) {
    return pack('Original notebook data', 'Self-joins · délai entre commandes', consecutiveOrders, 'The notebook generates this dataset with random.seed(42); these are its first rows.')
  }
  if (/Self Join meeting/i.test(source) || /meeting/i.test(title) && /Self/i.test(source)) {
    return pack('Original notebook output', 'Self-join · les réunions', meetingRows, 'Rows are taken from the notebook output after meeting durations are attached.')
  }
  if (/Self Joins/i.test(source)) {
    return pack('Original notebook data', 'Self joins · introduction', selfJoinEmployees, 'This is the employee/manager table used in the introductory self-join example.')
  }
  if (/Cross Joins/i.test(source)) {
    if (/retail|reporting grid/i.test(title)) return pack('Original CSV sample', 'weights_turnover_retail.csv', retailGrid, 'First rows from the uploaded retail source CSV.')
    if (/size|brand|trademark/i.test(title)) return pack('Original notebook data', 'Cross joins · SQL & Python examples', sizeBrand, 'These are the exact size and trademark inputs from the notebook exercise.')
    return pack('Original notebook data', 'Cross joins · SQL & Python examples', beveragesFood, 'These are the exact beverage and food-item DataFrames used in the notebook.')
  }
  if (/CASE football/i.test(source) || /football|Lille/i.test(text)) {
    return pack('Original CSV sample', 'season-1011_csv.csv', lilleMatches, 'Source rows from the uploaded 2010/11 football dataset, filtered to Lille for readability.')
  }
  if (/CASE WHEN simple/i.test(source)) {
    return pack('Original notebook data', 'CASE WHEN · simple use cases', wages, 'Salary rows copied from the notebook DataFrame used for the raise exercise.')
  }
  if (/CASE inside aggregation/i.test(source)) {
    return pack('Original notebook data', 'CASE WHEN in aggregation functions', discountedOrders, 'Order rows copied from the notebook discount/revenue example.')
  }
  if (/Real-estate GROUP BY/i.test(source) || /sale value by city/i.test(title)) {
    return pack('Original CSV sample', 'appartements_nord_pdc.csv', realEstate, 'First rows from the uploaded Nord/Pas-de-Calais apartment-sales CSV.')
  }
  if (/GROUP BY intro/i.test(source)) {
    return pack('Original notebook data', 'Groupby intro', neighborhoodSales, 'The exact small real-estate DataFrame used to teach grouping by neighborhood.')
  }
  if (/GROUP BY exercises/i.test(source)) {
    return pack('Original notebook data', 'Groupby, CTE & Having exercices', basketSales, 'First rows from the notebook customer-sales dataset.')
  }
  if (/Grouping Sets/i.test(source)) {
    if (/population|region|department|departement/i.test(text)) return pack('Original notebook / INSEE-derived sample', 'Grouping sets · population', population, 'The notebook reads the uploaded INSEE workbook and maps departments to regions; these are the 2016 rows used in the example.')
    if (/redbull|store|product/i.test(text)) return pack('Original notebook data', 'Grouper par plusieurs niveaux d’aggregation', redbullSales, 'The exact store/product sales table used to motivate GROUPING SETS.')
    return pack('Original notebook output', 'ROLLUP & CUBE · assurance santé', health, 'Sample rows shown by the original health-reimbursement notebook.')
  }
  if (/Window Functions/i.test(source)) {
    if (/salary|wage|department|rank/i.test(text)) return pack('Original notebook data', 'OVER(PARTITION BY col)', wages, 'Salary rows from the notebook used for PARTITION BY and ranking examples.')
    return pack('Original CSV sample', 'capteur_a_retrail.csv', capteurs, 'First rows from the uploaded retail-sensor CSV used throughout the window-function notebooks.')
  }
  return null
}

export const originalPreviewRuleCount = 14
