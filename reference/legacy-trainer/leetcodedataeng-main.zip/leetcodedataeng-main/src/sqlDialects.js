export const sqlDialects = [
  {
    id: 'tsql',
    label: 'T-SQL',
    short: 'Microsoft',
    note: 'SQL Server / Azure SQL / Fabric Warehouse style. Uses dbo-style schemas and CTEs when a window result must be filtered.',
  },
  {
    id: 'duckdb',
    label: 'DuckDB / source style',
    short: 'Original',
    note: 'Close to the SQL used by the uploaded notebooks. DuckDB is convenient for local analytics and supports QUALIFY for filtering window results.',
  },
  {
    id: 'bigquery',
    label: 'BigQuery GoogleSQL',
    short: 'GCP',
    note: 'GoogleSQL for BigQuery. QUALIFY is supported, and BigQuery adds first-class ARRAY / STRUCT / UNNEST patterns.',
  },
]

function stripDbo(text = '') {
  return text.replaceAll('dbo.', '')
}

function duckify(text = '') {
  return stripDbo(text)
    .replaceAll("DATEADD(day, 1, a.order_date)", "a.order_date + INTERVAL 1 DAY")
    .replaceAll("'20260101'", "DATE '2026-01-01'")
    .replaceAll("'20270101'", "DATE '2027-01-01'")
    .replaceAll('CAST(AVG(sale_value) AS int)', 'CAST(AVG(sale_value) AS INTEGER)')
}

function bigqueryify(text = '') {
  return stripDbo(text)
    .replaceAll("DATEADD(day, 1, a.order_date)", "DATE_ADD(a.order_date, INTERVAL 1 DAY)")
    .replaceAll("'20260101'", "DATE '2026-01-01'")
    .replaceAll("'20270101'", "DATE '2027-01-01'")
    .replace(/\bAS\s+int\b/gi, 'AS INT64')
}

const special = {
  duckdb: {
    'lab-window-top-one': {
      starter: `SELECT *\nFROM employees\nQUALIFY ROW_NUMBER() OVER (\n    PARTITION BY department\n    ORDER BY wage DESC, employee_name\n) = -- finish\n`,
      solution: `SELECT *\nFROM employees\nQUALIFY ROW_NUMBER() OVER (\n    PARTITION BY department\n    ORDER BY wage DESC, employee_name\n) = 1;`,
      solutionExplanation: 'DuckDB can filter a window expression directly with QUALIFY, so the extra CTE used in the T-SQL version is not required.',
    },
    'lab-window-second-highest': {
      starter: `SELECT *\nFROM employees\nQUALIFY DENSE_RANK() OVER (\n    PARTITION BY department\n    ORDER BY wage DESC\n) = -- second distinct wage\n`,
      solution: `SELECT *\nFROM employees\nQUALIFY DENSE_RANK() OVER (\n    PARTITION BY department\n    ORDER BY wage DESC\n) = 2;`,
      solutionExplanation: 'QUALIFY runs after the window calculation, so DuckDB can keep rank 2 in the same SELECT statement.',
    },
  },
  bigquery: {
    'lab-window-top-one': {
      starter: `SELECT *\nFROM employees\nQUALIFY ROW_NUMBER() OVER (\n  PARTITION BY department\n  ORDER BY wage DESC, employee_name\n) = -- finish\n`,
      solution: `SELECT *\nFROM employees\nQUALIFY ROW_NUMBER() OVER (\n  PARTITION BY department\n  ORDER BY wage DESC, employee_name\n) = 1;`,
      solutionExplanation: 'BigQuery supports QUALIFY, so a ranking result can be filtered without wrapping the SELECT in a CTE or subquery.',
    },
    'lab-window-second-highest': {
      starter: `SELECT *\nFROM employees\nQUALIFY DENSE_RANK() OVER (\n  PARTITION BY department\n  ORDER BY wage DESC\n) = -- second distinct wage\n`,
      solution: `SELECT *\nFROM employees\nQUALIFY DENSE_RANK() OVER (\n  PARTITION BY department\n  ORDER BY wage DESC\n) = 2;`,
      solutionExplanation: 'GoogleSQL evaluates QUALIFY after window functions, which makes top-N and rank filters concise.',
    },
  },
}

export function getSqlDialectChallenge(challenge, dialect = 'tsql') {
  if (dialect === 'tsql') {
    return {
      ...challenge,
      dialect,
      dialectLabel: 'T-SQL',
      dialectNote: sqlDialects[0].note,
    }
  }

  const transform = dialect === 'duckdb' ? duckify : bigqueryify
  const override = special[dialect]?.[challenge.id] ?? {}
  const label = dialect === 'duckdb' ? 'DuckDB / source style' : 'BigQuery GoogleSQL'
  const baseExplanation = dialect === 'duckdb'
    ? 'For this exercise the core SQL pattern is portable; schema prefixes are removed to keep the query close to the notebook/DuckDB style.'
    : 'For this exercise the core SQL pattern is portable to GoogleSQL; dataset qualification is intentionally omitted so you can focus on the syntax pattern.'

  return {
    ...challenge,
    dialect,
    dialectLabel: label,
    dialectNote: sqlDialects.find((d) => d.id === dialect)?.note,
    context: transform(challenge.context),
    starter: override.starter ?? transform(challenge.starter),
    solution: override.solution ?? transform(challenge.solution),
    solutionExplanation: override.solutionExplanation ?? `${transform(challenge.solutionExplanation)} ${baseExplanation}`,
    hints: challenge.hints,
  }
}
