import { lessons } from './curriculum.js'
import { cheatSheets } from './cheatSheets.js'
import { extraHubs, hubExtensions } from './learningHubContent.js'

const OFFICIAL = {
  debeziumTutorial: { label: 'Debezium · CDC tutorial', url: 'https://debezium.io/documentation/reference/stable/kc-tutorial.html' },
  debeziumArchitecture: { label: 'Debezium · architecture', url: 'https://debezium.io/documentation/reference/3.1/architecture.html' },
  debeziumMysql: { label: 'Debezium · MySQL connector recovery', url: 'https://debezium.io/documentation/reference/stable/connectors/mysql.html' },
  dbtContracts: { label: 'dbt · model contracts', url: 'https://docs.getdbt.com/docs/mesh/govern/model-contracts' },
  openLineageModel: { label: 'OpenLineage · object model', url: 'https://openlineage.io/docs/spec/object-model/' },
  openLineageAirflow: { label: 'OpenLineage · Airflow guide', url: 'https://openlineage.io/docs/guides/airflow-quickstart/' },
  openLineageSpark: { label: 'OpenLineage · Spark integration', url: 'https://openlineage.io/docs/integrations/spark/installation/' },
  openLineageDbt: { label: 'OpenLineage · dbt integration', url: 'https://openlineage.io/docs/integrations/dbt/' },
  fabricMirroring: { label: 'Microsoft Fabric · mirroring', url: 'https://learn.microsoft.com/en-us/fabric/mirroring/get-started-with-mirroring' },
  fabricOpenMirroring: { label: 'Microsoft Fabric · open mirroring', url: 'https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring' },
  fabricMirrorTroubleshoot: { label: 'Microsoft Fabric · mirroring troubleshooting', url: 'https://learn.microsoft.com/en-us/fabric/mirroring/troubleshooting' },
}

const cdcDiagram = `flowchart LR
  DB[(OLTP database)] --> LOG[Transaction / replication log]
  LOG --> DZ[CDC connector]
  DZ --> K[Change-event stream]
  K --> C[Consumer / Spark / sink]
  C --> L[Lakehouse / warehouse]
  DZ --> O[(Offset / source position)]
  O --> DZ`

const lineageDiagram = `flowchart LR
  A[Airflow run] --> OL[OpenLineage events]
  S[Spark job] --> OL
  D[dbt model/test] --> OL
  OL --> B[Lineage backend]
  B --> I[Impact analysis]
  B --> T[Troubleshooting]
  B --> R[Backfill / replay scope]`

const mirroringDiagram = `flowchart LR
  SRC[(Operational source)] -->|snapshot + changes| M[Fabric Mirroring]
  APP[Custom provider] -->|Parquet / CSV changes| O[Open Mirroring landing zone]
  O --> M
  M --> D[Delta Parquet in OneLake]
  D --> SQL[SQL analytics endpoint]
  D --> SP[Spark / Lakehouse]
  D --> BI[Power BI]`

const R = (x) => ({ sourcePack: 'Web verified · CDC + contracts + lineage + Fabric mirroring · Sep 2026', ...x })

export const dataReliabilityLessons = [
  R({
    id: 'cdc-log-vs-polling', track: 'pipeline-troubleshooting', level: 'Intermediate', language: 'plaintext', title: 'CDC: transaction log vs polling',
    concept: 'Log-based change data capture reads database change/replication logs instead of repeatedly querying tables for rows whose timestamps changed.',
    why: 'CDC can capture inserts, updates and deletes with low latency without requiring a reliable last_updated column or frequent full/table polling.',
    context: 'An orders database changes continuously and deletes must reach the lakehouse. A polling job currently queries WHERE updated_at > last_watermark every minute.',
    task: 'Explain when log-based CDC is a better fit, what state the connector must preserve, and one reason polling can miss changes.',
    starter: 'POLLING RISKS:\n1.\n2.\n\nCDC STATE TO PRESERVE:\n- \n\nWHEN CDC FITS:\n- ',
    solution: 'POLLING RISKS:\n1. Deletes are invisible unless the source exposes tombstones/soft-delete state.\n2. Late or incorrectly maintained timestamps can make updates invisible; aggressive polling also adds source load.\n\nCDC STATE TO PRESERVE:\n- The source log/replication position (connector offset) and the schema/history state required to decode changes.\n\nWHEN CDC FITS:\n- Frequent operational changes, low-latency replication, delete capture and sources with a usable transaction/replication log.\n\nPolling is still reasonable for small/slow sources or APIs without CDC support.',
    hints: ['Think about DELETE events.', 'A CDC connector needs a resumable source position.'],
    pitfall: 'CDC is not automatically exactly-once end to end; downstream consumers still need idempotent keys/write semantics.',
    diagram: cdcDiagram,
    officialSources: [OFFICIAL.debeziumTutorial, OFFICIAL.debeziumArchitecture],
  }),
  R({
    id: 'cdc-envelope-upsert-delete', track: 'pipeline-troubleshooting', level: 'Intermediate', language: 'python', title: 'CDC: turn Debezium envelopes into upserts and deletes',
    concept: 'Debezium change events include an operation code plus before/after row state and source metadata. Consumers must preserve the operation semantics when applying changes.',
    why: 'Flattening every event to after-values can silently lose delete semantics and traceability.',
    context: "A consumer receives Debezium-style events where op is c/u/d/r. For create, update and snapshot-read events use after; for delete use the key/before identity.",
    task: 'Complete a small routing function that returns UPSERT or DELETE commands.',
    starter: `def route_change(event):\n    op = event['op']\n    if op in {'c', 'u', 'r'}:\n        return #\n    if op == 'd':\n        return #\n    raise ValueError(op)`,
    solution: `def route_change(event):\n    op = event['op']\n    if op in {'c', 'u', 'r'}:\n        return ('UPSERT', event['after'])\n    if op == 'd':\n        identity = event.get('before') or event.get('key')\n        return ('DELETE', identity)\n    raise ValueError(f'Unsupported CDC op: {op}')\n\n# Production sinks should also retain source position / event metadata\n# needed for ordering, diagnostics and idempotency.`,
    hints: ['c=create, u=update, d=delete, r=snapshot read.', 'For deletes, after may be null.'],
    pitfall: 'Do not discard op/source metadata before the sink has correctly applied inserts, updates and deletes.',
    diagram: cdcDiagram,
    officialSources: [OFFICIAL.debeziumTutorial],
  }),
  R({
    id: 'cdc-offset-recovery', track: 'pipeline-troubleshooting', level: 'Expert', language: 'plaintext', title: 'CDC: recover after connector downtime',
    concept: 'CDC recovery depends on a durable source position/offset and the source retaining the transaction or replication history needed from that point onward.',
    why: 'A connector can restart safely only while its saved position is still usable; long outages and log retention can force a new snapshot/re-bootstrap.',
    context: 'A connector has been offline for several days. Its saved offset points to source-log history that may already have been purged.',
    task: 'Write a recovery decision tree before restarting the connector.',
    starter: '1. CHECK SAVED OFFSET:\n2. CHECK SOURCE LOG RETENTION:\n3. CHECK SCHEMA HISTORY:\n4. IF OFFSET IS VALID:\n5. IF OFFSET IS NOT VALID:\n6. AFTER RECOVERY:',
    solution: '1. CHECK SAVED OFFSET: identify the connector source position and last successfully emitted/committed event.\n2. CHECK SOURCE LOG RETENTION: verify the corresponding binlog/WAL/replication history still exists.\n3. CHECK SCHEMA HISTORY: ensure the connector can reconstruct table schemas at the resume point.\n4. IF OFFSET IS VALID: resume from it and monitor lag until caught up.\n5. IF OFFSET IS NOT VALID: use the connector/source-supported re-snapshot or re-bootstrap procedure instead of inventing an offset.\n6. AFTER RECOVERY: reconcile source/target keys and counts, then verify delete/update behavior and lag.',
    hints: ['The offset is meaningful only if the source can still serve history from that point.', 'Schema history can matter as much as row-change history.'],
    pitfall: 'Never manually advance an offset only to make a connector start; that can permanently skip source changes.',
    diagram: cdcDiagram,
    officialSources: [OFFICIAL.debeziumMysql, OFFICIAL.debeziumTutorial],
  }),
  R({
    id: 'dbt-model-contract-enforced', track: 'analytics-engineering', level: 'Intermediate', language: 'yaml', title: 'dbt: enforce a model contract',
    concept: 'A dbt model contract defines the expected output shape. With contract.enforced: true, declared column names and data types are checked as part of building the model.',
    why: 'Public marts and shared models should not silently drop or change the type of columns that downstream reports and projects depend on.',
    context: 'dim_customers is a public table model with customer_id BIGINT, customer_name STRING and created_at TIMESTAMP.',
    task: 'Write the properties YAML that enables a contract and declares all three columns.',
    starter: `models:\n  - name: dim_customers\n    config:\n      contract:\n        enforced: #\n    columns:\n      - name: customer_id\n        data_type: #\n      - name: customer_name\n        data_type: #\n      - name: created_at\n        data_type: #`,
    solution: `models:\n  - name: dim_customers\n    config:\n      contract:\n        enforced: true\n    columns:\n      - name: customer_id\n        data_type: bigint\n      - name: customer_name\n        data_type: string\n      - name: created_at\n        data_type: timestamp\n\n# Adapter/platform type names and constraint enforcement differ,\n# so use data types understood by your target platform.`,
    hints: ['Every output column belongs in an enforced model contract.', 'Use adapter/platform-compatible type names.'],
    pitfall: 'Do not assume every declared primary-key/unique/check constraint is physically enforced by every warehouse; platform support varies.',
    officialSources: [OFFICIAL.dbtContracts],
  }),
  R({
    id: 'dbt-contract-vs-test', track: 'analytics-engineering', level: 'Intermediate', language: 'plaintext', title: 'dbt: model contract vs data test',
    concept: 'A model contract governs dataset shape such as column names/types; dbt data tests validate data content and business-quality conditions.',
    why: 'Calling every test a contract hides an important production distinction between interface/schema stability and row-level quality.',
    context: 'A finance mart must keep revenue as DECIMAL and customer_id present; it must also have no duplicate customer_id values and no negative invoice totals.',
    task: 'Classify each requirement as model contract, data test, or potentially both/constraint depending on platform.',
    starter: 'revenue data type =\ncustomer_id column exists =\ncustomer_id uniqueness =\ninvoice_total >= 0 =\n\nWHY:',
    solution: 'revenue data type = MODEL CONTRACT\ncustomer_id column exists = MODEL CONTRACT\ncustomer_id uniqueness = DATA TEST by default; it may also be a declared/enforced constraint only on platforms that actually support that enforcement\ninvoice_total >= 0 = DATA TEST by default; a check constraint is platform-dependent\n\nWHY:\n- Contract: stable model interface/shape checked while building the model.\n- Data test: queryable validation of data content after the model exists.\n\nUse contracts especially for stable/public downstream-facing models rather than every rapidly changing staging model.',
    hints: ['Shape versus content is the main distinction.', 'Constraint enforcement is adapter/platform-specific.'],
    pitfall: 'Do not say “dbt tests are contracts” without qualification; dbt now has a separate model-contract feature.',
    officialSources: [OFFICIAL.dbtContracts],
  }),
  R({
    id: 'lineage-run-event-model', track: 'airflow', level: 'Intermediate', language: 'plaintext', title: 'OpenLineage: understand Job, Run and Dataset events',
    concept: 'OpenLineage models runtime execution with RunEvents and also supports JobEvent and DatasetEvent metadata. RunEvents connect a specific job run to its inputs, outputs and run state.',
    why: 'Lineage becomes operationally useful when you can distinguish static design metadata from what actually ran and failed.',
    context: 'An Airflow task transforms raw.orders into silver.orders and fails halfway through a run.',
    task: 'Map the task name, this execution, raw.orders, silver.orders and FAIL state to the OpenLineage object model.',
    starter: 'JOB =\nRUN =\nINPUT DATASET =\nOUTPUT DATASET =\nRUN STATE =\n\nWHY THIS MATTERS:',
    solution: 'JOB = the logical transformation/task identity\nRUN = this specific execution instance with its run ID\nINPUT DATASET = raw.orders\nOUTPUT DATASET = silver.orders\nRUN STATE = FAIL\n\nWHY THIS MATTERS:\nA lineage backend can correlate a concrete failed run with affected inputs/outputs instead of only showing a static DAG drawing. START/RUNNING/COMPLETE/FAIL-style runtime events describe the execution lifecycle.',
    hints: ['Job is reusable identity; Run is one execution.', 'Datasets are the data inputs/outputs.'],
    pitfall: 'A DAG dependency graph and data lineage overlap, but they are not identical: task ordering alone does not prove which datasets each task actually read or wrote.',
    diagram: lineageDiagram,
    officialSources: [OFFICIAL.openLineageModel, OFFICIAL.openLineageAirflow],
  }),
  R({
    id: 'lineage-impact-debugging', track: 'airflow', level: 'Expert', language: 'plaintext', title: 'Use lineage to scope an incident and backfill',
    concept: 'Cross-tool lineage can connect orchestration runs, Spark jobs, dbt models and datasets so an incident can be scoped by actual upstream/downstream dependencies.',
    why: 'When a bad source partition is discovered, lineage can reduce the blast radius from “rerun everything” to the affected jobs/datasets and consumers.',
    context: 'raw.customer_status for 2026-09-03 is wrong. Airflow runs Spark to build silver.customer, then dbt builds dim_customer used by BI.',
    task: 'Describe how lineage changes your troubleshooting and replay plan.',
    starter: '1. BAD DATASET:\n2. DOWNSTREAM IMPACT:\n3. FAILED/AFFECTED RUNS:\n4. REPLAY SCOPE:\n5. VALIDATION:',
    solution: '1. BAD DATASET: identify raw.customer_status and the affected partition/version.\n2. DOWNSTREAM IMPACT: follow lineage to Spark silver.customer, dbt dim_customer and registered consumers.\n3. FAILED/AFFECTED RUNS: use run metadata to identify executions that consumed the bad input, including successful-but-wrong runs.\n4. REPLAY SCOPE: backfill only the affected partition/runs in dependency order with idempotent writes.\n5. VALIDATION: reconcile corrected outputs and confirm downstream lineage/consumers now reference corrected data.\n\nAirflow, Spark and dbt all have OpenLineage integration paths, but actual field coverage depends on operators/connectors and configuration.',
    hints: ['Successful runs can still have bad data.', 'Lineage should help bound replay, not replace reconciliation.'],
    pitfall: 'Do not assume automatic lineage is complete for every custom operator/UDF/sink; validate emitted metadata coverage.',
    diagram: lineageDiagram,
    officialSources: [OFFICIAL.openLineageAirflow, OFFICIAL.openLineageSpark, OFFICIAL.openLineageDbt],
  }),
  R({
    id: 'fabric-mirroring-vs-etl', track: 'storage-performance', level: 'Intermediate', language: 'plaintext', title: 'Fabric Mirroring vs a hand-built ETL pipeline',
    concept: 'Fabric Mirroring continuously makes supported operational data available in OneLake; Open Mirroring lets applications/providers land change data that Fabric converts into analytics-ready Delta Parquet.',
    why: 'Not every source-to-lake movement needs a custom scheduled extract pipeline, but mirroring also does not replace transformation/business-modeling layers.',
    context: 'An operational SQL source must be available near real time in Fabric for Spark and Power BI. The first requirement is faithful replication, not transformation.',
    task: 'Choose Mirroring/Open Mirroring or custom ETL and explain what still happens downstream.',
    starter: 'INGESTION CHOICE:\n\nWHY:\n\nWHAT MIRRORING HANDLES:\n- \n\nWHAT STILL BELONGS DOWNSTREAM:\n- ',
    solution: 'INGESTION CHOICE:\n- Prefer a supported Fabric Mirroring source when available. Use Open Mirroring when a custom provider/application can write the required change files into the OneLake landing zone. Use custom ETL when the source/requirements do not fit mirroring or substantial transformation must happen during ingestion.\n\nWHAT MIRRORING HANDLES:\n- continuous replication/change application into OneLake and Delta Parquet representation.\n\nWHAT STILL BELONGS DOWNSTREAM:\n- business transformations, quality rules, dimensional/semantic modeling, KPIs and consumer-specific marts.\n\nThe mirrored SQL analytics endpoint is for analytics over the replicated copy; it is not the OLTP source.',
    hints: ['Separate replication from transformation.', 'Mirroring is attractive when the main need is current source data in OneLake.'],
    pitfall: 'Do not describe Mirroring as “no data engineering needed”; quality, modeling, governance and downstream transformations still matter.',
    diagram: mirroringDiagram,
    officialSources: [OFFICIAL.fabricMirroring, OFFICIAL.fabricOpenMirroring],
  }),
  R({
    id: 'fabric-mirroring-troubleshoot', track: 'pipeline-troubleshooting', level: 'Intermediate', language: 'plaintext', title: 'Troubleshoot delayed Fabric Mirroring',
    concept: 'A mirroring delay should be isolated across replication status, source connectivity/configuration, OneLake landing/Delta data and SQL analytics endpoint metadata sync.',
    why: 'If rows are already in OneLake but absent from the SQL endpoint, restarting the source connector is the wrong first fix.',
    context: 'Users report that a mirrored table looks stale in SQL. You need to determine whether replication, OneLake data or endpoint metadata is the failing layer.',
    task: 'Write the diagnostic order and the evidence you would collect.',
    starter: '1. MIRROR STATUS:\n2. TABLE LAST COMPLETED / LATENCY:\n3. SOURCE:\n4. ONELAKE:\n5. SQL ENDPOINT:\n6. AFTER FIX:',
    solution: '1. MIRROR STATUS: check the mirrored database and per-table replication state/alerts.\n2. TABLE LAST COMPLETED / LATENCY: inspect last completed time and, when workspace monitoring is enabled, replication latency evidence.\n3. SOURCE: validate source-specific prerequisites, credentials/network/change-feed state and connector limitations.\n4. ONELAKE: verify whether the expected Delta data has actually landed; Spark/Lakehouse inspection can separate replication from SQL-endpoint issues.\n5. SQL ENDPOINT: if OneLake is current but SQL is stale, investigate metadata synchronization/refresh instead of redoing source replication.\n6. AFTER FIX: reconcile business keys/counts and monitor latency until the backlog is cleared.',
    hints: ['Locate the first stale layer.', 'OneLake current + SQL stale points to a different problem than OneLake stale.'],
    pitfall: 'Do not repeatedly stop/start mirroring before preserving status, latency and source evidence; that can make root-cause analysis harder.',
    diagram: mirroringDiagram,
    officialSources: [OFFICIAL.fabricMirrorTroubleshoot, OFFICIAL.fabricMirroring],
  }),
]

const existingIds = new Set(lessons.map((item) => item.id))
for (const lesson of dataReliabilityLessons) if (!existingIds.has(lesson.id)) lessons.push(lesson)

const dbtHub = extraHubs.find((item) => item.id === 'dbt')
if (dbtHub) {
  dbtHub.mentalModels = (dbtHub.mentalModels ?? []).map((text) =>
    text.includes('Tests are executable data contracts')
      ? 'Data tests validate content; model contracts define/enforce a stable output shape. Source freshness checks arrival expectations.'
      : text,
  )
  if (!dbtHub.sections.some(([title]) => title === 'Model contract')) {
    dbtHub.sections.push(['Model contract', "models:\n  - name: dim_customer\n    config:\n      contract:\n        enforced: true\n    columns:\n      - name: customer_id\n        data_type: bigint"])
  }
  if (!dbtHub.interview.includes('model contracts vs data tests')) dbtHub.interview.push('model contracts vs data tests')
}

const airflow = cheatSheets.find((item) => item.id === 'airflow')
if (airflow) {
  if (!airflow.sections.some(([title]) => title === 'OpenLineage')) {
    airflow.sections.push(['OpenLineage', 'Airflow task run → RunEvent\ninputs / outputs → Datasets\nSTART / COMPLETE / FAIL → run lifecycle\nUse lineage to scope downstream impact and backfills.'])
  }
  if (!airflow.interview.includes('OpenLineage / data lineage')) airflow.interview.push('OpenLineage / data lineage')
}

const dbtExt = hubExtensions.dbt
if (dbtExt?.problems && !dbtExt.problems.some((text) => text.includes('contract'))) {
  dbtExt.problems.push('A public model loses a column used by Power BI. Add an enforced model contract and decide which content checks remain data tests.')
}

const trExt = hubExtensions['pipeline-troubleshooting']
if (trExt?.problems) {
  for (const problem of [
    'A CDC connector was offline beyond source-log retention. Decide whether it can resume or needs a controlled re-snapshot.',
    'Fabric mirrored data is current in OneLake but stale in the SQL analytics endpoint. Isolate the failing layer.',
  ]) if (!trExt.problems.includes(problem)) trExt.problems.push(problem)
}

const deCards = hubExtensions['de-interview']?.interviewCards
if (Array.isArray(deCards)) {
  const additions = [
    ['CDC vs polling', 'Log-based CDC reads source change logs and preserves a resumable source position; polling repeatedly queries source rows.', 'op=c/u/d/r; before/after/source metadata', 'When would you prefer CDC over updated_at polling?', 'When changes are frequent, deletes matter, latency matters and the database exposes a reliable change/replication log. Polling can remain simpler for small/slow sources.', 'Design recovery after the connector offset falls outside retained source logs.'],
    ['Contract vs data test', 'A model contract protects schema/interface shape; data tests validate data content/business quality.', 'contract:\n  enforced: true', 'What is the difference between a dbt model contract and a dbt data test?', 'Contracts check the declared model shape/types while building. Tests run queries/assertions over the built data. Constraint enforcement still varies by platform.', 'Protect a public finance mart from a removed column and duplicate keys.'],
    ['Operational lineage', 'Run-aware lineage connects jobs/runs to input/output datasets and helps scope impact/replay.', 'Airflow → Spark → dbt → BI', 'How does lineage help during a bad-data incident?', 'It identifies downstream datasets/jobs and affected runs so the backfill can be bounded; reconciliation is still required because lineage coverage may be incomplete.', 'Scope a replay for one corrupt source partition.'],
  ]
  for (const card of additions) if (!deCards.some(([title]) => title === card[0])) deCards.push(card)
}
