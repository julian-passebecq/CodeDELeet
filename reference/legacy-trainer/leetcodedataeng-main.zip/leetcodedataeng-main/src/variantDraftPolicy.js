export function shouldRestoreVariantStarter({ editorText = '', starter = '', savedDraft = null } = {}) {
  if (typeof starter !== 'string' || !starter.trim()) return false
  if (typeof editorText === 'string' && editorText.trim()) return false
  if (typeof savedDraft === 'string' && savedDraft.trim()) return false
  return true
}
