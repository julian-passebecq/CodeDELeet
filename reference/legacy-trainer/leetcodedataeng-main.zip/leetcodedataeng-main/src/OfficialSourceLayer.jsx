import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { ExternalLink } from 'lucide-react'
import TechnologyMark from './TechnologyMark'
import { lessons } from './curriculum'
import { sqlChallenges } from './sqlChallenges'
import { engineChallenges } from './engineLab'
import { pythonLabChallenges } from './pythonLab'

const allItems = [...lessons, ...sqlChallenges, ...engineChallenges, ...pythonLabChallenges]

function currentItem(title) {
  if (!title) return null
  return allItems.find((item) => item.title === title) ?? null
}

function ensureMount(meta) {
  if (!meta?.parentElement) return null
  let mount = meta.parentElement.querySelector(':scope > .official-source-mount')
  if (!mount) {
    mount = document.createElement('div')
    mount.className = 'official-source-mount'
    meta.insertAdjacentElement('afterend', mount)
  }
  return mount
}

function OfficialLinks({ sources }) {
  if (!sources?.length) return null
  return (
    <div className="official-source-row" aria-label="Official documentation">
      <span className="official-source-label">OFFICIAL DOCS</span>
      {sources.map((source) => (
        <a key={source.url} href={source.url} target="_blank" rel="noreferrer">
          <TechnologyMark source={source} className="official-source-icon" />
          <span>{source.label}</span>
          <ExternalLink size={10} />
        </a>
      ))}
    </div>
  )
}

export default function OfficialSourceLayer() {
  const [state, setState] = useState({ mount: null, title: '' })

  useEffect(() => {
    let frame = 0
    const sync = () => {
      frame = 0
      const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim() ?? ''
      const meta = document.querySelector('.leetcode-practice .problem-meta')
      const mount = ensureMount(meta)
      setState((old) => old.mount === mount && old.title === title ? old : { mount, title })
    }
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(sync)
    }
    sync()
    const observer = new MutationObserver(schedule)
    observer.observe(document.body, { childList: true, subtree: true, characterData: true })
    return () => {
      observer.disconnect()
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  const item = useMemo(() => currentItem(state.title), [state.title])
  const sources = item?.officialSources ?? []
  if (!state.mount || sources.length === 0) return null
  return createPortal(<OfficialLinks sources={sources} />, state.mount)
}
