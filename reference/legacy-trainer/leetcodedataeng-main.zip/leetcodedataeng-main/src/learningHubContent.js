export const extraHubs = [
  {
    id: 'coding-concepts', label: 'Coding Concepts', icon: 'AL', subtitle: 'Algorithms, complexity and DE coding patterns', language: 'python', practiceTarget: 'Algorithms',
    useFor: ['coding interviews', 'complexity reasoning', 'pipeline utilities', 'dependency / graph problems'],
    sections: [
      ['Complexity', 'O(1) lookup\nO(log n) binary search\nO(n) scan\nO(n log n) efficient sort\nO(n²) nested all-pairs work'],
      ['Core data structures', 'list / array → ordered sequence\ndict / hash map → key lookup\nset → uniqueness + membership\nstack → LIFO\nqueue → FIFO\nheap → efficient top-K'],
      ['DE mental model', 'Prefer one pass + state over repeated rescans.\nEstimate cardinality before joins.\nKnow whether data is sorted/partitioned.\nAvoid materializing more data than needed.'],
      ['Graph mental model', 'DAG nodes = tasks/models\nedges = dependencies\nBFS/DFS = traversal\ntopological sort = valid execution order'],
    ],
    mentalModels: ['First identify input size and required output grain.', 'A hash map often converts repeated O(n) scans into one O(n) build plus cheap lookups.', 'In distributed systems, data movement can dominate CPU complexity.'],
    interview: ['Big-O intuition', 'hash map vs list', 'two pointers', 'sliding window', 'heap/top-K', 'BFS/DFS', 'topological sort', 'sort + dedupe'],
    starter: 'def solve(rows):\n    # State the expected complexity before coding.\n    pass\n',
  },
  {
    id: 'duckdb', label: 'DuckDB', icon: 'DU', subtitle: 'Local analytical SQL on files and DataFrames', language: 'sql', practiceTarget: 'Multi-Engine Lab',
    useFor: ['query Parquet/CSV directly', 'local ELT validation', 'fast analytical prototypes', 'portable SQL'],
    sections: [
      ['Query Parquet', "SELECT *\nFROM read_parquet('landing/orders/*.parquet')\nWHERE status = 'PAID';"],
      ['Aggregate files', "SELECT customer_id, SUM(amount) AS revenue\nFROM read_csv_auto('sales.csv')\nGROUP BY customer_id;"],
      ['QUALIFY', "SELECT *\nFROM history\nQUALIFY ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY updated_at DESC) = 1;"],
      ['EXPLAIN', "EXPLAIN ANALYZE\nSELECT customer_id, SUM(amount)\nFROM sales\nGROUP BY customer_id;"],
    ],
    mentalModels: ['DuckDB is an in-process analytical database; there is no separate server to administer.', 'It is optimized for OLAP-style scans and aggregations, not high-concurrency OLTP.', 'Push filters/projections into file scans and let DuckDB operate columnarly.'],
    interview: ['DuckDB vs SQLite/Postgres', 'Parquet pushdown', 'QUALIFY', 'when DuckDB beats Spark', 'read_parquet/read_csv_auto', 'in-process architecture'],
    starter: "SELECT customer_id,\n       -- latest row per customer\nFROM read_parquet('history.parquet');\n",
  },
  {
    id: 'dbt', label: 'dbt', icon: 'dbt', subtitle: 'SQL transformation engineering, tests and lineage', language: 'sql', practiceTarget: 'T-SQL',
    useFor: ['modular SQL models', 'quality tests', 'documentation + lineage', 'incremental transformations'],
    sections: [
      ['ref()', "SELECT customer_id, SUM(amount) AS revenue\nFROM {{ ref('stg_orders') }}\nGROUP BY customer_id"],
      ['Tests', "models:\n  - name: dim_customer\n    columns:\n      - name: customer_id\n        data_tests: [not_null, unique]"],
      ['Incremental', "{{ config(materialized='incremental', unique_key='order_id') }}\nSELECT * FROM {{ ref('stg_orders') }}\n{% if is_incremental() %}\nWHERE updated_at > (SELECT MAX(updated_at) FROM {{ this }})\n{% endif %}"],
      ['Snapshot / SCD2', "{% snapshot customer_snapshot %}\n{{ config(unique_key='customer_id', strategy='timestamp', updated_at='updated_at') }}\nSELECT * FROM {{ source('raw','customers') }}\n{% endsnapshot %}"],
    ],
    mentalModels: ['dbt owns transformation logic in the warehouse; it is not an ingestion engine.', 'ref() creates dependency edges and stable relation references.', 'Tests are executable data contracts; source freshness tests arrival expectations.'],
    interview: ['ref vs source', 'materializations', 'tests + relationships', 'incremental late data', 'snapshots / SCD2', 'macros / Jinja', 'dbt CI / slim CI'],
    starter: "{{ config(materialized='incremental', unique_key='customer_id') }}\n\nSELECT customer_id, updated_at\nFROM {{ ref('stg_customer') }}\n-- add a safe incremental predicate\n",
  },
  {
    id: 'de-interview', label: 'Data Engineering Interview', icon: 'DE', subtitle: 'Cloud, databases, modeling, quality, architecture and DevOps', language: 'plaintext', practiceTarget: 'Start here',
    useFor: ['DE interviews', 'architecture discussion', 'database fundamentals', 'cloud/platform trade-offs'],
    sections: [
      ['Keys', 'Primary key → unique row identity\nForeign key → relationship / integrity\nNatural key → business identifier\nSurrogate key → warehouse-generated identifier\nComposite key → identity from multiple columns'],
      ['Indexes', 'B-tree → equality + range access\nClustered → storage/order concept (engine-specific)\nNonclustered → separate lookup structure\nComposite → column order matters\nMore indexes → slower writes'],
      ['Data quality', 'Completeness · uniqueness · validity · consistency · timeliness · referential integrity\nTest ingestion, transformation and serving boundaries.'],
      ['Reliable pipeline', 'idempotent writes\nwatermark / checkpoint\nbounded retries\nquarantine / DLQ\nobservability + lineage\nreplay / backfill plan'],
      ['CI/CD', 'PR → lint/unit tests → SQL/dbt tests → build → deploy dev/test → integration checks → promote prod\nVersion code, schema contracts and infrastructure.'],
      ['Cloud lens', 'Azure: ADLS + Fabric/ADF/Databricks/Synapse\nAWS: S3 + Glue/EMR/Redshift\nGCP: GCS + Dataflow/Dataproc/BigQuery\nCompare storage, compute, orchestration, governance and cost.'],
    ],
    mentalModels: ['Separate storage, compute, orchestration, serving and governance when explaining architecture.', 'Choose batch vs streaming from business latency requirements.', 'Correctness, recoverability and observability matter as much as throughput.'],
    interview: ['incremental ingestion design', 'SCD1 vs SCD2', 'partitioning vs indexing', 'Databricks vs Snowflake vs Fabric', 'idempotency', 'schema evolution', 'CI/CD', 'quality + reconciliation'],
    starter: 'Source → Ingest → Bronze → Silver → Gold → Semantic/Serving\n\nFor each arrow explain:\n- storage / compute\n- quality contract\n- retry / replay\n- observability\n',
  },
  {
    id: 'bi', label: 'BI · Finance · Logistics', icon: 'BI', subtitle: 'Models, KPIs, DAX, finance and operational analytics', language: 'plaintext', practiceTarget: 'DAX',
    useFor: ['Power BI', 'P&L / finance', 'sales + margin analysis', 'logistics KPIs'],
    sections: [
      ['P&L', 'Revenue\n- COGS\n= Gross Profit\n- Operating Expenses\n= EBITDA\n- Depreciation & Amortization\n= EBIT\n- Interest / Tax\n= Net Income'],
      ['DAX', 'Revenue = SUM(FactSales[Revenue])\nCOGS = SUM(FactSales[COGS])\nGross Profit = [Revenue] - [COGS]\nGross Margin % = DIVIDE([Gross Profit], [Revenue])'],
      ['SQL equivalent', "SELECT period, SUM(revenue) revenue, SUM(cogs) cogs,\n       SUM(revenue-cogs) gross_profit,\n       1.0*SUM(revenue-cogs)/NULLIF(SUM(revenue),0) gross_margin_pct\nFROM fact_sales GROUP BY period;"],
      ['pandas equivalent', "kpi = df.groupby('period', as_index=False).agg(revenue=('revenue','sum'), cogs=('cogs','sum'))\nkpi['gross_profit'] = kpi.revenue - kpi.cogs\nkpi['gross_margin_pct'] = kpi.gross_profit / kpi.revenue"],
      ['Logistics', 'OTIF = on-time & in-full deliveries / deliveries\nFill rate = fulfilled qty / ordered qty\nInventory turnover = COGS / average inventory\nDays inventory = average inventory / COGS × days'],
      ['Statistics / economics', 'Weighted average ≠ simple average\nMedian resists outliers\nStd. deviation measures dispersion\nYoY % = current / prior - 1\nWorking capital = current assets - current liabilities\nDSO / DPO / DIO explain cash-cycle timing'],
    ],
    mentalModels: ['Define fact grain and dimensions before measures.', 'Star schemas usually simplify filters and BI performance.', 'Recompute ratios from aggregated numerators/denominators; do not blindly average row percentages.'],
    interview: ['star vs snowflake', 'fact vs dimension + grain', 'measure vs calculated column', 'filter context', 'P&L / EBITDA / EBIT', 'YoY and weighted averages', 'OTIF / inventory turnover', 'SCD2'],
    starter: 'Gross Margin % =\nVAR Revenue = [Revenue]\nVAR GrossProfit = [Gross Profit]\nRETURN\n    -- safe division\n',
  },
]

const commonAlgorithms = [
  ['Hash map / dictionary', 'Build one lookup, then probe by key. Typical use: dedupe, frequency counts, joins. O(n) build; O(1) average lookup.'],
  ['Two pointers', 'Walk two ordered inputs once. Useful for merge/reconciliation. O(n + m).'],
  ['Sliding window', 'Keep only state for the current interval instead of recomputing every window. Often O(n).'],
  ['Prefix sums', 'Build cumulative totals once; answer range totals cheaply. O(n) build, O(1) range query.'],
  ['Heap / Top-K', 'Keep a heap of K candidates instead of sorting everything. O(n log k).'],
  ['BFS / DFS', 'Traverse dependency/lineage graphs or nested structures. O(V + E).'],
  ['Topological sort', 'Order DAG tasks/models so dependencies run first. O(V + E).'],
  ['Sort + dedupe', 'Sort by business key + recency, then keep the winning row. O(n log n).'],
]

const sqlPatterns = [
  ['Window ranking', 'ROW_NUMBER / RANK / DENSE_RANK for latest-row, top-N and dedupe.'],
  ['Relational joins', 'INNER / LEFT / FULL based on which unmatched rows must survive.'],
  ['Set operations', 'UNION / INTERSECT / EXCEPT and anti-joins for reconciliation.'],
  ['Aggregation grain', 'Choose GROUP BY keys from the business grain before writing aggregates.'],
  ['Recursive traversal', 'Recursive CTE for hierarchies; use graph tools when traversal becomes the main workload.'],
]

const sparkPatterns = [
  ['Broadcast hash join', 'Replicate a small dimension to workers to avoid shuffling the large side.'],
  ['Sort-merge join', 'Common strategy for large equi-joins after repartition/sort by key.'],
  ['Partition-aware aggregation', 'Reduce before wide operations and choose keys that avoid unnecessary shuffle.'],
  ['Skew handling', 'Detect hot keys; salt/split them or change join strategy.'],
  ['Top-K per group', 'Window partition + order + row_number/rank, while understanding shuffle cost.'],
]

export const hubExtensions = {
  'coding-concepts': {
    algorithms: commonAlgorithms,
    problems: ['Deduplicate event IDs while preserving first-seen order.', 'Return the top 10 largest files from a stream.', 'Merge two sorted event streams by timestamp.', 'Find a valid execution order for pipeline dependencies.', 'Compute rolling failures in the last N jobs.'],
  },
  python: {
    algorithms: commonAlgorithms,
    problems: ['Parse nested JSON with optional fields.', 'Group records by key without pandas.', 'Deduplicate rows keeping latest updated_at.', 'Yield file paths in deterministic batches.', 'Implement bounded retry/backoff with non-retryable errors.'],
    interviewCards: [
      ['Collections + complexity', 'dict/set use hashing for average O(1) membership.', 'seen = set()\nif row["id"] not in seen:\n    seen.add(row["id"])', 'When use a set instead of a list?', 'When uniqueness or frequent membership checks matter more than indexed order.', 'Deduplicate event IDs while preserving first-seen order.'],
      ['Generators', 'yield produces values lazily instead of materializing the full result.', 'def batches(rows, size):\n    for i in range(0, len(rows), size):\n        yield rows[i:i+size]', 'Why are generators useful in ETL control code?', 'They reduce peak memory and support streaming/lazy iteration.', 'Yield input paths in batches of 100.'],
      ['Mutable defaults', 'Default arguments are evaluated once when the function is defined.', 'def add(x, items=None):\n    items = [] if items is None else items\n    items.append(x)\n    return items', 'Why is def f(items=[]) dangerous?', 'The same list instance is reused across calls.', 'Fix a helper that leaks state between pipeline calls.'],
      ['Retries', 'Retry transient failures only; keep attempts bounded and observable.', 'for attempt in range(3):\n    try:\n        return call_api()\n    except TimeoutError:\n        sleep(2 ** attempt)', 'Why is except Exception: pass dangerous?', 'It hides failures and can let bad data continue silently.', 'Design a retry that never retries authentication failures.'],
    ],
  },
  pandas: {
    algorithms: [...commonAlgorithms.slice(0, 4), ['Vectorization', 'Prefer column/array operations over Python row loops.'], ['Index alignment', 'Series align by labels; validate indexes before combining data.']],
    problems: ['Latest row per customer.', 'Join orders to customers and audit unmatched keys.', 'Weighted average selling price.', 'Compare two DataFrames for inserted/changed/missing rows.', 'Vectorize a multi-band classification.'],
    interviewCards: [
      ['Vectorization', 'Vectorized operations avoid Python-level row loops.', 'df["net"] = df["revenue"] - df["cost"]', 'Why avoid iterrows for large transforms?', 'It is slow and bypasses vectorized execution.', 'Replace a row-loop category rule with np.select.'],
      ['Join validation', 'Expected cardinality must be explicit before merge.', 'orders.merge(customers, on="customer_id", how="left", validate="many_to_one", indicator=True)', 'How detect an accidental many-to-many join?', 'Validate grain/cardinality and compare row counts/duplicates before and after.', 'Find order keys with no matching dimension row.'],
      ['Weighted metrics', 'Average of group percentages can be wrong when weights differ.', 'weighted = (df.price * df.qty).sum() / df.qty.sum()', 'When is mean(mean_per_group) incorrect?', 'When groups have unequal weights and the goal is the overall weighted result.', 'Compute weighted average selling price by month.'],
    ],
  },
  pyspark: {
    algorithms: [...sparkPatterns, ...commonAlgorithms.slice(0, 3)],
    problems: ['Latest record per business key with Window.', 'Broadcast a small dimension.', 'Diagnose a skewed join.', 'Choose repartition vs coalesce before a write.', 'Incrementally MERGE into Delta.'],
    interviewCards: [
      ['Lazy evaluation', 'Transformations build a plan; actions/writes trigger execution.', 'result = df.filter("status = \'ACTIVE\'").groupBy("customer_id").count()', 'What triggers a Spark job?', 'An action or write that materializes the plan.', 'Mark where shuffles occur in filter → groupBy → join → write.'],
      ['Shuffle', 'Wide operations redistribute data across partitions.', 'df.groupBy("customer_id").agg(F.sum("amount"))', 'Which operations commonly shuffle?', 'groupBy, join, distinct, orderBy and repartition can shuffle.', 'Reduce a pipeline that performs two avoidable shuffles.'],
      ['Broadcast join', 'A small table can be replicated to executors instead of shuffling both sides.', 'fact.join(F.broadcast(dim), "product_id")', 'When should you not broadcast?', 'When the dimension is too large for executor memory or changes size unpredictably.', 'Choose a join strategy for 2 TB facts + 20 MB dimension.'],
    ],
  },
  sql: {
    algorithms: [...sqlPatterns, ...commonAlgorithms.slice(0, 3)],
    problems: ['Latest row per customer.', 'Top 3 products per category.', 'Reconcile source and target with FULL JOIN.', 'Detect duplicates at the intended grain.', 'Implement SCD Type 2 change handling.'],
    interviewCards: [
      ['Primary / foreign keys', 'PK identifies a row; FK links to a candidate/primary key and can enforce integrity.', 'CREATE TABLE fact_order (order_id bigint PRIMARY KEY, customer_id bigint REFERENCES dim_customer(customer_id));', 'Can a primary key contain NULL?', 'No; a primary key is unique and non-null.', 'Choose natural vs surrogate keys for a customer dimension.'],
      ['Indexes', 'Indexes accelerate reads by maintaining search structures but add storage/write cost.', 'CREATE INDEX IX_orders_customer_date ON dbo.orders(customer_id, order_date) INCLUDE (amount);', 'Why does composite index column order matter?', 'The leading key columns determine which predicates/orderings can efficiently seek the index.', 'Design an index for customer + date range queries.'],
      ['Window vs GROUP BY', 'GROUP BY changes grain; window functions preserve rows.', 'SUM(amount) OVER (PARTITION BY customer_id) AS customer_total', 'When use a window instead of GROUP BY?', 'When you need an aggregate/rank while retaining row-level detail.', 'Return each order with customer lifetime revenue.'],
      ['SCD Type 2', 'SCD2 preserves history by expiring the old dimension row and inserting a new version.', 'valid_from · valid_to · is_current', 'What business key vs surrogate key roles exist in SCD2?', 'Business key identifies the entity; surrogate key identifies each historical version.', 'Design an idempotent SCD2 load.'],
    ],
  },
  duckdb: {
    algorithms: [...sqlPatterns, ['Vectorized execution', 'DuckDB processes vectors/chunks rather than one tuple at a time.'], ['Pushdown', 'Push filters and projections into Parquet scans.']],
    problems: ['Query partitioned Parquet without pandas.', 'Latest row with QUALIFY.', 'Join two local Parquet datasets.', 'Profile a query with EXPLAIN ANALYZE.', 'Export a transformed query directly to Parquet.'],
    interviewCards: [
      ['In-process OLAP', 'DuckDB runs inside the application process and is optimized for analytical work.', "SELECT COUNT(*) FROM read_parquet('events/*.parquet');", 'When prefer DuckDB over Spark?', 'When data fits a single machine and local analytical execution avoids distributed overhead.', 'Choose DuckDB vs Spark for 8 GB of Parquet on a developer laptop.'],
      ['Parquet pushdown', 'Columnar file scans can skip unused columns and row groups.', "SELECT customer_id FROM read_parquet('sales.parquet') WHERE sale_date >= DATE '2026-01-01';", 'What is projection pushdown?', 'Reading only referenced columns from the source.', 'Rewrite SELECT * to minimize scan work.'],
    ],
  },
  dbt: {
    algorithms: [['DAG / topological sort', 'ref() builds model dependencies; execution follows a valid dependency order.'], ['Incremental watermark', 'Process only new/changed data while handling late arrivals.'], ['SCD2 snapshot pattern', 'Preserve historical versions of changing attributes.'], ['Contract testing', 'Test uniqueness, nullability, relationships and business invariants.']],
    problems: ['Create a staged orders model with source().', 'Add unique/not_null/relationships tests.', 'Build an incremental model safe for late-arriving rows.', 'Explain when ephemeral materialization is appropriate.', 'Design a dbt CI job that only builds modified models + children.'],
    interviewCards: [
      ['ref vs source', 'source() names raw/external relations; ref() links dbt models and builds lineage.', "SELECT * FROM {{ ref('stg_orders') }}", 'Why avoid hard-coded database.schema.table inside models?', 'ref/source improve environment portability, lineage and dependency ordering.', 'Refactor a hard-coded model into source + ref.'],
      ['Incremental models', 'Incremental models reduce work but must handle updates, late data and backfills.', "{% if is_incremental() %} WHERE updated_at >= DATEADD(day,-2,(SELECT MAX(updated_at) FROM {{ this }})) {% endif %}", 'Why use a lookback window?', 'To reprocess late-arriving or updated records near the watermark.', 'Design incremental logic for orders updated up to 48h late.'],
      ['Tests', 'Generic tests cover reusable constraints; singular tests express custom SQL invariants.', 'data_tests: [not_null, unique]', 'Is a dbt test the same as unit testing application code?', 'No; many dbt tests validate data/model contracts after SQL execution.', 'Add a relationship test from fact_order.customer_id to dim_customer.'],
    ],
  },
  airflow: {
    algorithms: [['Topological sort', 'A DAG scheduler must respect upstream dependencies.'], ['Queue / priority', 'Schedulers select runnable work under pools, priorities and concurrency limits.'], ['Retry/backoff', 'Bound retries and separate transient from permanent failures.']],
    problems: ['Build extract → transform → load dependencies.', 'Make a partition load idempotent.', 'Explain catchup and backfill.', 'Keep large datasets out of XCom.', 'Design retry + timeout behavior for an API task.'],
  },
  powershell: {
    algorithms: [['Pipeline filtering', 'Filter/select objects as they stream through the pipeline.'], ['Hash-table lookup', 'Use hashtables for configuration and keyed state.'], ['Batching', 'Chunk file/API work instead of loading everything at once.']],
    problems: ['List CSV files > 1 MB.', 'Call a REST API using an environment token.', 'Check SQL Server port connectivity.', 'Process files with try/catch and a failure log.', 'Build a hashtable from configuration records.'],
  },
  'csharp-functions': {
    algorithms: commonAlgorithms.slice(0, 5),
    problems: ['Async HTTP ingestion function.', 'Queue-trigger idempotency key.', 'LINQ group + aggregate.', 'Retry transient HTTP failures.', 'Deserialize and validate JSON payloads.'],
  },
  'csharp-tabular': {
    algorithms: [['Filtering + projection', 'LINQ Where/Select over model metadata.'], ['Grouping', 'Group measures/columns by metadata or naming pattern.'], ['Traversal', 'Walk model tables, measures and relationships safely.']],
    problems: ['Move selected measures to a display folder.', 'Create measures from a naming convention.', 'Apply format strings in bulk.', 'Find measures with missing descriptions.', 'Add annotations to selected objects.'],
  },
  dax: {
    algorithms: [['Filter-context transformation', 'CALCULATE changes filter context before evaluating an expression.'], ['Iteration', 'X-functions iterate a table expression.'], ['Time comparison', 'Compare current period to prior period using a proper date dimension.']],
    problems: ['Gross margin %.', 'YoY revenue growth.', 'Rolling 12-month revenue.', 'Share of total ignoring product filter.', 'Weighted average selling price.'],
  },
  kubernetes: {
    algorithms: [['Reconciliation loop', 'Controllers continually compare desired vs actual state.'], ['Scheduling constraints', 'Scheduler filters/scores candidate nodes.'], ['Backoff / restart', 'Retries and restart policy interact with probes and failure modes.']],
    problems: ['Diagnose CrashLoopBackOff.', 'Read logs from the correct namespace.', 'Explain Deployment vs Service.', 'Configure readiness vs liveness probes.', 'Find a missing ConfigMap/Secret reference.'],
  },
  bi: {
    algorithms: [['Aggregation grain', 'Define business grain before KPIs.'], ['Weighted average', 'Aggregate numerator/denominator separately; do not average percentages blindly.'], ['Time comparison', 'Current vs prior period using a conformed date dimension.'], ['Variance bridge', 'Actual - Budget, price/volume/mix decomposition where appropriate.']],
    problems: ['Build a P&L matrix from account mappings.', 'Gross margin % in DAX + SQL + pandas.', 'YoY revenue and variance to budget.', 'OTIF and fill-rate dashboard.', 'Inventory turnover and days inventory.', 'Weighted average price without average-of-averages error.'],
    interviewCards: [
      ['Star schema', 'Facts store measurable events at a declared grain; dimensions describe them.', 'FactSales → DimDate / DimProduct / DimCustomer', 'Why is fact grain the first modeling question?', 'Because joins, measures, uniqueness and additive behavior all depend on what one fact row represents.', 'Design a sales model supporting daily product/customer analysis.'],
      ['P&L', 'Gross Profit = Revenue - COGS; EBITDA subtracts operating expenses before D&A.', 'Gross Margin % = DIVIDE([Revenue]-[COGS],[Revenue])', 'Why use margin % alongside gross profit?', 'Profit gives absolute value; margin normalizes profitability relative to revenue.', 'Explain a month with growing revenue but falling gross margin.'],
      ['Logistics KPIs', 'OTIF measures service reliability; inventory turnover measures inventory efficiency.', 'OTIF = OnTimeInFull / Deliveries', 'Can high inventory improve OTIF but hurt another KPI?', 'Yes; service can improve while turnover/cash efficiency worsens.', 'Propose a balanced logistics KPI set.'],
      ['Statistics', 'Median is robust to outliers; weighted means preserve population weights.', 'weighted_avg = SUMX(rows, value*weight)/SUMX(rows, weight)', 'Why is correlation not causation?', 'Association can be driven by confounding variables, reverse causality or coincidence.', 'Choose mean vs median for highly skewed delivery delays.'],
    ],
  },
  'de-interview': {
    algorithms: [['Hash partitioning', 'Distribute records by key; understand skew.'], ['Merge / watermark', 'Incrementally process new/changed rows and reconcile target state.'], ['Topological sort', 'Order dependent models/tasks.'], ['Bloom/filter intuition', 'Probabilistic membership structures can reduce expensive lookups in some systems.'], ['Compaction', 'Merge many small files to improve scan efficiency.']],
    problems: ['Design an idempotent incremental ingestion pipeline.', 'Choose partition keys for a 5 TB event table.', 'Explain PK/FK/index vs partitioning.', 'Design Bronze/Silver/Gold quality checks.', 'Compare Databricks, Snowflake and Fabric for a new platform.', 'Design CI/CD for dbt + PySpark + Terraform.', 'Handle schema evolution and replay after a bad deployment.'],
    interviewCards: [
      ['Database keys', 'PK uniquely identifies; FK relates; surrogate keys stabilize warehouse history.', 'business_key + surrogate_key + valid_from + valid_to', 'Natural or surrogate key for SCD2 dimension?', 'Use the natural/business key to identify the entity and a surrogate key for each historical version.', 'Model customer history with SCD2.'],
      ['Indexes vs partitions', 'Indexes accelerate lookup paths; partitions divide data physically/logically for pruning/management.', 'INDEX(customer_id, order_date)\nPARTITION BY load_date', 'Are partitioning and indexing interchangeable?', 'No; they solve different access/management problems and are engine-specific.', 'Choose both for a large order table.'],
      ['Data quality', 'Quality should be measurable and placed at boundaries.', 'not_null · unique · accepted_values · relationships · reconciliation', 'Where would you quarantine bad records?', 'At a controlled boundary where raw evidence remains recoverable and downstream trusted layers stay clean.', 'Design quality gates from Bronze to Gold.'],
      ['Cloud architecture', 'Separate storage, compute, orchestration, governance and serving.', 'ADLS/S3/GCS → Spark/SQL → warehouse/lakehouse → BI', 'Databricks vs Snowflake vs Fabric?', 'Compare workload mix, ecosystem, governance, openness, operations, skills and cost rather than naming one universal winner.', 'Choose a platform for an Azure-heavy Power BI organization.'],
      ['DevOps / dbt', 'PR-based delivery should validate code and data contracts before promotion.', 'PR → tests → build → deploy test → integration → prod', 'What belongs in CI for data engineering?', 'Lint/unit tests, SQL/dbt tests, schema/contracts, package/build validation and targeted integration tests.', 'Design CI/CD for dbt + Airflow + Terraform.'],
    ],
  },
}
