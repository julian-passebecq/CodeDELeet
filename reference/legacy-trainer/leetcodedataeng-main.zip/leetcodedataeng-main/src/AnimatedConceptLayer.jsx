import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { ChevronLeft, ChevronRight, Pause, Play, RotateCcw } from 'lucide-react'
import { lessons } from './curriculum'
import { sqlChallenges } from './sqlChallenges'
import { engineChallenges } from './engineLab'
import { pythonLabChallenges } from './pythonLab'

const allItems = [...lessons, ...sqlChallenges, ...engineChallenges, ...pythonLabChallenges]

const SCENES = {
  scan: ['Row-by-row scan', 'O(n)', ['Start at the first row.', 'Compare the current row.', 'No match: move forward.', 'Keep scanning.', 'Match found: stop.', 'Return the matching row.']],
  binary: ['Binary search halves the search space', 'O(log n)', ['Start with a sorted search space.', 'Inspect the midpoint.', 'Discard the impossible half.', 'Inspect the new midpoint.', 'Stop when the target is found.']],
  hash: ['Build a hash lookup once', 'O(n) build · O(1) avg lookup', ['Start with raw keys.', 'Read one key.', 'Update its bucket.', 'Continue without rescanning old rows.', 'Lookup jumps directly to a bucket.']],
  dedupe: ['Seen set + ordered output', 'O(n) avg', ['Start with an empty seen set.', 'Read the next value.', 'New value: add it to seen and output.', 'Repeated value: skip it.', 'Continue while preserving first-seen order.']],
  stackqueue: ['Stack vs queue', 'LIFO vs FIFO', ['Load the same items into both structures.', 'A stack removes the newest item first.', 'A queue removes the oldest item first.', 'Choose the structure from the ordering rule.']],
  batch: ['Bound work into batches', 'O(n)', ['Start with one long input stream.', 'Take only the next bounded chunk.', 'Process that chunk.', 'Advance to the next chunk.', 'Stop after the final partial batch.']],
  rank: ['Window rank → keep latest row', 'PARTITION → ORDER → ROW_NUMBER → FILTER', ['Raw rows keep their detail.', 'Partition rows by business key.', 'Order newest first inside each partition.', 'Assign ROW_NUMBER within each partition.', 'Keep only rn = 1.']],
  sort: ['Stable sort by explicit key', 'O(n log n)', ['Unordered input.', 'Compare keys.', 'Move the smallest key forward.', 'Preserve tie order with a stable sort.', 'Ordered output.']],
  pointers: ['Two pointers merge sorted streams', 'O(n + m)', ['Place one pointer on each stream.', 'Compare current values.', 'Emit the smaller value.', 'Advance only that pointer.', 'Continue until one stream ends.', 'Append the remaining tail.']],
  sliding: ['Sliding window reuses state', 'O(n)', ['Sum the first window.', 'Slide right one position.', 'Subtract the row leaving the window.', 'Add the new row entering the window.', 'Keep the best rolling value.']],
  prefix: ['Prefix sums answer ranges fast', 'O(n) build · O(1) range', ['Start cumulative state at 0.', 'Add the next value.', 'Store every cumulative total.', 'A range is right prefix minus left prefix.', 'Answer without rescanning the range.']],
  topk: ['Top K without sorting everything', 'O(n log k)', ['Read the first candidate.', 'Keep a bounded K-sized structure.', 'Compare the next candidate with the current minimum.', 'Replace only when the candidate belongs in Top K.', 'Return the final K values.']],
  bfs: ['BFS explores lineage level by level', 'O(V + E)', ['Queue the starting node.', 'Visit the current node.', 'Queue unseen children.', 'Process the next level.', 'Continue until the queue is empty.']],
  topo: ['Topological order releases ready tasks', 'DAG ordering', ['Count incoming dependencies.', 'Tasks with indegree 0 are ready.', 'Run one ready task.', 'Decrease child indegrees.', 'Release newly-ready tasks.', 'If nodes remain blocked, a cycle exists.']],
  intervals: ['Sort then merge overlapping windows', 'O(n log n)', ['Start with raw intervals.', 'Sort intervals by start.', 'Compare with the last merged interval.', 'Extend when intervals overlap.', 'Start a new interval when they do not.']],
  partition: ['Prune data before scanning it', 'Partitioning / clustering', ['Without layout knowledge, many blocks are candidates.', 'Partition pruning removes unrelated date groups.', 'Clustering narrows candidate blocks further.', 'Scan only the remaining blocks.']],
  join: ['Join keys connect matching rows', 'Key → match → output', ['Read keys from the left table.', 'Build or inspect matching keys on the right.', 'Match equal keys.', 'Emit joined rows.', 'Unmatched rows depend on join type.']],
  medallion: ['Bronze → Silver → Gold', 'Raw → clean → business-ready', ['Land raw data unchanged.', 'Validate and standardize into Silver.', 'Deduplicate and conform business keys.', 'Aggregate/model into Gold.', 'Serve trusted analytical outputs.']],
  git: ['Git moves changes through states', 'working tree → staging → commit → remote', ['Edit files in the working tree.', 'git add moves selected changes to staging.', 'git commit records a local snapshot.', 'pull/rebase integrates upstream changes.', 'git push updates the remote branch.']],
}

function resolveScene(item) {
  if (!item) return null
  const text = `${item.id ?? ''} ${item.title ?? ''} ${item.concept ?? ''} ${item.task ?? ''}`.toLowerCase()
  if (/row_number|qualify|latest record|latest row|rank rows/.test(text)) return 'rank'
  if (item.track === 'algorithms' && /deduplic|dedupe/.test(text)) return 'dedupe'
  if (/binary search/.test(text)) return 'binary'
  if (/linear search/.test(text)) return 'scan'
  if (/stack vs queue|stack.*lifo|queue.*fifo/.test(text)) return 'stackqueue'
  if (item.track === 'algorithms' && /batch|chunk/.test(text)) return 'batch'
  if (/frequency|hash map|hash lookup|nested-loop lookup/.test(text)) return 'hash'
  if (/two pointer/.test(text)) return 'pointers'
  if (/sliding window/.test(text)) return 'sliding'
  if (/prefix sum/.test(text)) return 'prefix'
  if (/heap|top k|top-k/.test(text)) return 'topk'
  if (/topological/.test(text)) return 'topo'
  if (/\bbfs\b|graph traversal/.test(text)) return 'bfs'
  if (/merge overlapping interval|merge interval/.test(text)) return 'intervals'
  if (/sorting|stable sort/.test(text)) return 'sort'
  if (/partition design|partitioning|clustering|partition prune|pruning/.test(text)) return 'partition'
  if (/bronze.*silver.*gold|silver.*gold|delta.*merge|gold merge/.test(text)) return 'medallion'
  if (item.track === 'git' || /git add|git commit|git push|update before pushing/.test(text)) return 'git'
  if (/\bjoin\b/.test(text) && !/stream-stream join/.test(text)) return 'join'
  return null
}

function ensurePracticeMount() {
  const description = document.querySelector('.problem-description')
  if (!description) return null
  let mount = description.querySelector(':scope > .animated-concept-mount')
  if (!mount) {
    mount = document.createElement('div')
    mount.className = 'animated-concept-mount'
    const diagram = description.querySelector(':scope > .practice-diagram-mount')
    const context = description.querySelector('.problem-context')
    if (diagram) description.insertBefore(mount, diagram)
    else if (context) context.insertAdjacentElement('afterend', mount)
    else description.querySelector('.problem-meta')?.insertAdjacentElement('afterend', mount)
  }
  return mount
}

function ensureCheatMount() {
  const page = document.querySelector('.learning-hub-page')
  const active = page?.querySelector('.hub-five-part-nav button.active')
  const content = page?.querySelector('.hub-tab-content')
  const patternGrid = content?.querySelector('.hub-pattern-grid')
  if (!page || !content || !patternGrid || !/Algorithms\s*\/\s*patterns/i.test(active?.textContent ?? '')) return null
  let mount = content.querySelector(':scope > .visual-cheat-mount')
  if (!mount) {
    mount = document.createElement('div')
    mount.className = 'visual-cheat-mount'
    content.insertBefore(mount, patternGrid)
  }
  return mount
}

function CellRow({ values, className = '', active = () => false, label = () => null }) {
  return <div className={`vc-cell-row ${className}`}>{values.map((value, index) => <span key={`${value}-${index}`} className={active(index, value)}>{value}{label(index, value)}</span>)}</div>
}

function ScanVisual({ step }) {
  const rows = [['u1', '84', false], ['u2', '41', false], ['u3', '73', false], ['u4', '120', true], ['u5', '55', false]]
  const active = Math.min(step, 3)
  return <div className="vc-table vc-scan-table"><p className="vc-predicate">target amount = 120</p>{rows.map(([id, value, match], index) => <div key={id} className={`vc-row ${index === active ? 'active' : ''} ${step >= 4 && match ? 'match' : ''} ${index < active ? 'passed' : ''}`}><span>{id}</span><strong>{value}</strong><small>{index === active && step < 4 ? 'compare' : match && step >= 4 ? 'match' : 'amount'}</small></div>)}</div>
}

function BinaryVisual({ step }) {
  const values = [2, 5, 8, 12, 16, 23, 38, 56]
  const states = [[0, 7, 3], [4, 7, 5], [4, 7, 5], [5, 5, 5], [5, 5, 5]]
  const [left, right, mid] = states[Math.min(step, states.length - 1)]
  return <div className="vc-binary"><p>target = <strong>23</strong></p><CellRow values={values} className="large" active={(index) => index < left || index > right ? 'binary-pruned' : index === mid ? 'binary-mid' : 'binary-live'} label={(index) => index === mid ? <small>mid</small> : null} /><div className="vc-range-label">search range: {left} … {right}</div></div>
}

function HashVisual({ step }) {
  const stream = ['A', 'B', 'A', 'C', 'B']
  const seen = stream.slice(0, Math.min(step + 1, stream.length))
  const counts = seen.reduce((acc, key) => ({ ...acc, [key]: (acc[key] ?? 0) + 1 }), {})
  return <div className="vc-hash-layout"><CellRow values={stream} active={(index) => index < seen.length ? 'used' : ''} /><div className="vc-arrow-line">→</div><div className="vc-hash-buckets">{['A', 'B', 'C'].map((key) => <div key={key} className={counts[key] ? 'filled' : ''}><strong>{key}</strong><span>{counts[key] ?? 0}</span></div>)}</div></div>
}

function DedupeVisual({ step }) {
  const values = ['A', 'B', 'A', 'C', 'B']
  const processed = values.slice(0, Math.min(step + 1, values.length))
  const output = []
  const seen = new Set()
  processed.forEach((value) => { if (!seen.has(value)) { seen.add(value); output.push(value) } })
  const current = Math.min(step, values.length - 1)
  return <div className="vc-dedupe"><div><strong>input</strong><CellRow values={values} active={(index) => index === current ? 'pointer' : index < processed.length ? 'consumed' : ''} /></div><div className="vc-dedupe-arrow">↓</div><div className="vc-dedupe-state"><span><strong>seen</strong>{[...seen].join(' · ') || '∅'}</span><span><strong>output</strong>{output.join(' → ') || '∅'}</span></div></div>
}

function StackQueueVisual({ step }) {
  const values = ['extract', 'clean', 'model']
  const poppedStack = step >= 1 ? 'model' : null
  const poppedQueue = step >= 2 ? 'extract' : null
  return <div className="vc-stackqueue"><div><strong>STACK · LIFO</strong><div className="vc-structure vertical">{values.map((v) => <span key={v} className={v === poppedStack ? 'removed' : ''}>{v}</span>)}</div><em>{poppedStack ? `pop → ${poppedStack}` : 'newest on top'}</em></div><div><strong>QUEUE · FIFO</strong><div className="vc-structure horizontal">{values.map((v) => <span key={v} className={v === poppedQueue ? 'removed' : ''}>{v}</span>)}</div><em>{poppedQueue ? `popleft → ${poppedQueue}` : 'oldest leaves first'}</em></div></div>
}

function BatchVisual({ step }) {
  const batch = Math.min(Math.max(step - 1, 0), 2)
  return <div className="vc-batch"><div className="vc-batch-stream">{Array.from({ length: 12 }, (_, index) => <span key={index} className={step > 0 && Math.floor(index / 4) === batch ? 'active' : Math.floor(index / 4) < batch ? 'done' : ''}>{index + 1}</span>)}</div><div className="vc-batch-caption">{step === 0 ? '12 rows waiting' : `process batch ${batch + 1} · rows ${batch * 4 + 1}–${batch * 4 + 4}`}</div></div>
}

function RankVisual({ step }) {
  const raw = [['u1', '09:00', 3], ['u2', '09:10', 2], ['u1', '09:20', 2], ['u2', '09:40', 1], ['u1', '09:50', 1]]
  const ordered = [['u1', '09:50', 1], ['u1', '09:20', 2], ['u1', '09:00', 3], ['u2', '09:40', 1], ['u2', '09:10', 2]]
  const rows = step >= 2 ? ordered : raw
  return <div className={`vc-rank-table step-${step}`}><div className="vc-rank-head"><span>user</span><span>event_ts</span><span>rn</span></div>{rows.map(([user, ts, rank], index) => { const keep = rank === 1; const hidden = step >= 4 && !keep; return <div key={`${user}-${ts}`} className={`vc-rank-row user-${user} ${hidden ? 'filtered' : ''} ${step >= 4 && keep ? 'keep' : ''}`} style={{ '--delay': `${index * 70}ms` }}><span>{user}</span><strong>{ts}</strong><em>{step >= 3 ? rank : '—'}</em></div> })}</div>
}

function SlidingVisual({ step }) {
  const values = [120, 80, 200, 150, 90, 210]
  const start = Math.min(Math.max(step - 1, 0), 3)
  const sum = values.slice(start, start + 3).reduce((a, b) => a + b, 0)
  return <div className="vc-window-wrap"><CellRow values={values} className="large" active={(index) => index >= start && index < start + 3 ? 'window' : ''} /><div className="vc-window-brace" style={{ '--start': start }}><span>window sum = {sum}</span></div></div>
}

const pointerStates = [[0, 0, []], [1, 0, [1]], [1, 1, [1, 2]], [1, 2, [1, 2, 3]], [2, 2, [1, 2, 3, 4]], [4, 4, [1, 2, 3, 4, 8, 9, 12, 15]]]
function PointerVisual({ step }) {
  const left = [1, 4, 8, 12], right = [2, 3, 9, 15]
  const [i, j, merged] = pointerStates[Math.min(step, pointerStates.length - 1)]
  const row = (name, values, pointer) => <div className="vc-pointer-row"><strong>{name}</strong>{values.map((value, index) => <span key={value} className={index === pointer && step < 5 ? 'pointer' : index < pointer ? 'consumed' : ''}>{value}</span>)}</div>
  return <div className="vc-pointer-wrap">{row('A', left, i)}{row('B', right, j)}<div className="vc-merged"><strong>merged</strong>{merged.map((value, index) => <span key={`${value}-${index}`}>{value}</span>)}</div></div>
}

function SortVisual({ step }) {
  const states = [[3, 1, 2, 2], [1, 3, 2, 2], [1, 2, 3, 2], [1, 2, 2, 3], [1, 2, 2, 3]]
  const values = states[Math.min(step, states.length - 1)]
  return <div className="vc-sort-wrap"><CellRow values={values} className="large sortable" active={(_, value) => step >= 3 && value === 2 ? 'stable-tie' : ''} label={(_, value) => value === 2 && step >= 3 ? <small>tie</small> : null} /><p>{step >= 3 ? 'Equal-key rows keep a deterministic relative order.' : 'Cells move according to the sort key.'}</p></div>
}

function PrefixVisual({ step }) {
  const values = [10, 20, 30, 40, 50], prefix = [0, 10, 30, 60, 100, 150]
  return <div className="vc-prefix"><div><strong>values</strong><CellRow values={values} /></div><div><strong>prefix</strong><CellRow values={prefix.map((v, i) => i <= step + 1 ? v : '·')} active={(index) => index <= step + 1 ? 'used' : ''} /></div><p className={step >= 3 ? 'show' : ''}>range [1..3] = 100 − 10 = <strong>90</strong></p></div>
}

function TopKVisual({ step }) {
  const items = [['a', 120], ['b', 900], ['c', 450], ['d', 700], ['e', 300]]
  const processed = items.slice(0, Math.min(step + 1, items.length))
  const top = [...processed].sort((a, b) => b[1] - a[1]).slice(0, 3)
  return <div className="vc-topk"><div className="vc-stream">{items.map(([name, size], i) => <span key={name} className={i < processed.length ? 'used' : ''}>{name}<small>{size}</small></span>)}</div><div className="vc-topk-box"><strong>TOP 3</strong>{top.map(([name, size]) => <span key={name}>{name}<em>{size} MB</em></span>)}</div></div>
}

const graphNodes = { ingest: [12, 50], clean: [38, 25], audit: [38, 75], model: [66, 25], publish: [90, 25] }
const graphEdges = [['ingest', 'clean'], ['ingest', 'audit'], ['clean', 'model'], ['model', 'publish']]
function GraphVisual({ step, topo = false }) {
  const order = topo ? ['ingest', 'clean', 'audit', 'model', 'publish'] : ['ingest', 'clean', 'audit', 'model', 'publish']
  const activeIndex = Math.min(step, order.length - 1)
  const visited = new Set(order.slice(0, activeIndex + 1))
  return <div className="vc-graph"><svg viewBox="0 0 100 100" aria-hidden="true">{graphEdges.map(([a, b]) => <line key={`${a}-${b}`} x1={graphNodes[a][0]} y1={graphNodes[a][1]} x2={graphNodes[b][0]} y2={graphNodes[b][1]} />)}{Object.entries(graphNodes).map(([name, [x, y]]) => <g key={name} className={`${visited.has(name) ? 'visited' : ''} ${order[activeIndex] === name ? 'active' : ''}`}><circle cx={x} cy={y} r="8"/><text x={x} y={y + 1}>{name}</text></g>)}</svg><div className="vc-queue"><strong>{topo ? 'ready / order' : 'queue / visited'}</strong><span>{order.slice(0, activeIndex + 1).join(' → ')}</span></div></div>
}

function IntervalVisual({ step }) {
  const raw = [[1, 4], [2, 6], [8, 10], [9, 12]], merged = step >= 3 ? [[1, 6], [8, 12]] : raw
  return <div className="vc-interval-wrap"><div className="vc-timeline">{Array.from({ length: 12 }, (_, i) => <span key={i}>{i + 1}</span>)}</div><div className="vc-interval-lanes">{merged.map(([start, end], index) => <div key={`${start}-${end}`} className={`vc-interval interval-${index}`} style={{ left: `${(start - 1) * 8}%`, width: `${Math.max((end - start + 1) * 8, 8)}%`, top: `${index * 24}px` }}>{start}–{end}</div>)}</div></div>
}

function PartitionVisual({ step }) {
  return <div className={`vc-block-grid step-${step}`}>{Array.from({ length: 48 }, (_, index) => { const row = Math.floor(index / 8); const dateKeep = row >= 3; const clusterKeep = dateKeep && index % 8 >= 4 && index % 8 <= 6; const keep = step === 0 ? true : step === 1 ? dateKeep : clusterKeep; return <span key={index} className={keep ? 'candidate' : 'pruned'} /> })}<div className="vc-block-legend"><span>{step === 0 ? 'all blocks candidates' : step === 1 ? 'date partition kept' : 'cluster blocks kept'}</span></div></div>
}

function JoinVisual({ step }) {
  const left = [['u1', 'A'], ['u2', 'B'], ['u3', 'C']], right = [['u1', 120], ['u3', 80], ['u4', 50]], matches = step >= 2 ? new Set(['u1', 'u3']) : new Set()
  return <div className="vc-join"><div className="vc-mini-table"><strong>customers</strong>{left.map(([id, name]) => <span key={id} className={matches.has(id) ? 'match' : ''}>{id}<em>{name}</em></span>)}</div><div className="vc-join-lines">{step >= 2 ? <><span>u1 ↔ u1</span><span>u3 ↔ u3</span></> : <span>match on key</span>}</div><div className="vc-mini-table"><strong>orders</strong>{right.map(([id, amount]) => <span key={id} className={matches.has(id) ? 'match' : ''}>{id}<em>{amount}</em></span>)}</div>{step >= 3 && <div className="vc-join-output"><strong>output</strong><span>u1 · A · 120</span><span>u3 · C · 80</span></div>}</div>
}

function MedallionVisual({ step }) {
  const stages = [['BRONZE', 'raw + immutable'], ['SILVER', 'clean + dedupe'], ['GOLD', 'business-ready']], active = Math.min(Math.floor(step / 2), 2)
  return <div className="vc-medallion">{stages.map(([name, text], index) => <div key={name} className={`${index < active ? 'done' : ''} ${index === active ? 'active' : ''}`}><span>{index + 1}</span><strong>{name}</strong><small>{text}</small>{index < 2 && <i>→</i>}</div>)}</div>
}

function GitVisual({ step }) {
  const stages = [['EDIT', 'working tree'], ['ADD', 'staging'], ['COMMIT', 'local history'], ['PULL', 'integrate'], ['PUSH', 'remote']]
  return <div className="vc-git"><div className="vc-git-track">{stages.map(([cmd, label], index) => <div key={cmd} className={`${index < step ? 'done' : ''} ${index === step ? 'active' : ''}`}><span>{index + 1}</span><strong>{cmd}</strong><small>{label}</small></div>)}</div><div className="vc-git-files"><span>app.js</span><span>model.sql</span><span>README.md</span></div></div>
}

function SceneVisual({ kind, step }) {
  const map = {
    scan: ScanVisual, binary: BinaryVisual, hash: HashVisual, dedupe: DedupeVisual, stackqueue: StackQueueVisual, batch: BatchVisual,
    rank: RankVisual, sort: SortVisual, pointers: PointerVisual, sliding: SlidingVisual, prefix: PrefixVisual, topk: TopKVisual,
    bfs: GraphVisual, topo: (props) => <GraphVisual {...props} topo />, intervals: IntervalVisual, partition: PartitionVisual,
    join: JoinVisual, medallion: MedallionVisual, git: GitVisual,
  }
  const Visual = map[kind]
  return Visual ? <Visual step={step} /> : null
}

function AnimatedConceptCard({ item, kind }) {
  const [title, badge, steps] = SCENES[kind]
  const [step, setStep] = useState(0)
  const [playing, setPlaying] = useState(() => !window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)
  const [speed, setSpeed] = useState(1)
  const last = steps.length - 1
  useEffect(() => { setStep(0) }, [item.id, kind])
  useEffect(() => {
    if (!playing) return undefined
    const timer = window.setInterval(() => setStep((value) => value >= last ? 0 : value + 1), 1250 / speed)
    return () => window.clearInterval(timer)
  }, [playing, speed, last])
  return <section className="animated-concept-card" data-concept-kind={kind}>
    <header><div><span>ANIMATED CONCEPT</span><strong>{title}</strong></div><em>{badge}</em></header>
    <div className="animated-concept-stage"><SceneVisual kind={kind} step={step} /></div>
    <div className="animated-concept-explanation"><span>{String(step + 1).padStart(2, '0')}</span><p>{steps[step]}</p></div>
    <footer><div className="animated-concept-controls"><button onClick={() => { setPlaying(false); setStep((v) => Math.max(0, v - 1)) }} aria-label="Previous visual step"><ChevronLeft size={15}/></button><button className="play" onClick={() => setPlaying((v) => !v)} aria-label={playing ? 'Pause animation' : 'Play animation'}>{playing ? <Pause size={15}/> : <Play size={15}/>} {playing ? 'Pause' : 'Play'}</button><button onClick={() => { setPlaying(false); setStep((v) => Math.min(last, v + 1)) }} aria-label="Next visual step"><ChevronRight size={15}/></button><button onClick={() => { setPlaying(false); setStep(0) }} aria-label="Reset animation"><RotateCcw size={14}/></button></div><div className="animated-concept-dots">{steps.map((_, index) => <button key={index} className={step === index ? 'active' : ''} onClick={() => { setPlaying(false); setStep(index) }} aria-label={`Go to visual step ${index + 1}`} />)}</div><div className="animated-speed" aria-label="Animation speed">{[0.75, 1, 1.5].map((v) => <button key={v} className={speed === v ? 'active' : ''} onClick={() => setSpeed(v)}>{v}×</button>)}</div></footer>
  </section>
}

const BIG_O_ROWS = [
  ['Hash lookup', 'hash', 'map.get(key)', 'O(1)'], ['Binary search', 'binary', 'halve search space', 'O(log n)'], ['Single scan', 'scan', 'touch each row once', 'O(n)'], ['Sliding window', 'window', 'reuse rolling state', 'O(n)'], ['Sort / merge', 'sort', 'divide + merge', 'O(n log n)'], ['Nested loop', 'nested', 'all row pairs', 'O(n²)'], ['BFS / DFS', 'graph', 'visit vertices + edges', 'O(V+E)'], ['Top K heap', 'heap', 'bounded priority queue', 'O(n log k)'],
]

function BigOCheatSheet() {
  return <section className="visual-cheat-sheet"><header><div><span>VISUAL CHEAT SHEET</span><h2>Time complexity patterns you should recognize instantly</h2></div><p>Watch the amount of work, not just the syntax.</p></header><div className="visual-cheat-table">{BIG_O_ROWS.map(([name, demo, code, complexity], index) => <div className="visual-cheat-row" key={name}><span className="visual-cheat-index">{index + 1}</span><div><strong>{name}</strong><code>{code}</code></div><div className={`visual-cheat-demo demo-${demo}`} aria-hidden="true">{Array.from({ length: demo === 'nested' ? 16 : 10 }, (_, i) => <i key={i} />)}</div><b>{complexity}</b></div>)}</div></section>
}

function SqlCheatSheet() {
  const rows = [['WHERE', 'Filter rows', 'Rows disappear before later analytical work.'], ['JOIN', 'Match keys', 'Rows connect when the join predicate matches.'], ['GROUP BY', 'Collapse groups', 'Many detail rows become one row per group.'], ['WINDOW', 'Keep rows', 'The window reads related rows but returns a result per input row.'], ['QUALIFY', 'Filter window result', 'Rank first, then keep rows whose computed window value qualifies.']]
  return <section className="visual-cheat-sheet sql-visual-cheat"><header><div><span>VISUAL CHEAT SHEET</span><h2>What each SQL operation does to rows</h2></div><p>Focus on whether rows are filtered, connected, collapsed, or preserved.</p></header><div className="sql-visual-flow">{rows.map(([name, action, note], index) => <article key={name}><span>{index + 1}</span><strong>{name}</strong><em>{action}</em><div className={`sql-mini-motion sql-motion-${index}`}>{Array.from({ length: 8 }, (_, i) => <i key={i} />)}</div><p>{note}</p></article>)}</div></section>
}

function HubCheat({ label }) {
  if (/algorithm|coding concept/i.test(label)) return <BigOCheatSheet />
  if (/\bsql\b|duckdb/i.test(label)) return <SqlCheatSheet />
  return null
}

export default function AnimatedConceptLayer() {
  const [state, setState] = useState({ practiceMount: null, title: '', cheatMount: null, hubLabel: '' })
  useEffect(() => {
    let frame = 0
    const sync = () => {
      frame = 0
      const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim() ?? ''
      const practiceMount = title ? ensurePracticeMount() : null
      const cheatMount = ensureCheatMount()
      const hubLabel = cheatMount ? document.querySelector('.learning-hub-hero h1')?.textContent?.trim() ?? '' : ''
      setState((old) => old.practiceMount === practiceMount && old.title === title && old.cheatMount === cheatMount && old.hubLabel === hubLabel ? old : { practiceMount, title, cheatMount, hubLabel })
    }
    const schedule = () => { if (!frame) frame = window.requestAnimationFrame(sync) }
    sync()
    const observer = new MutationObserver(schedule)
    observer.observe(document.body, { childList: true, subtree: true, characterData: true })
    return () => { observer.disconnect(); if (frame) window.cancelAnimationFrame(frame) }
  }, [])
  const item = useMemo(() => allItems.find((entry) => entry.title === state.title) ?? null, [state.title])
  const kind = useMemo(() => resolveScene(item), [item])
  return <>{state.practiceMount && item && kind && createPortal(<AnimatedConceptCard item={item} kind={kind}/>, state.practiceMount)}{state.cheatMount && state.hubLabel && createPortal(<HubCheat label={state.hubLabel}/>, state.cheatMount)}</>
}

export { BIG_O_ROWS, SCENES, resolveScene }
