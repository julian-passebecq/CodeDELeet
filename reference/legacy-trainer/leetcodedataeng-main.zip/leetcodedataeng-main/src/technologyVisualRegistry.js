const glyph = (body) => `<svg viewBox="0 0 24 24" focusable="false" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`

export const OFFICIAL_ASSETS = {
  python: {
    label: 'Python',
    src: 'https://s3.dualstack.us-east-2.amazonaws.com/pythondotorg-assets/media/files/python-logo-only.svg',
    trademark: true,
  },
  fabric: {
    label: 'Microsoft Fabric',
    src: '/icons/microsoft/fabric.svg',
  },
  lakehouse: {
    label: 'Microsoft Fabric Lakehouse',
    src: '/icons/microsoft/lakehouse.svg',
  },
  powerbi: {
    label: 'Power BI',
    src: '/icons/microsoft/power-bi.svg',
  },
}

export const GLYPHS = {
  database: glyph('<ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>'),
  table: glyph('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 4v16M15 4v16"/>'),
  spark: glyph('<path d="m13 2-7 11h6l-1 9 7-12h-6l1-8Z"/>'),
  workflow: glyph('<circle cx="5" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M7 6h10M6.5 7.5l4.2 8.4M17.5 7.5l-4.2 8.4"/>'),
  layers: glyph('<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>'),
  storage: glyph('<path d="M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3Z"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>'),
  wrench: glyph('<path d="M14.7 6.3a4 4 0 0 0-5-5L12 3.6 8.4 7.2 6.1 4.9a4 4 0 0 0 5 5l7.4 7.4a2 2 0 1 1-2.8 2.8l-7.4-7.4"/>'),
  network: glyph('<circle cx="12" cy="5" r="2.3"/><circle cx="5" cy="18" r="2.3"/><circle cx="19" cy="18" r="2.3"/><path d="m11 7-5 8.7M13 7l5 8.7M7.3 18h9.4"/>'),
  book: glyph('<path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22V5.5ZM20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22V5.5Z"/>'),
  branch: glyph('<circle cx="6" cy="5" r="2"/><circle cx="18" cy="7" r="2"/><circle cx="6" cy="19" r="2"/><path d="M6 7v10M8 10c5 0 4-3 8-3"/>'),
  cloud: glyph('<path d="M7 18h10a4 4 0 0 0 .7-7.9A6 6 0 0 0 6.2 8.5 4.5 4.5 0 0 0 7 18Z"/>'),
  terminal: glyph('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M12 15h5"/>'),
  clock: glyph('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  code: glyph('<path d="m8 9-4 3 4 3M16 9l4 3-4 3M14 5l-4 14"/>'),
  server: glyph('<rect x="4" y="3" width="16" height="7" rx="2"/><rect x="4" y="14" width="16" height="7" rx="2"/><path d="M8 6h.01M8 17h.01"/>'),
  boxes: glyph('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="8.5" y="14" width="7" height="7" rx="1"/><path d="M6.5 10v2h11v-2M12 12v2"/>'),
  container: glyph('<rect x="3" y="7" width="18" height="11" rx="2"/><path d="M7 7V4h4v3M8 10v5M12 10v5M16 10v5"/>'),
  activity: glyph('<path d="M3 12h4l2-6 4 12 2-6h6"/>'),
  sparkles: glyph('<path d="m12 3 1.2 3.3L16.5 7.5l-3.3 1.2L12 12l-1.2-3.3-3.3-1.2 3.3-1.2L12 3ZM18.5 13l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2ZM5.5 14l.8 2.2 2.2.8-2.2.8L5.5 20l-.8-2.2-2.2-.8 2.2-.8.8-2.2Z"/>'),
  trend: glyph('<path d="M4 18 10 12l4 4 6-9M16 7h4v4"/>'),
  interview: glyph('<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h5M8 17h7"/>'),
}

const normalize = (value) => String(value ?? '').replace(/\s+/g, ' ').trim().toLowerCase()

export function technologySpecFor(value) {
  const text = normalize(value)
  if (!text) return null
  if (/fabric lakehouse/.test(text)) return { official: 'lakehouse', kind: 'fabric-lakehouse', fallback: 'storage' }
  if (/microsoft fabric|fabric mirroring|\bfabric\b/.test(text)) return { official: 'fabric', kind: 'fabric', fallback: 'layers' }
  if (/power bi|\bdax\b|bi · finance|bi \/ dax|bi · dax/.test(text)) return { official: 'powerbi', kind: 'powerbi', fallback: 'activity' }
  if (/analytics eng|analytics engineering/.test(text)) return { glyph: 'layers', kind: 'analytics-engineering' }
  if (/pandas|numpy|polars/.test(text)) return { glyph: 'table', kind: 'dataframe' }
  if (/pyspark|apache spark|\bspark\b/.test(text)) return { glyph: 'spark', kind: 'spark' }
  if (/\bpython\b/.test(text)) return { official: 'python', kind: 'python', fallback: 'code' }
  if (/airflow/.test(text)) return { glyph: 'workflow', kind: 'airflow' }
  if (/openlineage|lineage|debezium|change data capture|\bcdc\b/.test(text)) return { glyph: 'network', kind: 'lineage' }
  if (/duckdb/.test(text)) return { glyph: 'database', kind: 'duckdb' }
  if (/\bdbt\b/.test(text)) return { glyph: 'layers', kind: 'dbt' }
  if (/storage|parquet|avro|delta lake|iceberg|lakehouse/.test(text)) return { glyph: 'storage', kind: 'storage' }
  if (/troubleshoot|incident|reliability/.test(text)) return { glyph: 'wrench', kind: 'troubleshooting' }
  if (/junior.*senior|seniority/.test(text)) return { glyph: 'trend', kind: 'seniority' }
  if (/algorithm|coding concept/.test(text)) return { glyph: 'network', kind: 'algorithms' }
  if (/foundation/.test(text)) return { glyph: 'book', kind: 'foundations' }
  if (/\bgit\b/.test(text)) return { glyph: 'branch', kind: 'git' }
  if (/cloud|bigquery|azure|gcp/.test(text)) return { glyph: 'cloud', kind: 'cloud' }
  if (/powershell|\bbash\b/.test(text)) return { glyph: 'terminal', kind: 'terminal' }
  if (/\bcron\b/.test(text)) return { glyph: 'clock', kind: 'cron' }
  if (/c#|csharp|tabular editor/.test(text)) return { glyph: 'code', kind: 'csharp' }
  if (/gateway/.test(text)) return { glyph: 'server', kind: 'gateway' }
  if (/kubernetes|\bk8s\b/.test(text)) return { glyph: 'boxes', kind: 'kubernetes' }
  if (/docker/.test(text)) return { glyph: 'container', kind: 'docker' }
  if (/mlops|machine learning operations/.test(text)) return { glyph: 'activity', kind: 'mlops' }
  if (/nosql|mongo|redis/.test(text)) return { glyph: 'database', kind: 'nosql' }
  if (/genai|generative ai|\brag\b/.test(text)) return { glyph: 'sparkles', kind: 'genai' }
  if (/interview|data engineering/.test(text)) return { glyph: 'interview', kind: 'interview' }
  if (/sql|database/.test(text)) return { glyph: 'database', kind: 'sql' }
  return null
}

export function sourceTechnologySpec(source) {
  const text = normalize(`${source?.label ?? ''} ${source?.url ?? ''}`)
  if (!text) return { glyph: 'book', kind: 'docs' }
  if (/learn\.microsoft\.com.*fabric|microsoft fabric|\/fabric\//.test(text)) return { official: 'fabric', kind: 'fabric', fallback: 'layers' }
  if (/power bi|powerbi/.test(text)) return { official: 'powerbi', kind: 'powerbi', fallback: 'activity' }
  if (/python\.org|python/.test(text)) return { official: 'python', kind: 'python', fallback: 'code' }
  if (/airflow\.apache\.org|airflow/.test(text)) return { glyph: 'workflow', kind: 'airflow' }
  if (/spark\.apache\.org|apache spark/.test(text)) return { glyph: 'spark', kind: 'spark' }
  if (/docs\.getdbt\.com|\bdbt\b/.test(text)) return { glyph: 'layers', kind: 'dbt' }
  if (/openlineage/.test(text)) return { glyph: 'network', kind: 'lineage' }
  if (/debezium/.test(text)) return { glyph: 'network', kind: 'lineage' }
  if (/duckdb/.test(text)) return { glyph: 'database', kind: 'duckdb' }
  if (/iceberg|parquet|delta/.test(text)) return { glyph: 'storage', kind: 'storage' }
  if (/databricks|spark/.test(text)) return { glyph: 'spark', kind: 'spark' }
  if (/polars|pandas/.test(text)) return { glyph: 'table', kind: 'dataframe' }
  return { glyph: 'book', kind: 'docs' }
}

export function fallbackGlyphFor(spec) {
  return spec?.fallback ?? spec?.glyph ?? 'book'
}

export function glyphMarkupFor(spec) {
  return GLYPHS[spec?.glyph ?? fallbackGlyphFor(spec)] ?? GLYPHS.book
}
