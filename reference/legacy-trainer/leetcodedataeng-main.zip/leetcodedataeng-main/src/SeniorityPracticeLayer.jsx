import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { ArrowRight, Gauge, RefreshCw, ShieldCheck } from 'lucide-react'
import { lessons } from './curriculum'

function currentLesson() {
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  return title ? lessons.find((item) => item.title === title) ?? null : null
}

function ensureMount() {
  const description = document.querySelector('.problem-description')
  if (!description) return null
  let mount = description.querySelector(':scope > .seniority-practice-mount')
  if (!mount) {
    mount = document.createElement('div')
    mount.className = 'seniority-practice-mount'
    const meta = description.querySelector('.problem-meta')
    if (meta) meta.insertAdjacentElement('afterend', mount)
    else description.prepend(mount)
  }
  return mount
}

function labelTabs(active) {
  const buttons = [...document.querySelectorAll('.code-pane-toolbar .mode-tabs button')]
  if (!buttons.length) return
  const seniorLabels = ['Junior baseline', 'Senior version', 'Compare']
  buttons.forEach((button, index) => {
    if (active) {
      if (!button.dataset.originalPracticeLabel) button.dataset.originalPracticeLabel = button.textContent ?? ''
      if (button.textContent !== seniorLabels[index]) button.textContent = seniorLabels[index]
      button.classList.add('seniority-mode-tab')
    } else if (button.dataset.originalPracticeLabel) {
      button.textContent = button.dataset.originalPracticeLabel
      delete button.dataset.originalPracticeLabel
      button.classList.remove('seniority-mode-tab')
    }
  })
}

function SeniorityGuide({ lesson }) {
  return (
    <section className="seniority-guide">
      <div className="seniority-guide-flow">
        <span className="junior-chip">JUNIOR</span>
        <ArrowRight size={14} />
        <span className="senior-chip">SENIOR</span>
        <strong>Compare behavior, not clever syntax.</strong>
      </div>
      <div className="seniority-lenses">
        <span><RefreshCw size={13} /><b>Rerun</b> Same final state?</span>
        <span><ShieldCheck size={13} /><b>Correctness</b> Late/duplicate/bad data?</span>
        <span><Gauge size={13} /><b>Scale</b> Still works at 100×?</span>
      </div>
      {lesson?.solutionExplanation && <p>Open <strong>Senior version</strong> or <strong>Compare</strong> after you have identified the risks yourself.</p>}
    </section>
  )
}

export default function SeniorityPracticeLayer() {
  const [mount, setMount] = useState(null)
  const [lesson, setLesson] = useState(null)

  useEffect(() => {
    const sync = () => {
      const current = currentLesson()
      const active = current?.track === 'seniority'
      labelTabs(active)
      if (!active) {
        setLesson(null)
        setMount(null)
        return
      }
      setLesson((old) => old?.id === current.id ? old : current)
      setMount((old) => old?.isConnected ? old : ensureMount())
    }

    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true, characterData: true })
    return () => {
      observer.disconnect()
      labelTabs(false)
    }
  }, [])

  if (!mount || !lesson) return null
  return createPortal(<SeniorityGuide lesson={lesson} />, mount)
}
