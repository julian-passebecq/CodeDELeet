import { lessons } from './curriculum.js'
import { extraHubs, hubExtensions } from './learningHubContent.js'

const OFFICIAL = {
  iceberg: { label: 'Apache Iceberg · evolution', url: 'https://iceberg.apache.org/docs/latest/evolution/' },
  icebergDdl: { label: 'Apache Iceberg · Spark DDL', url: 'https://iceberg.apache.org/docs/latest/spark-ddl/' },
  duckdbIceberg: { label: 'DuckDB · Iceberg extension', url: 'https://duckdb.org/docs/current/core_extensions/iceberg/overview' },
  databricksClustering: { label: 'Azure Databricks · liquid clustering', url: 'https://learn.microsoft.com/en-us/azure/databricks/tables/clustering' },
  fabricClustering: { label: 'Microsoft Fabric · liquid clustering', url: 'https://learn.microsoft.com/en-us/fabric/data-engineering/native-execution-engine-z-order-liquid-clustering' },
  fabricPartitioning: { label: 'Microsoft Fabric · Delta partitioning', url: 'https://learn.microsoft.com/en-us/fabric/data-engineering/delta-lake-partitioning' },
  fabricVorder: { label: 'Microsoft Fabric · V-Order', url: 'https://learn.microsoft.com/en-us/fabric/data-engineering/delta-optimization-and-v-order' },
  sparkAqe: { label: 'Apache Spark · performance tuning / AQE', url: 'https://spark.apache.org/docs/latest/sql-performance-tuning' },
  polarsParquet: { label: 'Polars · scan_parquet', url: 'https://docs.pola.rs/api/python/stable/reference/api/polars.scan_parquet.html' },
  dbtMicrobatch: { label: 'dbt · microbatch incremental models', url: 'https://docs.getdbt.com/docs/build/incremental-microbatch' },
}

const layoutDiagram = `flowchart LR
  F[Parquet / Avro / JSON files] --> T[Table metadata]
  T --> D[Delta Lake]
  T --> I[Apache Iceberg]
  D --> E[Fabric / Databricks / Spark]
  I --> S[Spark / DuckDB / other engines]
  E --> Q[Query + optimize]
  S --> Q`

const clusteringDiagram = `flowchart TD
  Q[Real query predicates] --> C{Layout strategy}
  C -->|coarse low/moderate cardinality + writer isolation| P[Partitioning]
  C -->|high-cardinality / changing filters| L[Liquid clustering]
  C -->|Fabric cross-engine file layout| V[V-Order]
  P --> R[Prune directories]
  L --> R2[Skip files by clustered ranges]
  V --> R3[Improve Parquet read layout]
  R --> O[Measure query plan + files read]
  R2 --> O
  R3 --> O`

const engineDiagram = `flowchart LR
  A[Parquet workload] --> B{Single machine comfortable?}
  B -->|yes, SQL-first| D[DuckDB]
  B -->|yes, DataFrame/lazy transforms| P[Polars]
  B -->|no / distributed platform standard| S[PySpark]
  D --> M[Measure bytes, memory, latency]
  P --> M
  S --> M`

const M = (x) => ({ sourcePack: 'Web verified · official docs · Sep 2026', ...x })

export const modernLakehouseLessons = [
  M({
    id: 'modern-format-table-engine-catalog', track: 'storage-performance', level: 'Intermediate', language: 'plaintext', title: 'Modern lakehouse layers: format, table, engine, catalog',
    concept: 'Parquet/Avro/JSON describe data files or records; Delta Lake and Iceberg add table metadata/transaction semantics; DuckDB and Spark execute queries; catalogs resolve table metadata and governance.',
    why: 'Modern architecture discussions are clearer when storage encoding, table semantics, execution and cataloging are separated.',
    context: 'Classify Parquet, Iceberg, Delta Lake, DuckDB, Spark and an Iceberg REST catalog.',
    task: 'Place each technology in the correct layer and explain one interaction between the layers.',
    starter: 'FILE / RECORD FORMAT:\n- \n\nTABLE FORMAT:\n- \n\nEXECUTION ENGINE:\n- \n\nCATALOG / METADATA SERVICE:\n- ',
    solution: 'FILE / RECORD FORMAT:\n- Parquet / Avro / JSON\n\nTABLE FORMAT:\n- Delta Lake / Apache Iceberg\n\nEXECUTION ENGINE:\n- DuckDB / Apache Spark\n\nCATALOG / METADATA SERVICE:\n- Iceberg REST catalog (one example)\n\nExample interaction: Spark or DuckDB resolves Iceberg table metadata through a catalog, then reads the referenced data files.',
    hints: ['Ask whether the technology defines bytes, table state, query execution, or table discovery/metadata.'],
    pitfall: 'Do not describe Iceberg, Parquet and DuckDB as three competing file formats.', diagram: layoutDiagram,
    officialSources: [OFFICIAL.iceberg, OFFICIAL.duckdbIceberg],
  }),
  M({
    id: 'modern-iceberg-hidden-partition', track: 'storage-performance', level: 'Expert', language: 'sql', title: 'Iceberg hidden partitioning and partition evolution',
    concept: 'Iceberg supports partition transforms and partition evolution while hiding physical partition layout from normal query predicates.',
    why: 'It separates logical filtering from a rigid Hive-style directory contract and lets layout evolve without eagerly rewriting old files.',
    context: 'events(id BIGINT, event_time TIMESTAMP, customer_id BIGINT, payload STRING). Queries filter by event_time and sometimes customer_id.',
    task: 'Create an Iceberg table using a day transform for event_time and buckets for customer_id, then explain what happens if the partition spec changes later.',
    starter: `CREATE TABLE prod.analytics.events (\n  id BIGINT,\n  event_time TIMESTAMP,\n  customer_id BIGINT,\n  payload STRING\n)\nUSING iceberg\nPARTITIONED BY (#);`,
    solution: `CREATE TABLE prod.analytics.events (\n  id BIGINT,\n  event_time TIMESTAMP,\n  customer_id BIGINT,\n  payload STRING\n)\nUSING iceberg\nPARTITIONED BY (days(event_time), bucket(32, customer_id));\n\n-- Queries still filter logical columns, e.g. event_time.\n-- If the partition spec evolves, old and new layouts can coexist;\n-- changing the spec is metadata-driven rather than an eager rewrite of all old files.`,
    hints: ['Iceberg Spark DDL supports transforms such as days(ts), bucket(N, col) and truncate.', 'Query the logical timestamp column rather than constructing partition directory predicates.'],
    pitfall: 'Hidden partitioning does not mean physical layout is irrelevant; it means users query logical columns while Iceberg handles partition mapping.',
    diagram: `flowchart LR\n  Q[WHERE event_time >= ...] --> M[Iceberg metadata]\n  M --> A[old partition spec files]\n  M --> B[new partition spec files]\n  A --> R[matching rows]\n  B --> R`,
    officialSources: [OFFICIAL.iceberg, OFFICIAL.icebergDdl],
  }),
  M({
    id: 'modern-duckdb-iceberg', track: 'storage-performance', level: 'Intermediate', language: 'sql', title: 'Inspect an Iceberg table with DuckDB',
    concept: 'DuckDB can read an Iceberg table directly with iceberg_scan and expose snapshot metadata; catalog-attached Iceberg tables unlock broader table operations.',
    why: 'DuckDB is useful as a lightweight local inspection/reconciliation engine around open lakehouse tables.',
    context: "An Iceberg table is available at 'lake/events_iceberg'. You need the row count and snapshot history without starting Spark.",
    task: 'Write DuckDB SQL to load the Iceberg extension, count rows and list snapshots.',
    starter: `INSTALL iceberg;\nLOAD iceberg;\n\nSELECT #\nFROM iceberg_scan('lake/events_iceberg');\n\nSELECT *\nFROM #( 'lake/events_iceberg' );`,
    solution: `INSTALL iceberg;\nLOAD iceberg;\n\nSELECT count(*) AS rows\nFROM iceberg_scan('lake/events_iceberg');\n\nSELECT *\nFROM iceberg_snapshots('lake/events_iceberg');`,
    hints: ['Use iceberg_scan for path-based reads.', 'Use iceberg_snapshots for snapshot metadata.'],
    pitfall: 'Path-based iceberg_scan is not the same as attaching a writable Iceberg REST catalog; write capabilities depend on catalog-backed access.',
    officialSources: [OFFICIAL.duckdbIceberg],
  }),
  M({
    id: 'modern-databricks-liquid-clustering', track: 'storage-performance', level: 'Expert', language: 'sql', title: 'Choose liquid clustering on Azure Databricks',
    concept: 'Current Azure Databricks guidance recommends liquid clustering for new tables and positions it as the replacement for traditional partitioning/ZORDER in that layout workflow.',
    why: 'Static high-cardinality partitions and changing access patterns are common sources of poor lakehouse layout.',
    context: 'orders is fast-growing; queries filter by customer_id, order_date and region, and the dominant predicates change over time.',
    task: 'Enable clustering on customer_id and order_date, and explain why you would not also partition/ZORDER the same table.',
    starter: `ALTER TABLE analytics.orders\nCLUSTER BY (#);\n\n-- maintenance\n# analytics.orders;`,
    solution: `ALTER TABLE analytics.orders\nCLUSTER BY (customer_id, order_date);\n\nOPTIMIZE analytics.orders;\n\n-- Liquid clustering is not combined with Hive-style partitioning or ZORDER on the same table.\n-- If clustering keys later change and old data must be fully reclustered, use the runtime-supported FULL optimization deliberately.`,
    hints: ['Choose columns used in selective filters.', 'Changing keys affects future clustering; maintenance applies the physical layout.'],
    pitfall: 'Do not copy universal partitioning rules into Databricks without checking current runtime/table guidance.', diagram: clusteringDiagram,
    officialSources: [OFFICIAL.databricksClustering],
  }),
  M({
    id: 'modern-fabric-vorder', track: 'storage-performance', level: 'Intermediate', language: 'sql', title: 'Fabric: separate V-Order from clustering and compaction',
    concept: 'V-Order is a Fabric write/file-layout optimization for Parquet; compaction reduces small-file overhead; clustering/Z-Order address data locality for selective predicates.',
    why: 'These optimizations are complementary concepts and should not be described as synonyms.',
    context: 'A Fabric Delta table has many small files and feeds repeated Power BI/SQL/Spark reads.',
    task: 'Explain which problem V-Order solves, which problem OPTIMIZE compaction solves, and where a clustering strategy fits.',
    starter: 'V-ORDER:\n- \n\nCOMPACTION / OPTIMIZE:\n- \n\nCLUSTERING / Z-ORDER:\n- ',
    solution: 'V-ORDER:\n- Reorganizes the Parquet file layout at write/maintenance time for efficient Fabric reads.\n\nCOMPACTION / OPTIMIZE:\n- Consolidates many small files into fewer larger files, reducing metadata/open-file overhead.\n\nCLUSTERING / Z-ORDER:\n- Improves data locality/file skipping for frequently filtered columns.\n\nAlways benchmark on the actual Fabric runtime/workload because defaults and supported maintenance syntax evolve.',
    hints: ['Think file encoding/layout vs file count vs value locality.'],
    pitfall: 'V-Order is not a replacement name for partitioning, Z-Order or liquid clustering.',
    officialSources: [OFFICIAL.fabricVorder],
  }),
  M({
    id: 'modern-fabric-partition-vs-liquid', track: 'storage-performance', level: 'Expert', language: 'plaintext', title: 'Fabric: partitioning vs liquid clustering',
    concept: 'Current Fabric Runtime 2.0 guidance favors liquid clustering for most read-performance scenarios, while Hive-style partitioning remains useful when disjoint partitions isolate concurrent writers.',
    why: 'Choosing layout from query behavior and write concurrency avoids thousands of tiny directories and unnecessary maintenance.',
    context: 'A sales Delta table is filtered by customer_id and region. Four pipelines concurrently MERGE separate legal entities.',
    task: 'Choose a physical layout and explain the trade-off between read optimization and writer isolation.',
    starter: 'READ PATTERN:\n\nWRITE CONCURRENCY:\n\nLAYOUT CHOICE:\n\nWHY:',
    solution: 'READ PATTERN:\n- customer_id is high-cardinality, so directory partitioning by customer_id is a poor default.\n\nWRITE CONCURRENCY:\n- if each pipeline truly owns a disjoint low/moderate-cardinality legal_entity partition, partitioning can isolate concurrent writes.\n\nLAYOUT CHOICE:\n- for read skipping alone on modern Fabric Runtime 2.0, prefer liquid clustering on useful filter columns.\n- if concurrent MERGE isolation is the primary need, carefully chosen partitions can still be justified.\n\nDo not enable partitioning and liquid clustering on the same table.',
    hints: ['Separate read optimization from concurrent-writer isolation.', 'Avoid high-cardinality directory partitions.'],
    pitfall: 'Do not turn a current Fabric recommendation into a universal rule for every lakehouse engine.', diagram: clusteringDiagram,
    officialSources: [OFFICIAL.fabricClustering, OFFICIAL.fabricPartitioning],
  }),
  M({
    id: 'modern-spark-aqe', track: 'pyspark', level: 'Expert', language: 'python', title: 'Read a Spark plan through the AQE lens',
    concept: 'Adaptive Query Execution uses runtime statistics to re-optimize parts of Spark SQL/DataFrame plans, including shuffle partition coalescing and some join/skew decisions.',
    why: 'Senior Spark tuning is not just setting spark.sql.shuffle.partitions to a magic number.',
    context: 'A large join is planned as sort-merge, but one side is much smaller after filters and a few shuffle partitions are skewed.',
    task: 'Enable/verify AQE, inspect the formatted plan, and list three adaptations AQE can make.',
    starter: `spark.conf.set('spark.sql.adaptive.enabled', #)\n\nresult = fact.join(dim, 'customer_id')\nresult.explain(#)\n\n# AQE can:\n# 1.\n# 2.\n# 3.`,
    solution: `spark.conf.set('spark.sql.adaptive.enabled', 'true')\n\nresult = fact.join(dim, 'customer_id')\nresult.explain('formatted')\n\n# AQE can, depending on runtime statistics/configuration:\n# 1. coalesce post-shuffle partitions\n# 2. convert an eligible sort-merge join to a broadcast/hash strategy\n# 3. split/mitigate skewed shuffle partitions`,
    hints: ['Look for adaptive plan information and Exchange/join nodes.', 'AQE reacts to runtime statistics; it does not excuse bad data modeling or an accidental many-to-many join.'],
    pitfall: 'Do not assume AQE guarantees a specific join conversion; thresholds, statistics and runtime conditions still matter.',
    officialSources: [OFFICIAL.sparkAqe],
  }),
  M({
    id: 'modern-polars-lazy-parquet', track: 'pipeline-troubleshooting', level: 'Intermediate', language: 'python', title: 'Use Polars lazy Parquet scanning before choosing Spark',
    concept: 'Polars scan_parquet returns a LazyFrame so the optimizer can push eligible projections and predicates into the scan.',
    why: 'A local workload may be solved more simply by reducing I/O rather than immediately moving to distributed compute.',
    context: 'You need daily revenue by customer from a local/cloud Parquet dataset and only three columns are required.',
    task: 'Build a lazy scan that filters recent rows, selects the needed columns, aggregates revenue, then collects once.',
    starter: `import polars as pl\n\nresult = (\n    pl.#('orders/*.parquet')\n      .filter(#)\n      .select(#)\n      .group_by('customer_id')\n      .agg(#)\n      .collect()\n)`,
    solution: `import polars as pl\n\nresult = (\n    pl.scan_parquet('orders/*.parquet')\n      .filter(pl.col('event_date') >= pl.date(2026, 9, 1))\n      .select('customer_id', 'amount', 'event_date')\n      .group_by('customer_id')\n      .agg(pl.col('amount').sum().alias('revenue'))\n      .collect()\n)`,
    hints: ['Use scan_parquet, not read_parquet, for a lazy scan.', 'Collect at the end of the logical plan.'],
    pitfall: 'Lazy execution is not a promise that every operation will push down; inspect the plan/profile when performance matters.', diagram: engineDiagram,
    officialSources: [OFFICIAL.polarsParquet],
  }),
  M({
    id: 'modern-dbt-microbatch', track: 'analytics-engineering', level: 'Expert', language: 'sql', title: 'dbt microbatch for large time-series models',
    concept: 'dbt microbatch splits a time-series incremental model into bounded event_time batches that can be processed/retried independently.',
    why: 'It provides a structured alternative to hand-written max(timestamp) incremental logic for supported adapters and appropriate time-series models.',
    context: 'events is large, append-heavy and keyed by event_occurred_at. Late rows can arrive up to three daily batches late.',
    task: 'Configure a daily microbatch model with a three-batch lookback and a fixed begin date.',
    starter: `{{ config(\n  materialized='incremental',\n  incremental_strategy=#,\n  event_time=#,\n  begin=#,\n  batch_size=#,\n  lookback=#\n) }}\n\nselect * from {{ ref('stg_events') }}`,
    solution: `{{ config(\n  materialized='incremental',\n  incremental_strategy='microbatch',\n  event_time='event_occurred_at',\n  begin='2024-01-01',\n  batch_size='day',\n  lookback=3,\n  full_refresh=false\n) }}\n\nselect * from {{ ref('stg_events') }}\n\n-- Also configure event_time on upstream models that should be auto-filtered.\n-- Adapter-specific requirements still apply.`,
    hints: ['event_time, begin and batch_size are central microbatch configs.', 'Set event_time on upstream models that should be automatically time-filtered.'],
    pitfall: 'Microbatch is not automatically best for every model; adapter support and a reliable event-time column matter.',
    diagram: `flowchart LR\n  E[Event-time source] --> B1[day -2]\n  E --> B2[day -1]\n  E --> B3[today]\n  B1 --> T[Target]\n  B2 --> T\n  B3 --> T\n  F[failed batch] --> R[retry only failed/bounded batch]\n  R --> T`,
    officialSources: [OFFICIAL.dbtMicrobatch],
  }),
  M({
    id: 'modern-engine-layout-decision', track: 'pipeline-troubleshooting', level: 'Expert', language: 'plaintext', title: 'Choose engine and physical layout from evidence',
    concept: 'Engine choice and table layout should follow data volume, memory, concurrency, platform constraints, query predicates, writes and observed plans—not brand preference.',
    why: 'A senior answer explains the decision process and the measurements that would invalidate the first choice.',
    context: 'Three workloads: 15 GB local Parquet reconciliation; 400 GB read-heavy Fabric Delta mart; 20 TB skewed Spark join pipeline.',
    task: 'Choose a first engine/layout for each workload, then name the evidence you would measure before scaling or redesigning.',
    starter: '15 GB local reconciliation:\n- engine:\n- layout:\n- measure:\n\n400 GB Fabric mart:\n- engine/layout:\n- measure:\n\n20 TB distributed join:\n- engine/layout:\n- measure:',
    solution: '15 GB local reconciliation:\n- start with DuckDB for SQL-first analysis or Polars for lazy DataFrame transforms if the machine has comfortable headroom; keep Parquet selective scans. Measure peak memory, bytes read and elapsed time.\n\n400 GB Fabric mart:\n- keep Delta/Fabric integration; inspect file count, query predicates and runtime. Consider liquid clustering for read skipping on current Runtime 2.0 guidance; use V-Order/compaction only for the problems they actually solve. Measure files read, query duration and write/maintenance cost.\n\n20 TB distributed join:\n- PySpark is justified; inspect the formatted/adaptive plan, shuffle bytes, skew, task durations and join cardinality before adding hardware.\n\nThere is no universal GB threshold that makes one engine correct.',
    hints: ['Use the smallest sufficient engine, but include operational/platform requirements.', 'Measure I/O, memory, shuffle, file count and end-to-end latency.'],
    pitfall: 'Do not quote a fixed “Spark starts at X GB” rule as if hardware, row width, compression, joins and concurrency do not matter.', diagram: engineDiagram,
    officialSources: [OFFICIAL.polarsParquet, OFFICIAL.sparkAqe, OFFICIAL.fabricClustering],
  }),
]

const existingIds = new Set(lessons.map((item) => item.id))
for (const lesson of modernLakehouseLessons) if (!existingIds.has(lesson.id)) lessons.push(lesson)

const addUnique = (items, value, key = (item) => item[0]) => {
  if (!items.some((item) => key(item) === key(value))) items.push(value)
}

const storageHub = extraHubs.find((hub) => hub.id === 'storage-performance')
if (storageHub) {
  if (!storageHub.sections.some(([title]) => title === 'Apache Iceberg')) storageHub.sections.push(['Apache Iceberg', 'Open table format with snapshots, schema evolution, hidden partitioning and partition evolution. Query logical columns; the table metadata maps predicates to the current and historical physical layouts.'])
  if (!storageHub.sections.some(([title]) => title === 'Modern layout')) storageHub.sections.push(['Modern layout', 'Databricks/Fabric liquid clustering, Fabric V-Order, partitioning, Z-Order and compaction solve different physical-layout problems. Always check the current runtime documentation before applying a universal rule.'])
  for (const topic of ['Apache Iceberg hidden partitions + evolution', 'liquid clustering', 'Fabric V-Order vs clustering/compaction']) if (!storageHub.interview.includes(topic)) storageHub.interview.push(topic)
}

const storageExt = hubExtensions['storage-performance']
if (storageExt) {
  addUnique(storageExt.algorithms, ['Hidden partition evolution', 'Let the table format map logical predicates to evolving physical partition specs instead of coupling queries to directory names.'])
  addUnique(storageExt.algorithms, ['Runtime-aware clustering', 'Choose partitioning/clustering from the platform/runtime, query predicates and writer concurrency; current recommendations can differ across Fabric, Databricks and open-source engines.'])
  addUnique(storageExt.problems, 'An Iceberg table changes from monthly to daily partition transforms. Explain how old/new files coexist and how users should query the timestamp.')
  addUnique(storageExt.problems, 'A Fabric Runtime 2.0 Delta table has high-cardinality customer filters and four concurrent MERGE writers. Choose between liquid clustering and partitioning, including the writer-isolation trade-off.', (item) => item)
  addUnique(storageExt.interviewCards, ['Iceberg hidden partitioning', 'Iceberg can use partition transforms and evolve the partition spec while queries keep filtering logical columns.', "PARTITIONED BY (days(event_time), bucket(32, customer_id))", 'Why is hidden partitioning useful?', 'It decouples logical query predicates from a fixed directory layout and lets metadata handle pruning across partition-spec changes.', 'Design an Iceberg layout for timestamp + customer filters, then evolve it safely.'])
  addUnique(storageExt.interviewCards, ['Liquid clustering vs partitioning', 'On current Databricks and modern Fabric guidance, liquid clustering is designed for flexible file skipping without high-cardinality directory partitions; partitioning still has platform-specific/write-isolation uses.', 'ALTER TABLE sales CLUSTER BY (customer_id, order_date);', 'Why is “always partition by date” a weak senior answer?', 'Because the correct layout depends on platform/runtime, table size, predicates, write concurrency, cardinality and maintenance behavior.', 'Choose a layout for a read-heavy table and a concurrently-written table.'])
  addUnique(storageExt.interviewCards, ['Fabric V-Order', 'V-Order changes Parquet file layout for Fabric read efficiency; it is distinct from compaction and value-based clustering.', "SET spark.sql.parquet.vorder.default=TRUE;", 'Is V-Order the same as Z-Order?', 'No. V-Order is a file-layout/write optimization; Z-Order/liquid clustering organize values for data skipping, while compaction primarily addresses file count.', 'Explain which optimization you would investigate for slow scans caused by small files versus poor filter locality.'])
}

const sparkExt = hubExtensions.pyspark
if (sparkExt) {
  addUnique(sparkExt.algorithms, ['Adaptive Query Execution', 'Use runtime statistics to coalesce shuffle partitions and adapt eligible joins/skew handling instead of relying only on static plans.'])
  addUnique(sparkExt.interviewCards, ['AQE', 'Adaptive Query Execution can re-optimize Spark SQL/DataFrame execution using runtime statistics.', "spark.conf.set('spark.sql.adaptive.enabled', 'true')\ndf.explain('formatted')", 'What problems can AQE address?', 'It can coalesce post-shuffle partitions, adapt eligible join strategies and mitigate skewed shuffle partitions, depending on runtime statistics and configuration.', 'Inspect a skewed join plan and explain what AQE can and cannot fix.'])
}

const dbtExt = hubExtensions.dbt
if (dbtExt) {
  addUnique(dbtExt.algorithms, ['Microbatch incremental processing', 'Split large event-time models into independent bounded time batches so retry/backfill can target specific windows.'])
  addUnique(dbtExt.problems, 'Convert a large daily event model from hand-written MAX(timestamp) filtering to a dbt microbatch model with event_time, lookback and bounded backfill.', (item) => item)
  addUnique(dbtExt.interviewCards, ['Microbatch', 'dbt microbatch is an incremental strategy for large time-series data using event_time and bounded batches.', "{{ config(materialized='incremental', incremental_strategy='microbatch', event_time='event_occurred_at', begin='2024-01-01', batch_size='day', lookback=3) }}", 'When is microbatch preferable to hand-written is_incremental logic?', 'When the model is naturally event-time based, the adapter supports it, and independent batch retry/backfill is valuable. It is not a universal replacement for other incremental strategies.', 'Design a daily microbatch model and a targeted historical backfill.'])
}

const deExt = hubExtensions['de-interview']
if (deExt) {
  addUnique(deExt.interviewCards, ['Delta vs Iceberg vs Parquet', 'Parquet is a file format; Delta Lake and Iceberg are table formats that add metadata/table semantics over data files.', 'Parquet files → table metadata/log → query engine', 'What changes when you move from plain Parquet files to an open table format?', 'You gain table-level metadata and capabilities such as snapshots/evolution/transaction semantics depending on the format, while engines still ultimately read data files.', 'Explain the layers in a lakehouse without calling every component a database.'])
  addUnique(deExt.interviewCards, ['Modern physical layout', 'Partitioning, liquid clustering, Z-Order, V-Order and compaction are not synonyms and platform guidance changes over time.', 'query predicates + writer pattern + runtime → layout choice', 'How would you choose a table layout in Fabric or Databricks?', 'Start from real predicates, cardinality, writer concurrency, table size and current runtime guidance; then verify pruning/files read and maintenance cost with plans/metrics.', 'Defend a layout choice and state what evidence would make you change it.'])
}
