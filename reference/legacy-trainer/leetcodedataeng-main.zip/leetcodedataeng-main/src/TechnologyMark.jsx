import { useEffect, useMemo, useState } from 'react'
import {
  GLYPHS,
  OFFICIAL_ASSETS,
  fallbackGlyphFor,
  sourceTechnologySpec,
  technologySpecFor,
} from './technologyVisualRegistry'

export default function TechnologyMark({ label = '', source = null, className = '' }) {
  const spec = useMemo(
    () => source ? sourceTechnologySpec(source) : technologySpecFor(label),
    [label, source],
  )
  const [failed, setFailed] = useState(false)

  useEffect(() => setFailed(false), [spec?.kind, spec?.official])

  if (!spec) return null
  const classes = ['technology-mark', className].filter(Boolean).join(' ')

  if (spec.official && !failed) {
    const asset = OFFICIAL_ASSETS[spec.official]
    return (
      <span className={classes} data-tech-visual={spec.kind} aria-hidden="true">
        <img alt="" src={asset.src} onError={() => setFailed(true)} />
        {asset.trademark ? <sup className="technology-trademark">™</sup> : null}
      </span>
    )
  }

  const markup = GLYPHS[spec.glyph ?? fallbackGlyphFor(spec)] ?? GLYPHS.book
  return (
    <span
      className={`${classes} technology-visual-fallback`}
      data-tech-visual={spec.kind}
      aria-hidden="true"
      dangerouslySetInnerHTML={{ __html: markup }}
    />
  )
}
