import { lessons, tracks } from './curriculum.js'

const analyticsTrack = {
  id: 'analytics-engineering',
  name: 'Analytics Engineering — Practical Labs',
  short: 'Analytics Eng',
  icon: 'AE',
  description: 'End-to-end local projects: dbt + DuckDB, pandas, PySpark/Delta, data quality, marts and lineage using one realistic e-commerce scenario.',
  concepts: ['dbt', 'DuckDB', 'ELT', 'staging', 'marts', 'tests', 'lineage', 'pandas', 'PySpark', 'Delta'],
}

const mlopsTrack = {
  id: 'mlops-practical',
  name: 'MLOps — Docker to Model Serving',
  short: 'MLOps',
  icon: 'ML',
  description: 'Practical Docker, Compose, FastAPI, MongoDB, Streamlit, model serving, MLflow, CI/CD and orchestration exercises.',
  concepts: ['Docker', 'Dockerfile', 'Compose', 'FastAPI', 'MongoDB', 'Streamlit', 'MLflow', 'GitHub Actions', 'orchestration'],
}

const ecommerceDiagram = `flowchart LR
  A[access.log] --> B[DuckDB raw source]
  P[products seed] --> G[Gold mart_daily_revenue]
  B --> S[Silver stg_access_logs]
  S --> G
  G --> Q[dbt tests]
  G --> D[dbt docs / lineage]`

const pandasDiagram = `flowchart LR
  A[access.log] --> P[pandas parse]
  J[products.json] --> M[merge]
  P --> M
  M --> Q[quality checks]
  Q --> G[daily_revenue.parquet]`

const sparkDiagram = `flowchart LR
  R[Raw logs] --> B[Bronze]
  B --> S[Silver parsed events]
  P[Product dimension] --> G[Gold daily revenue]
  S --> G
  G --> D[Delta table]`

const mlopsDiagram = `flowchart LR
  UI[Streamlit] --> API[FastAPI]
  API --> DB[(MongoDB)]
  API --> MR[MLflow model registry]
  ORCH[Airflow / Prefect] --> TRAIN[train.py]
  TRAIN --> MR
  CI[GitHub Actions] --> IMG[Container registry]
  IMG --> API
  IMG --> UI`

const A = (x) => ({ sourcePack: 'TD 6 — Analytics Engineering practical', ...x })
const M = (x) => ({ sourcePack: 'TD 1 — MLOps practical', ...x })

const analyticsLessons = [
  A({
    id: 'ae-dbt-profile', track: 'analytics-engineering', level: 'Beginner', language: 'yaml', title: 'dbt + DuckDB: local profile',
    concept: 'A dbt profile defines the execution target. A local DuckDB file makes the project self-contained.',
    why: 'You should be able to bootstrap an analytics project without depending on a cloud warehouse.',
    context: 'Project: ecommerce_analytics · target database: dbt.duckdb · local profiles.yml',
    task: 'Complete the local dbt-duckdb profile and enable httpfs + parquet extensions.',
    starter: `ecommerce_analytics:\n  target: dev\n  outputs:\n    dev:\n      type: duckdb\n      path: # database file\n      extensions:\n        - # extension 1\n        - # extension 2\n`,
    solution: `ecommerce_analytics:\n  target: dev\n  outputs:\n    dev:\n      type: duckdb\n      path: 'dbt.duckdb'\n      extensions:\n        - httpfs\n        - parquet\n`,
    hints: ['Use a persistent .duckdb file.', 'The tutorial uses httpfs and parquet.'],
    pitfall: 'Do not commit credentials or access tokens into profiles.yml.', diagram: ecommerceDiagram,
  }),
  A({
    id: 'ae-dbt-source', track: 'analytics-engineering', level: 'Beginner', language: 'yaml', title: 'dbt: declare raw access logs',
    concept: 'source() names raw upstream data and keeps source lineage separate from transformed models.',
    why: 'Explicit sources improve lineage, freshness checks and environment portability.',
    context: `access.log sample:\n10.0.0.12 - - [03/Sep/2026:09:00:01 +0000] "GET /product/105 HTTP/1.1" 200 312\n10.0.0.12 - - [03/Sep/2026:09:01:10 +0000] "GET /add_to_cart/105 HTTP/1.1" 200 88`,
    task: 'Declare access_logs as a DuckDB external source using read_text(access.log).',
    starter: `version: 2\n\nsources:\n  - name: raw_data\n    schema: main\n    tables:\n      - name: access_logs\n        meta:\n          external_location: # DuckDB expression\n`,
    solution: `version: 2\n\nsources:\n  - name: raw_data\n    schema: main\n    tables:\n      - name: access_logs\n        description: Raw server logs\n        meta:\n          external_location: "read_text('access.log')"\n`,
    hints: ['DuckDB read_text reads the file line by line.', 'Keep the raw relation named through source().'],
    pitfall: 'A source declaration is metadata; confirm your adapter/macro actually materializes or resolves the external relation as intended.',
  }),
  A({
    id: 'ae-dbt-parse-log', track: 'analytics-engineering', level: 'Intermediate', language: 'sql', title: 'dbt: parse raw HTTP logs',
    concept: 'A staging model turns unstable raw text into typed analytical columns.',
    why: 'Parsing and typing belong close to the source so downstream models can operate on stable contracts.',
    context: 'Input column: content. Extract ip_address, log_timestamp, url, status_code using DuckDB regex functions.',
    task: 'Complete stg_access_logs.sql so the raw text becomes four typed columns.',
    starter: `with source as (\n  select * from {{ source('raw_data', 'access_logs') }}\n),\nparsed as (\n  select\n    regexp_extract(content, '^(\\S+)', 1) as ip_address,\n    # timestamp,\n    # url,\n    # status code\n  from source\n)\nselect * from parsed`,
    solution: `with source as (\n  select * from {{ source('raw_data', 'access_logs') }}\n),\nparsed as (\n  select\n    regexp_extract(content, '^(\\S+)', 1) as ip_address,\n    strptime(regexp_extract(content, '\\[(.*?)\\]', 1), '%d/%b/%Y:%H:%M:%S %z') as log_timestamp,\n    regexp_extract(content, '"GET (.*?) HTTP', 1) as url,\n    cast(regexp_extract(content, 'HTTP/1.1" (\\d{3})', 1) as int) as status_code\n  from source\n)\nselect * from parsed`,
    hints: ['Extract text first, then cast/parse.', 'strptime converts the Apache-style timestamp.'],
    pitfall: 'Regex extraction can silently return empty strings; test malformed lines explicitly.',
  }),
  A({
    id: 'ae-dbt-event-features', track: 'analytics-engineering', level: 'Intermediate', language: 'sql', title: 'dbt: derive action + product_id',
    concept: 'Staging models normalize transport-level fields into business-level attributes.',
    why: 'Business models should not repeatedly parse URLs.',
    context: 'URLs include /product/105, /add_to_cart/105, /checkout and browse paths.',
    task: 'Derive action and product_id. Keep product_id NULL when the URL has no product identifier.',
    starter: `select\n  *,\n  case\n    when url like '/product/%' then #\n    when url like '/add_to_cart/%' then #\n    when url like '/checkout%' then #\n    else #\n  end as action,\n  # product_id\nfrom {{ ref('stg_access_logs_base') }}`,
    solution: `select\n  *,\n  case\n    when url like '/product/%' then 'view_product'\n    when url like '/add_to_cart/%' then 'add_to_cart'\n    when url like '/checkout%' then 'checkout'\n    else 'browse'\n  end as action,\n  try_cast(regexp_extract(url, '/(?:product|add_to_cart)/(\\d+)', 1) as int) as product_id\nfrom {{ ref('stg_access_logs_base') }}`,
    hints: ['CASE handles action classification.', 'Use regexp_extract for the trailing numeric product id.'],
    pitfall: 'Do not cast an empty regex result with a strict cast if malformed URLs are possible.',
  }),
  A({
    id: 'ae-dbt-revenue-mart', track: 'analytics-engineering', level: 'Intermediate', language: 'sql', title: 'dbt: build daily potential revenue',
    concept: 'A mart combines cleaned facts and dimensions at a declared reporting grain.',
    why: 'The analytical contract is one row per report_date with potential revenue and items added.',
    context: 'products(product_id, product_name, product_price). Only add_to_cart events contribute to potential revenue.',
    task: 'Join staged logs to products and produce one row per day.',
    starter: `with logs as (select * from {{ ref('stg_access_logs') }}),\nproducts as (select * from {{ ref('products') }})\n\nselect\n  # report date,\n  # revenue,\n  # item count\nfrom logs\njoin products on #\nwhere #\ngroup by #\norder by # desc`,
    solution: `with logs as (select * from {{ ref('stg_access_logs') }}),\nproducts as (select * from {{ ref('products') }})\n\nselect\n  date_trunc('day', logs.log_timestamp) as report_date,\n  sum(products.product_price) as potential_revenue,\n  count(*) as items_added\nfrom logs\njoin products on logs.product_id = products.product_id\nwhere logs.action = 'add_to_cart'\ngroup by 1\norder by 1 desc`,
    hints: ['Filter to add_to_cart.', 'The output grain is one row per day.'],
    pitfall: 'Validate product_id uniqueness before joining or the join can multiply revenue.', diagram: ecommerceDiagram,
  }),
  A({
    id: 'ae-dbt-tests', track: 'analytics-engineering', level: 'Beginner', language: 'yaml', title: 'dbt: add data tests',
    concept: 'Data tests encode assumptions about keys, nullability and accepted domains next to the model.',
    why: 'A pipeline is not reliable just because SQL compiles.',
    context: 'stg_access_logs.log_timestamp must exist; action is one of four values; mart_daily_revenue.report_date is unique and non-null.',
    task: 'Complete schema.yml with not_null, accepted_values and unique tests.',
    starter: `version: 2\nmodels:\n  - name: stg_access_logs\n    columns:\n      - name: log_timestamp\n        data_tests: [#]\n      - name: action\n        data_tests:\n          - accepted_values:\n              arguments:\n                values: #\n  - name: mart_daily_revenue\n    columns:\n      - name: report_date\n        data_tests: #\n`,
    solution: `version: 2\nmodels:\n  - name: stg_access_logs\n    columns:\n      - name: log_timestamp\n        data_tests: [not_null]\n      - name: action\n        data_tests:\n          - accepted_values:\n              arguments:\n                values: ['view_product', 'add_to_cart', 'checkout', 'browse']\n  - name: mart_daily_revenue\n    columns:\n      - name: report_date\n        data_tests: [unique, not_null]\n`,
    hints: ['Test the business domain for action.', 'The mart grain makes report_date a candidate key.'],
    pitfall: 'A uniqueness test is meaningful only when it matches the declared grain of the model.',
  }),
  A({
    id: 'ae-dbt-incremental', track: 'analytics-engineering', level: 'Expert', language: 'sql', title: 'dbt: make event processing incremental',
    concept: 'Incremental models process new/changed data while deliberately re-reading a lookback window for late arrivals.',
    why: 'This is one of the most common analytics-engineering interview and production patterns.',
    context: 'Events can arrive up to 48 hours late. {{ this }} contains the already-built target.',
    task: 'Add an is_incremental() filter with a two-day lookback from the current maximum log_timestamp.',
    starter: `select *\nfrom {{ ref('stg_access_logs') }}\n{% if is_incremental() %}\nwhere log_timestamp >= #\n{% endif %}`,
    solution: `select *\nfrom {{ ref('stg_access_logs') }}\n{% if is_incremental() %}\nwhere log_timestamp >= (\n  select coalesce(max(log_timestamp), timestamp '1900-01-01') - interval 2 day\n  from {{ this }}\n)\n{% endif %}`,
    hints: ['Use {{ this }} to refer to the current target.', 'Subtract a two-day lookback from the watermark.'],
    pitfall: 'A strict max(timestamp) watermark can permanently miss late-arriving updates.',
  }),
  A({
    id: 'ae-pandas-parse', track: 'analytics-engineering', level: 'Intermediate', language: 'python', title: 'pandas: parse the same access logs',
    concept: 'The same staging contract can be implemented locally with vectorized pandas string extraction.',
    why: 'Rebuilding one business transformation in several tools makes the underlying data logic portable.',
    context: `lines = pd.Series([...]) containing Apache-style GET requests. Produce ip_address, log_timestamp, url, status_code.`,
    task: 'Create a DataFrame with the same staging columns as the dbt model without row-by-row Python loops.',
    starter: `import pandas as pd\n\nraw = pd.DataFrame({"content": lines})\nparsed = pd.DataFrame()\nparsed["ip_address"] = #\nparsed["log_timestamp"] = #\nparsed["url"] = #\nparsed["status_code"] = #\n`,
    solution: `import pandas as pd\n\nraw = pd.DataFrame({"content": lines})\nparsed = pd.DataFrame()\nparsed["ip_address"] = raw["content"].str.extract(r'^(\\S+)', expand=False)\nparsed["log_timestamp"] = pd.to_datetime(raw["content"].str.extract(r'\\[(.*?)\\]', expand=False), format='%d/%b/%Y:%H:%M:%S %z', errors='coerce')\nparsed["url"] = raw["content"].str.extract(r'"GET (.*?) HTTP', expand=False)\nparsed["status_code"] = pd.to_numeric(raw["content"].str.extract(r'HTTP/1.1" (\\d{3})', expand=False), errors='coerce').astype('Int64')`,
    hints: ['Use Series.str.extract.', 'Use coercing parsers so malformed rows become observable nulls.'],
    pitfall: 'Avoid apply(lambda row: regex...) when vectorized string operations express the same transformation.', diagram: pandasDiagram,
  }),
  A({
    id: 'ae-pandas-revenue', track: 'analytics-engineering', level: 'Intermediate', language: 'python', title: 'pandas: daily revenue mart',
    concept: 'merge + filter + groupby reproduces the analytical mart locally.',
    why: 'You should recognize the same grain and join-cardinality risks outside SQL.',
    context: 'events has log_timestamp, action, product_id. products has unique product_id and product_price.',
    task: 'Build daily_revenue with potential_revenue and items_added.',
    starter: `cart = events[#].copy()\nenriched = cart.merge(products, #)\ndaily_revenue = (\n  enriched.assign(report_date=#)\n    .groupby(#, as_index=False)\n    .agg(#)\n)`,
    solution: `cart = events[events["action"].eq("add_to_cart")].copy()\nenriched = cart.merge(products, on="product_id", how="inner", validate="many_to_one")\ndaily_revenue = (\n  enriched.assign(report_date=enriched["log_timestamp"].dt.floor("D"))\n    .groupby("report_date", as_index=False)\n    .agg(potential_revenue=("product_price", "sum"), items_added=("product_id", "size"))\n)`,
    hints: ['Filter before aggregating.', 'validate=many_to_one protects the dimensional join contract.'],
    pitfall: 'Do not average or sum duplicated product prices caused by a non-unique dimension key.',
  }),
  A({
    id: 'ae-pandas-quality', track: 'analytics-engineering', level: 'Intermediate', language: 'python', title: 'pandas: enforce quality gates',
    concept: 'Lightweight assertions can protect local pipelines before publishing output.',
    why: 'Quality checks should validate both schema-level and business-level invariants.',
    context: 'events.action domain is fixed; products.product_id must be unique; report_date must be unique in the daily mart.',
    task: 'Write three assertions for those invariants.',
    starter: `allowed = {"view_product", "add_to_cart", "checkout", "browse"}\nassert # action domain\nassert # product key\nassert # mart grain\n`,
    solution: `allowed = {"view_product", "add_to_cart", "checkout", "browse"}\nassert set(events["action"].dropna()).issubset(allowed)\nassert products["product_id"].is_unique\nassert daily_revenue["report_date"].is_unique`,
    hints: ['Use set inclusion.', 'pandas Series exposes is_unique.'],
    pitfall: 'Assertions are useful locally, but production pipelines should report failures with actionable context rather than only crashing.',
  }),
  A({
    id: 'ae-spark-silver', track: 'analytics-engineering', level: 'Intermediate', language: 'python', title: 'PySpark: Bronze → Silver event parsing',
    concept: 'Bronze preserves raw evidence; Silver parses and types fields using distributed column expressions.',
    why: 'This is the common lakehouse separation between recoverable raw data and trusted structured data.',
    context: 'bronze has one string column content with the same access-log format.',
    task: 'Create silver with ip_address, log_timestamp, url and status_code using pyspark.sql.functions.',
    starter: `from pyspark.sql import functions as F\n\nsilver = (bronze\n  .select(\n    # regexp_extract columns\n  )\n)`,
    solution: `from pyspark.sql import functions as F\n\nsilver = bronze.select(\n  F.regexp_extract("content", r"^(\\S+)", 1).alias("ip_address"),\n  F.to_timestamp(F.regexp_extract("content", r"\\[(.*?)\\]", 1), "dd/MMM/yyyy:HH:mm:ss Z").alias("log_timestamp"),\n  F.regexp_extract("content", r'"GET (.*?) HTTP', 1).alias("url"),\n  F.regexp_extract("content", r'HTTP/1.1" (\\d{3})', 1).cast("int").alias("status_code"),\n)`,
    hints: ['Stay in Spark Column expressions.', 'Do not collect raw log lines to the driver.'],
    pitfall: 'Python UDFs are unnecessary for regex extraction here and usually reduce optimizer visibility.', diagram: sparkDiagram,
  }),
  A({
    id: 'ae-spark-gold', track: 'analytics-engineering', level: 'Intermediate', language: 'python', title: 'PySpark: build the Gold revenue table',
    concept: 'Gold models apply business logic at a stable reporting grain.',
    why: 'The same dimensional join and aggregation rules apply whether the engine is DuckDB, pandas or Spark.',
    context: 'events(action, product_id, log_timestamp); products(product_id, product_price). products is small enough to broadcast.',
    task: 'Build daily revenue and items_added with a broadcast dimension join.',
    starter: `from pyspark.sql import functions as F\n\ngold = (events\n  .filter(#)\n  .join(F.broadcast(products), #, #)\n  .groupBy(#)\n  .agg(#)\n)`,
    solution: `from pyspark.sql import functions as F\n\ngold = (events\n  .filter(F.col("action") == "add_to_cart")\n  .join(F.broadcast(products), on="product_id", how="inner")\n  .withColumn("report_date", F.to_date("log_timestamp"))\n  .groupBy("report_date")\n  .agg(\n    F.sum("product_price").alias("potential_revenue"),\n    F.count("*").alias("items_added"),\n  )\n)`,
    hints: ['Broadcast only because the product dimension is small.', 'Group by the declared daily grain.'],
    pitfall: 'Broadcasting a large dimension can exhaust executor memory; it is a physical optimization, not a default rule.',
  }),
  A({
    id: 'ae-spark-delta-merge', track: 'analytics-engineering', level: 'Expert', language: 'python', title: 'PySpark + Delta: idempotent Gold merge',
    concept: 'MERGE reconciles a recalculated business key into an existing Delta target.',
    why: 'Idempotent writes are essential for retries, late-arriving data and backfills.',
    context: 'daily_updates has one row per report_date. Target table: gold.daily_revenue.',
    task: 'Merge by report_date, updating matches and inserting new dates.',
    starter: `from delta.tables import DeltaTable\n\ntarget = DeltaTable.forName(spark, "gold.daily_revenue")\n(target.alias("t")\n  .merge(daily_updates.alias("s"), #)\n  .#\n  .#\n  .execute())`,
    solution: `from delta.tables import DeltaTable\n\ntarget = DeltaTable.forName(spark, "gold.daily_revenue")\n(target.alias("t")\n  .merge(daily_updates.alias("s"), "t.report_date = s.report_date")\n  .whenMatchedUpdateAll()\n  .whenNotMatchedInsertAll()\n  .execute())`,
    hints: ['The daily business key is report_date.', 'Use matched update + not matched insert.'],
    pitfall: 'Ensure the source is unique on the merge key or a MERGE can be ambiguous or produce unexpected behavior.',
  }),
]

const mlopsLessons = [
  M({
    id: 'mlops-docker-run', track: 'mlops-practical', level: 'Beginner', language: 'shell', title: 'Docker: run and inspect a Python container',
    concept: 'An image is an immutable template; a container is a running instance. -it, --rm, -p and -v change runtime behavior.',
    why: 'Containers give reproducible runtimes for data/ML services and jobs.',
    context: 'Use python:3.12-slim. Run an interactive Python shell and remove the container on exit.',
    task: 'Write the docker pull, run and inspection commands.',
    starter: `docker # pull image\ndocker # list images\ndocker run # flags python:3.12-slim\ndocker # list all containers`,
    solution: `docker pull python:3.12-slim\ndocker images\ndocker run -it --rm python:3.12-slim\ndocker ps -a`,
    hints: ['-it gives an interactive TTY.', '--rm cleans the container after exit.'],
    pitfall: 'Do not confuse deleting a container (docker rm) with deleting an image (docker rmi).',
  }),
  M({
    id: 'mlops-dockerfile', track: 'mlops-practical', level: 'Beginner', language: 'dockerfile', title: 'Dockerfile: package a Python app',
    concept: 'Order Dockerfile layers so dependency installation can be cached independently from frequently changing source code.',
    why: 'Small, cache-friendly images make CI and deployment faster.',
    context: 'Files: app.py + requirements.txt. Base image: python:3.12-slim.',
    task: 'Complete a Dockerfile that installs requirements then runs app.py.',
    starter: `FROM python:3.12-slim\n\nCOPY # requirements\nWORKDIR /app\nRUN # install\nCOPY # app\nCMD # run app`,
    solution: `FROM python:3.12-slim\n\nCOPY requirements.txt /app/requirements.txt\nWORKDIR /app\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY app.py /app/app.py\nCMD ["python", "app.py"]`,
    hints: ['Copy requirements before app.py for better cache reuse.', 'Use exec-form CMD.'],
    pitfall: 'Copying the entire repository before pip install invalidates the dependency layer whenever any source file changes.',
  }),
  M({
    id: 'mlops-fastapi', track: 'mlops-practical', level: 'Beginner', language: 'python', title: 'FastAPI: expose a service endpoint',
    concept: 'FastAPI maps HTTP routes to typed Python functions and auto-generates OpenAPI docs.',
    why: 'Model/data services are commonly exposed behind a small API boundary.',
    context: 'GET / should return {"message": "Hello World"}. Server runs on 0.0.0.0:8000.',
    task: 'Create the FastAPI app and route.',
    starter: `from fastapi import FastAPI\n\napp = #\n\n@app.#("/")\ndef root():\n    return #`,
    solution: `from fastapi import FastAPI\n\napp = FastAPI()\n\n@app.get("/")\ndef root():\n    return {"message": "Hello World"}`,
    hints: ['Instantiate FastAPI.', 'Use @app.get.'],
    pitfall: 'Inside a container, bind the server to 0.0.0.0 rather than only localhost.',
  }),
  M({
    id: 'mlops-compose', track: 'mlops-practical', level: 'Intermediate', language: 'yaml', title: 'Docker Compose: FastAPI + MongoDB',
    concept: 'Compose creates a service network where containers resolve each other by service name.',
    why: 'A multi-service stack should be reproducible with one declarative configuration.',
    context: 'Services: mongo using mongo image; server built from ./server and exposed as 8000:8000.',
    task: 'Complete docker-compose.yml.',
    starter: `services:\n  mongo:\n    image: #\n  server:\n    build:\n      context: #\n    ports:\n      - #\n`,
    solution: `services:\n  mongo:\n    image: mongo\n  server:\n    build:\n      context: ./server\n      dockerfile: Dockerfile\n    ports:\n      - "8000:8000"\n`,
    hints: ['Compose service names become DNS names on the project network.', 'Host port 8000 maps to container port 8000.'],
    pitfall: 'From the server container, MongoDB is mongo:27017, not localhost:27017.', diagram: mlopsDiagram,
  }),
  M({
    id: 'mlops-mongo-api', track: 'mlops-practical', level: 'Intermediate', language: 'python', title: 'FastAPI + MongoDB: persist API data',
    concept: 'Only the API talks to the database; clients use the API contract.',
    why: 'This separates presentation, service logic and persistence into replaceable tiers.',
    context: 'Mongo service hostname is mongo. Add GET /add/{fruit} and GET /list.',
    task: 'Connect with MongoClient and implement the list endpoint.',
    starter: `from pymongo import MongoClient\n\nclient = MongoClient(# host, # port)\ncollection = client.test_database.test_collection\n\n@app.get("/list")\ndef list_fruits():\n    return #`,
    solution: `from pymongo import MongoClient\n\nclient = MongoClient("mongo", 27017)\ncollection = client.test_database.test_collection\n\n@app.get("/list")\ndef list_fruits():\n    return list(collection.find({}, {"_id": False}))`,
    hints: ['Use the Compose service name mongo.', 'Exclude _id if you want directly JSON-serializable rows.'],
    pitfall: 'Do not make the Streamlit client connect directly to MongoDB; keep the API boundary.',
  }),
  M({
    id: 'mlops-streamlit-client', track: 'mlops-practical', level: 'Intermediate', language: 'python', title: 'Streamlit: call the FastAPI service',
    concept: 'The UI is a client of the HTTP API, not of the persistence layer.',
    why: 'A clean service boundary makes authentication, validation and deployment easier.',
    context: 'Inside Compose the API URL is http://server:8000. POST/GET behavior stays in FastAPI.',
    task: 'Add a text input and button that calls /add/{fruit}.',
    starter: `import requests\nimport streamlit as st\n\nfruit = st.text_input("Fruit")\nif st.button("Add"):\n    response = requests.get(#)\n    st.write(#)`,
    solution: `import requests\nimport streamlit as st\n\nfruit = st.text_input("Fruit")\nif st.button("Add") and fruit:\n    response = requests.get(f"http://server:8000/add/{fruit}", timeout=10)\n    response.raise_for_status()\n    st.write(response.json())`,
    hints: ['Use the server service hostname inside Compose.', 'Check HTTP failures explicitly.'],
    pitfall: 'Do not hard-code localhost for container-to-container calls.',
  }),
  M({
    id: 'mlops-model-api', track: 'mlops-practical', level: 'Intermediate', language: 'python', title: 'Serve a trained model with FastAPI',
    concept: 'Training produces a versioned artifact; inference loads that artifact behind a typed request schema.',
    why: 'Separating training and serving avoids retraining on each request.',
    context: 'Iris-style features: sepal_length, sepal_width, petal_length, petal_width. model.pkl already exists.',
    task: 'Define the Pydantic request and return model.predict for one row.',
    starter: `class Item(BaseModel):\n    sepal_length: float\n    sepal_width: float\n    petal_length: float\n    petal_width: float\n\n@app.post("/predict")\ndef predict(item: Item):\n    row = [[#]]\n    return {"prediction": #}`,
    solution: `class Item(BaseModel):\n    sepal_length: float\n    sepal_width: float\n    petal_length: float\n    petal_width: float\n\n@app.post("/predict")\ndef predict(item: Item):\n    row = [[item.sepal_length, item.sepal_width, item.petal_length, item.petal_width]]\n    prediction = model.predict(row)[0]\n    return {"prediction": str(prediction)}`,
    hints: ['Keep feature ordering aligned with training.', 'Return a JSON-serializable scalar.'],
    pitfall: 'A model endpoint also needs schema/version compatibility; successful deserialization does not guarantee correct feature semantics.',
  }),
  M({
    id: 'mlops-mlflow', track: 'mlops-practical', level: 'Intermediate', language: 'python', title: 'MLflow: log metrics and register a model',
    concept: 'Experiment tracking stores parameters/metrics; a registry gives named model versions for serving.',
    why: 'A reproducible ML service must connect a deployed model back to a training run.',
    context: 'Metrics: rmse, mae, r2. Model: ElasticNet. Registry name: ElasticnetWineModel.',
    task: 'Complete the MLflow logging block.',
    starter: `with mlflow.start_run():\n    model.fit(train_x, train_y)\n    predicted = model.predict(test_x)\n    mlflow.log_param("alpha", alpha)\n    mlflow.log_metric("rmse", #)\n    mlflow.sklearn.log_model(#)`,
    solution: `with mlflow.start_run():\n    model.fit(train_x, train_y)\n    predicted = model.predict(test_x)\n    rmse, mae, r2 = eval_metrics(test_y, predicted)\n    mlflow.log_param("alpha", alpha)\n    mlflow.log_metric("rmse", rmse)\n    mlflow.log_metric("mae", mae)\n    mlflow.log_metric("r2", r2)\n    mlflow.sklearn.log_model(model, "model", registered_model_name="ElasticnetWineModel")`,
    hints: ['Log parameters separately from metrics.', 'Register the fitted model artifact.'],
    pitfall: 'A registry is not enough by itself; capture code/data/environment versions needed to reproduce the run.', diagram: mlopsDiagram,
  }),
  M({
    id: 'mlops-gh-actions', track: 'mlops-practical', level: 'Expert', language: 'yaml', title: 'CI: build and push a container safely',
    concept: 'CI builds/tests immutable artifacts from committed code and authenticates to registries using repository secrets.',
    why: 'Manual local builds are not a reliable release process.',
    context: 'Build on push. Registry: ghcr.io. Never place a PAT directly in workflow source.',
    task: 'Complete the GitHub Actions login/build/push skeleton using secrets.GITHUB_TOKEN.',
    starter: `name: container-ci\non: [push]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n      packages: write\n    steps:\n      - uses: actions/checkout@v4\n      - uses: docker/login-action@v3\n        with:\n          registry: ghcr.io\n          username: #\n          password: #\n      - run: docker build -t ghcr.io/\${{ github.repository }}:latest .\n      - run: # push`,
    solution: `name: container-ci\non: [push]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n      packages: write\n    steps:\n      - uses: actions/checkout@v4\n      - uses: docker/login-action@v3\n        with:\n          registry: ghcr.io\n          username: \${{ github.actor }}\n          password: \${{ secrets.GITHUB_TOKEN }}\n      - run: docker build -t ghcr.io/\${{ github.repository }}:latest .\n      - run: docker push ghcr.io/\${{ github.repository }}:latest`,
    hints: ['Use GitHub-provided credentials when sufficient.', 'Grant packages: write.'],
    pitfall: 'Never paste a personal access token into committed YAML, logs or exercise notes.',
  }),
  M({
    id: 'mlops-orchestration', track: 'mlops-practical', level: 'Expert', language: 'python', title: 'Orchestrate retraining',
    concept: 'A scheduler triggers training; training logs a candidate model; serving promotes or reloads an approved version.',
    why: 'Retraining is a pipeline with dependencies, retries and observability—not a while loop in the API server.',
    context: 'Use Airflow-style DAG semantics: train → evaluate → register. Daily schedule is enough for the exercise.',
    task: 'Wire the three tasks in dependency order.',
    starter: `with DAG("retrain_model", schedule="@daily", catchup=False) as dag:\n    train = PythonOperator(task_id="train", python_callable=train_model)\n    evaluate = PythonOperator(task_id="evaluate", python_callable=evaluate_model)\n    register = PythonOperator(task_id="register", python_callable=register_model)\n\n    # dependencies`,
    solution: `with DAG("retrain_model", schedule="@daily", catchup=False) as dag:\n    train = PythonOperator(task_id="train", python_callable=train_model)\n    evaluate = PythonOperator(task_id="evaluate", python_callable=evaluate_model)\n    register = PythonOperator(task_id="register", python_callable=register_model)\n\n    train >> evaluate >> register`,
    hints: ['Training must complete before evaluation.', 'Only register after evaluation.'],
    pitfall: 'Scheduling every few minutes is useful for learning but rarely appropriate for expensive production retraining without a real trigger/business need.', diagram: mlopsDiagram,
  }),
]

for (const track of [analyticsTrack, mlopsTrack]) {
  if (!tracks.some((item) => item.id === track.id)) tracks.push(track)
}

const existingIds = new Set(lessons.map((lesson) => lesson.id))
for (const lesson of [...analyticsLessons, ...mlopsLessons]) {
  if (!existingIds.has(lesson.id)) lessons.push(lesson)
}

export { analyticsLessons, mlopsLessons, analyticsTrack, mlopsTrack }
