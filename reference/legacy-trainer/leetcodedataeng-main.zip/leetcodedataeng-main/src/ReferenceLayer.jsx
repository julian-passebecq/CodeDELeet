import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import Editor from '@monaco-editor/react'
import { ArrowLeft, ArrowRight, BookOpen, Braces, Code2, Database, ExternalLink, Layers3, Play, Table2, X } from 'lucide-react'
import { cheatSheets } from './cheatSheets'
import { lessons, tracks } from './curriculum'
import { sqlChallenges } from './sqlChallenges'
import { engineChallenges } from './engineLab'
import { pythonLabChallenges } from './pythonLab'

const allPracticeItems = [...lessons, ...sqlChallenges, ...engineChallenges, ...pythonLabChallenges]

const extraPatterns = [
  {
    title: 'Join two datasets',
    idea: 'Match rows by a business key; choose the join type from the rows you need to preserve.',
    examples: [
      ['T-SQL', 'SELECT o.order_id, c.customer_name\nFROM dbo.orders o\nLEFT JOIN dbo.customers c\n  ON c.customer_id = o.customer_id;'],
      ['pandas', 'result = orders.merge(customers, on="customer_id", how="left")'],
      ['PySpark', 'result = orders.join(customers, "customer_id", "left")'],
    ],
  },
  {
    title: 'Null handling',
    idea: 'Detect missing values explicitly; null comparison rules differ from normal equality.',
    examples: [
      ['T-SQL', 'SELECT COALESCE(region, \'Unknown\') AS region\nFROM dbo.customer;'],
      ['pandas', 'df["region"] = df["region"].fillna("Unknown")'],
      ['PySpark', 'df = df.fillna({"region": "Unknown"})'],
    ],
  },
  {
    title: 'Conditional column',
    idea: 'Map business rules into a derived category without row-by-row imperative code.',
    examples: [
      ['T-SQL', 'CASE\n  WHEN amount >= 1000 THEN \'high\'\n  WHEN amount >= 100 THEN \'medium\'\n  ELSE \'low\'\nEND AS band'],
      ['pandas', 'df["band"] = np.select([df.amount.ge(1000), df.amount.ge(100)], ["high", "medium"], default="low")'],
      ['PySpark', 'df = df.withColumn("band", F.when(F.col("amount") >= 1000, "high").when(F.col("amount") >= 100, "medium").otherwise("low"))'],
    ],
  },
  {
    title: 'Running total / window',
    idea: 'Compute a value over related ordered rows without collapsing the row grain.',
    examples: [
      ['T-SQL', 'SUM(amount) OVER (\n  PARTITION BY customer_id\n  ORDER BY order_date\n  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW\n) AS running_total'],
      ['pandas', 'df["running_total"] = df.sort_values("order_date").groupby("customer_id")["amount"].cumsum()'],
      ['PySpark', 'w = Window.partitionBy("customer_id").orderBy("order_date").rowsBetween(Window.unboundedPreceding, Window.currentRow)\ndf = df.withColumn("running_total", F.sum("amount").over(w))'],
    ],
  },
  {
    title: 'Explode nested data',
    idea: 'Turn an array/list nested inside one record into multiple rows before relational processing.',
    examples: [
      ['BigQuery', 'SELECT order_id, item\nFROM orders, UNNEST(items) AS item;'],
      ['pandas', 'items = orders.explode("items", ignore_index=True)'],
      ['PySpark', 'items = orders.withColumn("item", F.explode("items"))'],
    ],
  },
  {
    title: 'Upsert / incremental merge',
    idea: 'Match source keys to target keys, update changed rows and insert new rows.',
    examples: [
      ['T-SQL', 'MERGE dbo.target AS t\nUSING dbo.stage AS s\nON t.id = s.id\nWHEN MATCHED THEN UPDATE SET t.value = s.value\nWHEN NOT MATCHED THEN INSERT (id, value) VALUES (s.id, s.value);'],
      ['Delta / PySpark', 'DeltaTable.forName(spark, "silver.target")\n  .alias("t").merge(source.alias("s"), "t.id = s.id")\n  .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()'],
    ],
  },
]

function ensureMount(parent, className, before = null) {
  if (!parent) return null
  let mount = parent.querySelector(`:scope > .${className}`)
  if (!mount) {
    mount = document.createElement('div')
    mount.className = className
    if (before) parent.insertBefore(mount, before)
    else parent.appendChild(mount)
  }
  return mount
}

function clickTrack(label) {
  const button = [...document.querySelectorAll('.track-nav button')].find((node) => node.textContent?.replace(/\s+/g, ' ').includes(label))
  if (button instanceof HTMLElement) button.click()
}

function ReferenceNav({ activeId, onOpen }) {
  return (
    <div className="reference-nav">
      <div className="reference-nav-label">LANGUAGES & PLATFORMS</div>
      {cheatSheets.map((sheet) => (
        <button key={sheet.id} className={activeId === sheet.id ? 'active' : ''} onClick={() => onOpen(sheet.id)}>
          <span className="reference-nav-icon">{sheet.icon}</span>
          <span><strong>{sheet.label}</strong><small>Cheat sheet + editor</small></span>
          <ArrowRight size={13} />
        </button>
      ))}
    </div>
  )
}

function CheatSheetPage({ sheet, appearance, onClose, onPractice }) {
  const [scratch, setScratch] = useState(sheet.starter)
  useEffect(() => setScratch(sheet.starter), [sheet.id])
  const editorTheme = appearance === 'black' ? 'vs-dark' : 'vs-light'
  return (
    <div className="reference-page">
      <header className="reference-page-header">
        <button onClick={onClose}><ArrowLeft size={16} /> Home</button>
        <div><span>{sheet.icon}</span><div><small>CHEAT SHEET</small><strong>{sheet.label}</strong></div></div>
        <button className="reference-practice-button" onClick={onPractice}><Play size={14} /> Practice drills</button>
      </header>
      <div className="reference-page-grid">
        <main className="reference-content">
          <section className="reference-hero">
            <span>{sheet.subtitle}</span>
            <h1>{sheet.label}</h1>
            <p>This page is the reference layer: scan the syntax and mental models first, then use the scratch editor or open the related drills.</p>
            <div className="reference-use-row">{sheet.useFor.map((item) => <span key={item}>{item}</span>)}</div>
          </section>

          <section className="reference-section">
            <div className="reference-section-title"><BookOpen size={17} /><div><span>QUICK REFERENCE</span><h2>Syntax you should recognize</h2></div></div>
            <div className="reference-snippet-grid">
              {sheet.sections.map(([title, code]) => (
                <article key={title} className="reference-snippet">
                  <strong>{title}</strong>
                  <pre><code>{code}</code></pre>
                </article>
              ))}
            </div>
          </section>

          <div className="reference-two-col">
            <section className="reference-list-card">
              <span>MENTAL MODELS</span>
              <h2>Understand, do not only memorize</h2>
              <ul>{sheet.mentalModels.map((item) => <li key={item}>{item}</li>)}</ul>
            </section>
            <section className="reference-list-card">
              <span>INTERVIEW CHECKLIST</span>
              <h2>Topics worth being able to explain</h2>
              <ul>{sheet.interview.map((item) => <li key={item}>{item}</li>)}</ul>
            </section>
          </div>
        </main>

        <aside className="reference-editor-column">
          <div className="reference-editor-heading">
            <div><Braces size={16} /><span><strong>Scratch editor</strong><small>Type from memory before opening a drill.</small></span></div>
            <span>{sheet.label}</span>
          </div>
          <div className="reference-scratch-editor">
            <Editor
              height="100%"
              language={sheet.language}
              value={scratch}
              onChange={(value) => setScratch(value ?? '')}
              theme={editorTheme}
              options={{ minimap: { enabled: false }, fontSize: 13, lineHeight: 21, wordWrap: 'on', scrollBeyondLastLine: false, automaticLayout: true, padding: { top: 14 } }}
            />
          </div>
          <div className="reference-editor-note">
            <strong>Reference ≠ answer</strong>
            <p>The cheat sheet is intentionally broader than a single problem. Practice drills still hide their reference solution until you choose to open it.</p>
          </div>
        </aside>
      </div>
    </div>
  )
}

function FullCurriculum() {
  return (
    <section className="full-curriculum-section">
      <div className="full-curriculum-heading">
        <div><span>FULL PRACTICE CURRICULUM</span><h2>All coding and engineering drills</h2></div>
        <p>The reference pages above teach the language. These tracks are the exercises. Operational topics remain here even when they are not promoted into the language sidebar.</p>
      </div>
      <div className="full-curriculum-grid">
        {tracks.map((track) => {
          const count = lessons.filter((lesson) => lesson.track === track.id).length
          return (
            <button key={track.id} onClick={() => clickTrack(track.short)}>
              <span className="full-curriculum-icon">{track.icon}</span>
              <div><strong>{track.name}</strong><small>{count} drills</small><p>{track.description}</p></div>
              <ArrowRight size={14} />
            </button>
          )
        })}
      </div>
    </section>
  )
}

function ExpandedPatterns() {
  return (
    <div className="extended-patterns">
      <div className="extended-patterns-heading"><span>MORE TRANSFERABLE PATTERNS</span><h2>The bridge should cover the transformations you actually repeat.</h2></div>
      {extraPatterns.map((pattern) => (
        <section className="extended-pattern-card" key={pattern.title}>
          <div className="extended-pattern-copy"><span>PATTERN</span><h2>{pattern.title}</h2><p>{pattern.idea}</p></div>
          <div className="extended-pattern-code-grid">
            {pattern.examples.map(([label, code]) => <div key={label}><strong>{label}</strong><pre><code>{code}</code></pre></div>)}
          </div>
        </section>
      ))}
    </div>
  )
}

function variantLogo(label) {
  const normalized = label.toLowerCase()
  if (normalized.includes('pandas')) return 'https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/pandas/pandas-original.svg'
  if (normalized.includes('spark')) return 'https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/apachespark/apachespark-original.svg'
  if (normalized.includes('bigquery')) return 'https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/googlecloud/googlecloud-original.svg'
  if (normalized.includes('t-sql') || normalized.includes('sql server')) return 'https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/microsoftsqlserver/microsoftsqlserver-original.svg'
  if (normalized.includes('python')) return 'https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/python/python-original.svg'
  return null
}

function VariantButtons({ select }) {
  const [value, setValue] = useState(select?.value ?? '')
  const options = useMemo(() => select ? [...select.options].map((option) => ({ value: option.value, label: option.textContent })) : [], [select])
  useEffect(() => {
    if (!select) return undefined
    const sync = () => setValue(select.value)
    select.addEventListener('change', sync)
    return () => select.removeEventListener('change', sync)
  }, [select])
  if (!select || options.length < 2) return null
  const choose = (next) => {
    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')?.set
    nativeSetter?.call(select, next)
    select.dispatchEvent(new Event('change', { bubbles: true }))
    setValue(next)
  }
  return (
    <div className="variant-button-row" role="group" aria-label="Language or engine">
      {options.map((option) => {
        const logo = variantLogo(option.label)
        return (
          <button key={option.value} className={value === option.value ? 'active' : ''} onClick={() => choose(option.value)} title={option.label} aria-pressed={value === option.value}>
            {logo ? <img src={logo} alt="" /> : <span>{option.label.slice(0, 2).toUpperCase()}</span>}
            <small>{option.label}</small>
          </button>
        )
      })}
    </div>
  )
}

const previewTemplates = [
  {
    test: (text) => /orders?/i.test(text) && /customers?/i.test(text),
    tables: [
      { name: 'customers', columns: ['customer_id', 'customer_name'], rows: [[1, 'Amina'], [2, 'Jon'], [3, 'Sara']] },
      { name: 'orders', columns: ['order_id', 'customer_id', 'amount'], rows: [[101, 1, 120], [102, 2, 75], [103, 1, 240], [104, 4, 90]] },
    ],
  },
  {
    test: (text) => /history|updated_at/i.test(text),
    tables: [{ name: 'history', columns: ['customer_id', 'status', 'updated_at'], rows: [[1, 'NEW', '2026-09-01'], [1, 'ACTIVE', '2026-09-03'], [2, 'ACTIVE', '2026-09-02']] }],
  },
  {
    test: (text) => /matches?/i.test(text),
    tables: [{ name: 'matches', columns: ['division', 'home_team', 'away_team', 'home_goals', 'away_goals'], rows: [['L1', 'Lille', 'Nice', 2, 0], ['L1', 'Paris', 'Lille', 1, 2], ['L1', 'Lille', 'Lyon', 0, 1]] }],
  },
  {
    test: (text) => /sales|amount/i.test(text),
    tables: [{ name: 'sales', columns: ['customer_id', 'status', 'amount'], rows: [[1, 'ACTIVE', 120], [1, 'ACTIVE', 80], [2, 'INACTIVE', 50], [2, 'ACTIVE', 300]] }],
  },
  {
    test: (text) => /employees?/i.test(text) && /departments?/i.test(text),
    tables: [
      { name: 'departments', columns: ['department_id', 'department_name'], rows: [[10, 'Data'], [20, 'Finance']] },
      { name: 'employees', columns: ['employee_id', 'department_id', 'name'], rows: [[1, 10, 'Ana'], [2, 10, 'Leo'], [3, 20, 'Mina']] },
    ],
  },
]

function findCurrentPracticeItem() {
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  if (!title) return null
  return allPracticeItems.find((item) => item.title === title) ?? null
}

function DataPreview({ practiceKey }) {
  const item = useMemo(() => findCurrentPracticeItem(), [practiceKey])
  const [open, setOpen] = useState(true)
  if (!item) return null
  const context = item.context ?? ''
  const haystack = `${item.title} ${item.task ?? ''} ${context}`
  const template = previewTemplates.find((entry) => entry.test(haystack))
  if (!context && !template) return null
  return (
    <section className={`practice-data-preview ${open ? 'open' : ''}`}>
      <button className="practice-data-preview-header" onClick={() => setOpen((value) => !value)} aria-expanded={open}>
        <span><Table2 size={15} /><strong>Data preview</strong><small>{template ? 'Illustrative rows + exercise schema' : 'Exercise schema'}</small></span>
        <span>{open ? 'Hide' : 'Show'}</span>
      </button>
      {open && (
        <div className="practice-data-preview-body">
          {context && <div className="practice-schema"><span>SCHEMA / CONTEXT</span><p>{context}</p></div>}
          {template && <div className="practice-preview-tables">
            {template.tables.map((table) => (
              <div className="preview-table-wrap" key={table.name}>
                <strong>{table.name}</strong>
                <table><thead><tr>{table.columns.map((column) => <th key={column}>{column}</th>)}</tr></thead><tbody>{table.rows.map((row, index) => <tr key={index}>{row.map((value, cell) => <td key={cell}>{String(value)}</td>)}</tr>)}</tbody></table>
              </div>
            ))}
          </div>}
          {template && <p className="preview-disclaimer">Illustrative trainer rows. The original notebook sample frames were not stored in the current repository, so these rows demonstrate the schema/pattern without pretending to be the original notebook data.</p>}
        </div>
      )}
    </section>
  )
}

export default function ReferenceLayer() {
  const [activeId, setActiveId] = useState(null)
  const [sidebarMount, setSidebarMount] = useState(null)
  const [mainMount, setMainMount] = useState(null)
  const [homeMount, setHomeMount] = useState(null)
  const [patternMount, setPatternMount] = useState(null)
  const [variantMount, setVariantMount] = useState(null)
  const [variantSelect, setVariantSelect] = useState(null)
  const [dataMount, setDataMount] = useState(null)
  const [practiceKey, setPracticeKey] = useState('')
  const [appearance, setAppearance] = useState(() => document.documentElement.dataset.editorAppearance ?? 'gray')

  useEffect(() => {
    document.body.classList.add('reference-layer-ready')
    const sync = () => {
      const sidebar = document.querySelector('.sidebar')
      const sidebarLabel = sidebar?.querySelector('.sidebar-label') ?? null
      setSidebarMount(ensureMount(sidebar, 'reference-nav-mount', sidebarLabel))

      const main = document.querySelector('.main-area')
      setMainMount(ensureMount(main, 'reference-page-mount'))

      const simpleHome = document.querySelector('.simple-home')
      setHomeMount(ensureMount(simpleHome, 'full-curriculum-mount'))

      const patternList = document.querySelector('.pattern-list')
      setPatternMount(ensureMount(patternList, 'extended-pattern-mount'))

      const select = document.querySelector('.code-pane-actions .variant-select')
      if (select instanceof HTMLSelectElement) {
        select.classList.add('variant-select-enhanced')
        const host = select.parentElement
        let mount = host?.querySelector('.variant-button-mount') ?? null
        if (!mount && host) {
          mount = document.createElement('div')
          mount.className = 'variant-button-mount'
          host.insertBefore(mount, select)
        }
        setVariantSelect(select)
        setVariantMount(mount)
      } else {
        setVariantSelect(null)
        setVariantMount(null)
      }

      const editor = document.querySelector('.leetcode-practice .editor-wrap')
      if (editor?.parentElement) {
        let mount = editor.parentElement.querySelector(':scope > .data-preview-mount')
        if (!mount) {
          mount = document.createElement('div')
          mount.className = 'data-preview-mount'
          editor.insertAdjacentElement('afterend', mount)
        }
        setDataMount(mount)
        const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim() ?? ''
        const variant = select instanceof HTMLSelectElement ? select.value : ''
        setPracticeKey(`${title}|${variant}`)
      } else {
        setDataMount(null)
      }
    }
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })
    const closeReference = (event) => {
      const target = event.target instanceof Element ? event.target.closest('.brand, .main-nav button') : null
      if (target) setActiveId(null)
    }
    document.addEventListener('click', closeReference, true)
    return () => {
      observer.disconnect()
      document.removeEventListener('click', closeReference, true)
      document.body.classList.remove('reference-layer-ready')
    }
  }, [])

  useEffect(() => {
    const update = (event) => setAppearance(event.detail ?? document.documentElement.dataset.editorAppearance ?? 'gray')
    window.addEventListener('de-editor-appearance', update)
    return () => window.removeEventListener('de-editor-appearance', update)
  }, [])

  const sheet = cheatSheets.find((item) => item.id === activeId) ?? null
  const openSheet = (id) => {
    setActiveId(id)
    window.scrollTo({ top: 0, behavior: 'instant' })
  }
  const openPractice = () => {
    if (!sheet) return
    setActiveId(null)
    window.setTimeout(() => clickTrack(sheet.practiceTarget), 0)
  }

  return (
    <>
      {sidebarMount && createPortal(<ReferenceNav activeId={activeId} onOpen={openSheet} />, sidebarMount)}
      {mainMount && sheet && createPortal(<CheatSheetPage sheet={sheet} appearance={appearance} onClose={() => setActiveId(null)} onPractice={openPractice} />, mainMount)}
      {homeMount && createPortal(<FullCurriculum />, homeMount)}
      {patternMount && createPortal(<ExpandedPatterns />, patternMount)}
      {variantMount && variantSelect && createPortal(<VariantButtons select={variantSelect} />, variantMount)}
      {dataMount && createPortal(<DataPreview practiceKey={practiceKey} />, dataMount)}
    </>
  )
}
