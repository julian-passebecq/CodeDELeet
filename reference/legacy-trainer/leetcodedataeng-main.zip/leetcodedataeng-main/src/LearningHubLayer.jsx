import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import Editor from '@monaco-editor/react'
import { ArrowLeft, ArrowRight, BookOpen, Braces, Code2, Database, GraduationCap, Network, Play } from 'lucide-react'
import { cheatSheets } from './cheatSheets'
import { extraHubs, hubExtensions } from './learningHubContent'
import { lessons } from './curriculum'
import { sqlChallenges } from './sqlChallenges'
import { engineChallenges } from './engineLab'
import { pythonLabChallenges } from './pythonLab'

const allHubs = [...cheatSheets, ...extraHubs]
const allPracticeItems = [...lessons, ...sqlChallenges, ...engineChallenges, ...pythonLabChallenges]
const fiveParts = [
  ['cheat', 'Cheat sheet', BookOpen],
  ['algorithms', 'Algorithms / patterns', Network],
  ['source', 'Source labs', Database],
  ['problems', 'Typical problems', Code2],
  ['interview', 'Interview', GraduationCap],
]

const shortLabels = {
  python: 'Python', pandas: 'pandas / NumPy', pyspark: 'PySpark', sql: 'SQL', duckdb: 'DuckDB',
  powershell: 'PowerShell', 'csharp-functions': 'C#', 'csharp-tabular': 'C# / TE', airflow: 'Airflow',
  dax: 'BI / DAX', kubernetes: 'Kubernetes', dbt: 'dbt', bi: 'BI', 'de-interview': 'Data Engineering',
  'coding-concepts': 'Algorithms',
}

const extraNavIds = ['coding-concepts', 'duckdb', 'dbt', 'de-interview', 'bi']

function ensureMount(parent, className, before = null) {
  if (!parent) return null
  let mount = parent.querySelector(`:scope > .${className}`)
  if (!mount) {
    mount = document.createElement('div')
    mount.className = className
    if (before) parent.insertBefore(mount, before)
    else parent.appendChild(mount)
  }
  return mount
}

function normalized(value = '') {
  return value.toLowerCase().replace(/[^a-z0-9#+]+/g, ' ').trim()
}

function hubByLabel(label) {
  const key = normalized(label)
  return allHubs.find((hub) => normalized(hub.label) === key || normalized(shortLabels[hub.id]) === key) ?? null
}

function currentPracticeItem() {
  const title = document.querySelector('.ide-breadcrumb strong')?.textContent?.trim()
  if (!title) return null
  return allPracticeItems.find((item) => item.title === title) ?? null
}

function hubForPractice(item) {
  if (!item) return null
  const variant = document.querySelector('.variant-select')?.value ?? ''
  if (item.collection === 'python-lab') return 'python'
  if (item.collection === 'sql-lab') return variant === 'duckdb' ? 'duckdb' : 'sql'
  if (item.collection === 'engine-lab') {
    if (variant === 'pandas') return 'pandas'
    if (variant === 'pyspark') return 'pyspark'
    if (variant === 'duckdb') return 'duckdb'
    return 'sql'
  }
  return {
    algorithms: 'coding-concepts', python: 'python', pandas: 'pandas', pyspark: 'pyspark', sql: 'sql',
    dax: 'bi', powershell: 'powershell', airflow: 'airflow', kubernetes: 'kubernetes', csharp: 'csharp-tabular',
  }[item.track] ?? null
}

function clickContaining(selector, text) {
  const button = [...document.querySelectorAll(selector)].find((node) => node.textContent?.replace(/\s+/g, ' ').includes(text))
  if (button instanceof HTMLElement) {
    button.click()
    return true
  }
  return false
}

function openExistingPractice(hubId, sourceMode = false) {
  if (hubId === 'python') return clickContaining('.main-nav button', 'Python Syntax Gym') || clickContaining('.track-nav button', 'Python')
  if (hubId === 'sql') return clickContaining('.main-nav button', 'SQL Dialect Lab') || clickContaining('.track-nav button', 'T-SQL')
  if (hubId === 'duckdb') {
    const opened = clickContaining('.main-nav button', 'SQL Dialect Lab')
    window.setTimeout(() => clickContaining('.dialect-picker button', 'DuckDB'), 60)
    return opened
  }
  if (hubId === 'pandas' || hubId === 'pyspark') return clickContaining('.main-nav button', 'Multi-Engine Lab') || clickContaining('.track-nav button', hubId === 'pandas' ? 'Pandas' : 'Spark')
  if (hubId === 'coding-concepts') return clickContaining('.track-nav button', 'Algorithms')
  if (hubId === 'bi' || hubId === 'dax') return clickContaining('.track-nav button', 'DAX')
  if (hubId === 'de-interview') return clickContaining('.track-nav button', 'Start here')
  if (hubId === 'dbt') return sourceMode ? clickContaining('.main-nav button', 'SQL Dialect Lab') : false
  const hub = allHubs.find((item) => item.id === hubId)
  return hub?.practiceTarget ? clickContaining('.track-nav button', hub.practiceTarget) : false
}

function sourceInfo(hubId) {
  const core = (track) => lessons.filter((item) => item.track === track)
  let items = []
  let label = 'Trainer drills'
  if (hubId === 'python') { items = [...pythonLabChallenges, ...core('python')]; label = 'Python Syntax Gym + core Python' }
  else if (hubId === 'sql') { items = [...sqlChallenges, ...core('sql')]; label = 'Uploaded SQL notebook packs + SQL core' }
  else if (hubId === 'duckdb') { items = [...sqlChallenges, ...engineChallenges.filter((item) => item.variants?.duckdb)]; label = 'Uploaded SQL packs in DuckDB/source mode' }
  else if (hubId === 'pandas') { items = [...core('pandas'), ...engineChallenges.filter((item) => item.variants?.pandas)]; label = 'pandas core + multi-engine lab' }
  else if (hubId === 'pyspark') { items = [...core('pyspark'), ...engineChallenges.filter((item) => item.variants?.pyspark)]; label = 'PySpark core + multi-engine lab' }
  else if (hubId === 'coding-concepts') { items = core('algorithms'); label = 'Classical algorithm drills' }
  else if (hubId === 'bi' || hubId === 'dax') { items = core('dax'); label = 'DAX / BI drills' }
  else {
    const map = { powershell: 'powershell', airflow: 'airflow', kubernetes: 'kubernetes', 'csharp-tabular': 'csharp', 'csharp-functions': 'csharp' }
    if (map[hubId]) items = core(map[hubId])
  }
  const packs = [...new Set(items.map((item) => item.sourcePack).filter(Boolean))]
  return { items, packs, label }
}

function AlgorithmVisual({ item }) {
  const id = item?.id ?? ''
  let nodes = ['input', 'pattern', 'result']
  if (id.includes('linear-search')) nodes = ['table names', 'scan → compare', 'match → break']
  else if (/frequency|dict|hash/i.test(item?.title ?? '')) nodes = ['rows', 'hash map counts', '{key: count}']
  else if (/dedup/i.test(item?.title ?? '')) nodes = ['rows', 'seen set', 'unique rows']
  else if (/two pointer/i.test(item?.title ?? '')) nodes = ['sorted A + B', 'two cursors', 'merged stream']
  else if (/sliding window/i.test(item?.title ?? '')) nodes = ['events', 'moving window state', 'rolling metric']
  else if (/topological/i.test(item?.title ?? '')) nodes = ['DAG', 'indegree / queue', 'valid task order']
  const complexity = item?.concept?.match(/O\([^)]*\)/)?.[0] ?? (id.includes('linear-search') ? 'O(n)' : '')
  return (
    <div className="algorithm-mini-visual" aria-label="Algorithm mental model">
      {nodes.map((node, index) => <span key={node}><strong>{node}</strong>{index < nodes.length - 1 && <ArrowRight size={14} />}</span>)}
      {complexity && <em>{complexity}</em>}
    </div>
  )
}

function ExtraHubNav({ activeId, onOpen }) {
  return (
    <div className="learning-extra-nav">
      <div className="reference-nav-label">INTERVIEW & DOMAINS</div>
      {extraNavIds.map((id) => {
        const hub = allHubs.find((item) => item.id === id)
        if (!hub) return null
        return <button key={id} className={activeId === id ? 'active' : ''} onClick={() => onOpen(id)}><span>{hub.icon}</span><div><strong>{hub.label}</strong><small>{hub.subtitle}</small></div><ArrowRight size={13} /></button>
      })}
    </div>
  )
}

function CheatTab({ hub, appearance }) {
  const [scratch, setScratch] = useState(hub.starter ?? '')
  useEffect(() => setScratch(hub.starter ?? ''), [hub.id])
  const theme = appearance === 'black' ? 'de-black' : appearance === 'light' ? 'de-light' : 'de-gray'
  return (
    <div className="hub-cheat-grid">
      <div>
        <div className="hub-section-title"><BookOpen size={17} /><div><span>QUICK REFERENCE</span><h2>Recognize these patterns</h2></div></div>
        <div className="hub-snippet-grid">{hub.sections.map(([title, code]) => <article key={title}><strong>{title}</strong><pre><code>{code}</code></pre></article>)}</div>
        <div className="hub-mental"><strong>Mental models</strong>{hub.mentalModels.map((item) => <span key={item}>{item}</span>)}</div>
      </div>
      <aside className="hub-scratch"><div><Braces size={15} /><strong>Scratch editor</strong><small>Write from memory.</small></div><Editor height="390px" language={hub.language} value={scratch} onChange={(value) => setScratch(value ?? '')} theme={theme} options={{ minimap: { enabled: false }, fontSize: 13, lineHeight: 21, wordWrap: 'on', automaticLayout: true, scrollBeyondLastLine: false, padding: { top: 14 } }} /></aside>
    </div>
  )
}

function AlgorithmsTab({ hub }) {
  const ext = hubExtensions[hub.id] ?? {}
  const algorithms = ext.algorithms ?? hubExtensions['coding-concepts']?.algorithms ?? []
  return <div className="hub-pattern-grid">{algorithms.map(([title, text]) => <article key={title}><span>ALGORITHM / PATTERN</span><h3>{title}</h3><p>{text}</p></article>)}</div>
}

function SourceTab({ hub, onPractice }) {
  const info = sourceInfo(hub.id)
  const samples = info.items.slice(0, 10)
  return (
    <div className="hub-source-layout">
      <section className="hub-source-summary"><span>SOURCE LABS</span><h2>{info.label}</h2><strong>{info.items.length}</strong><p>{info.packs.length ? `${info.packs.length} uploaded/source pack groups are mapped here.` : 'No uploaded source pack is explicitly mapped here; existing trainer drills remain available.'}</p>{info.items.length > 0 && <button onClick={() => onPractice(true)}><Play size={14} /> Open practice</button>}</section>
      <div>
        {info.packs.length > 0 && <div className="hub-pack-list"><strong>Original source packs</strong>{info.packs.map((pack) => <span key={pack}>{pack}</span>)}</div>}
        <div className="hub-source-items">{samples.map((item) => <div key={`${item.collection ?? 'core'}-${item.id}`}><span>{item.level ?? 'Practice'}</span><strong>{item.title}</strong><small>{item.sourcePack ? `Source: ${item.sourcePack}` : item.task}</small></div>)}</div>
      </div>
    </div>
  )
}

function ProblemsTab({ hub, onPractice }) {
  const ext = hubExtensions[hub.id] ?? {}
  const fallback = sourceInfo(hub.id).items.slice(0, 6).map((item) => item.task || item.title)
  const problems = ext.problems?.length ? ext.problems : fallback
  return (
    <div className="hub-problems"><div className="hub-section-title"><Code2 size={17} /><div><span>TYPICAL PROBLEMS</span><h2>Problems worth solving without a template</h2></div></div><ol>{problems.map((problem, index) => <li key={problem}><span>{String(index + 1).padStart(2, '0')}</span><p>{problem}</p></li>)}</ol>{sourceInfo(hub.id).items.length > 0 && <button onClick={() => onPractice(false)}><Play size={14} /> Open drills</button>}</div>
  )
}

function InterviewTab({ hub }) {
  const ext = hubExtensions[hub.id] ?? {}
  const cards = ext.interviewCards ?? []
  if (!cards.length) {
    return <div className="hub-interview-simple"><div className="hub-section-title"><GraduationCap size={17} /><div><span>INTERVIEW</span><h2>Explain these clearly out loud</h2></div></div>{hub.interview.map((topic, index) => <article key={topic}><span>Q{index + 1}</span><strong>{topic}</strong><p>Explain the concept, give one concrete data-engineering example, state one trade-off, then sketch the relevant syntax from the cheat sheet.</p></article>)}</div>
  }
  return <div className="hub-interview-grid">{cards.map(([title, theory, code, question, answer, problem]) => <article key={title}><header><span>INTERVIEW CARD</span><h3>{title}</h3></header><p>{theory}</p>{code && <pre><code>{code}</code></pre>}<div className="hub-qa"><strong>Question</strong><p>{question}</p><strong>Good answer</strong><p>{answer}</p></div><footer><strong>Coding prompt</strong><p>{problem}</p></footer></article>)}</div>
}

function HubPage({ hub, appearance, onClose, onPractice }) {
  const [tab, setTab] = useState('cheat')
  useEffect(() => setTab('cheat'), [hub.id])
  const source = useMemo(() => sourceInfo(hub.id), [hub.id])
  const ext = hubExtensions[hub.id] ?? {}
  return (
    <div className="learning-hub-page">
      <header className="learning-hub-header"><button onClick={onClose}><ArrowLeft size={15} /> Home</button><div><span>{hub.icon}</span><div><small>LEARNING HUB</small><strong>{hub.label}</strong></div></div><div className="hub-header-meta"><span>{source.items.length} drills</span><span>{ext.interviewCards?.length ?? hub.interview.length} interview topics</span></div></header>
      <main className="learning-hub-content">
        <section className="learning-hub-hero"><span>{hub.subtitle}</span><h1>{hub.label}</h1><p>Reference first, then patterns, source material, problems and interview practice.</p><div>{hub.useFor.map((item) => <span key={item}>{item}</span>)}</div></section>
        <nav className="hub-five-part-nav">{fiveParts.map(([id, label, Icon]) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}><Icon size={15} /><span><strong>{label}</strong><small>{id === 'source' ? `${source.items.length} mapped drills` : id === 'interview' ? `${ext.interviewCards?.length ?? hub.interview.length} topics` : 'Open'}</small></span></button>)}</nav>
        <section className="hub-tab-content">{tab === 'cheat' && <CheatTab hub={hub} appearance={appearance} />}{tab === 'algorithms' && <AlgorithmsTab hub={hub} />}{tab === 'source' && <SourceTab hub={hub} onPractice={(sourceMode) => onPractice(sourceMode)} />}{tab === 'problems' && <ProblemsTab hub={hub} onPractice={(sourceMode) => onPractice(sourceMode)} />}{tab === 'interview' && <InterviewTab hub={hub} />}</section>
      </main>
    </div>
  )
}

export default function LearningHubLayer() {
  const [activeId, setActiveId] = useState(null)
  const [mainMount, setMainMount] = useState(null)
  const [extraNavMount, setExtraNavMount] = useState(null)
  const [visualMount, setVisualMount] = useState(null)
  const [visualItem, setVisualItem] = useState(null)
  const [appearance, setAppearance] = useState(() => document.documentElement.dataset.editorAppearance ?? 'gray')

  useEffect(() => {
    const open = (id) => {
      if (!allHubs.some((hub) => hub.id === id)) return
      setActiveId(id)
      window.scrollTo({ top: 0, behavior: 'instant' })
    }
    const onOpenEvent = (event) => open(event.detail)
    window.addEventListener('de-open-learning-hub', onOpenEvent)

    const captureNavigation = (event) => {
      const target = event.target instanceof Element ? event.target : null
      const referenceButton = target?.closest('.reference-nav button')
      if (referenceButton) {
        const hub = hubByLabel(referenceButton.querySelector('strong')?.textContent ?? '')
        if (hub) {
          event.preventDefault()
          event.stopPropagation()
          event.stopImmediatePropagation?.()
          open(hub.id)
          return
        }
      }
      const breadcrumb = target?.closest('.ide-breadcrumb span[data-learning-hub-id]')
      if (breadcrumb) {
        event.preventDefault()
        event.stopPropagation()
        open(breadcrumb.dataset.learningHubId)
      }
    }
    document.addEventListener('click', captureNavigation, true)

    const captureKey = (event) => {
      if (!['Enter', ' '].includes(event.key)) return
      const target = event.target instanceof Element ? event.target.closest('.ide-breadcrumb span[data-learning-hub-id]') : null
      if (!target) return
      event.preventDefault()
      open(target.dataset.learningHubId)
    }
    document.addEventListener('keydown', captureKey, true)

    const sync = () => {
      const main = document.querySelector('.main-area')
      setMainMount(ensureMount(main, 'learning-hub-layer-mount'))
      const sidebar = document.querySelector('.sidebar')
      const sidebarLabel = sidebar?.querySelector('.sidebar-label') ?? null
      setExtraNavMount(ensureMount(sidebar, 'learning-extra-nav-mount', sidebarLabel))

      const actions = document.querySelector('.code-pane-actions')
      if (actions) actions.classList.toggle('has-variants', Boolean(actions.querySelector('.variant-select')))

      const item = currentPracticeItem()
      const hubId = hubForPractice(item)
      const crumb = document.querySelector('.ide-breadcrumb span')
      if (crumb && hubId) {
        const nextLabel = shortLabels[hubId] ?? allHubs.find((hub) => hub.id === hubId)?.label ?? crumb.textContent
        if (crumb.textContent !== nextLabel) crumb.textContent = nextLabel
        crumb.dataset.learningHubId = hubId
        crumb.setAttribute('role', 'button')
        crumb.setAttribute('tabindex', '0')
        crumb.setAttribute('title', `Open ${nextLabel} learning hub`)
      }

      const description = document.querySelector('.problem-description')
      if (description) {
        for (const section of description.querySelectorAll('.problem-section')) {
          const heading = section.querySelector('h3')?.textContent?.trim() ?? ''
          section.classList.toggle('compact-concept', heading === 'Concept')
          section.classList.toggle('compact-why', heading.startsWith('Why this matters'))
        }
      }

      const practiceRule = document.querySelector('.problem-section.practice-rule')
      if (practiceRule) practiceRule.classList.add('compact-hide-rule')

      if (item?.track === 'algorithms') {
        const meta = document.querySelector('.problem-description .problem-meta')
        let mount = meta?.parentElement?.querySelector(':scope > .algorithm-visual-mount') ?? null
        if (!mount && meta) {
          mount = document.createElement('div')
          mount.className = 'algorithm-visual-mount'
          meta.insertAdjacentElement('afterend', mount)
        }
        setVisualMount(mount)
        setVisualItem(item)
      } else {
        setVisualMount(null)
        setVisualItem(null)
      }
    }
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => {
      observer.disconnect()
      document.removeEventListener('click', captureNavigation, true)
      document.removeEventListener('keydown', captureKey, true)
      window.removeEventListener('de-open-learning-hub', onOpenEvent)
    }
  }, [])

  useEffect(() => {
    document.body.classList.toggle('learning-hub-open', Boolean(activeId))
    return () => document.body.classList.remove('learning-hub-open')
  }, [activeId])

  useEffect(() => {
    const update = (event) => setAppearance(event.detail ?? document.documentElement.dataset.editorAppearance ?? 'gray')
    window.addEventListener('de-editor-appearance', update)
    return () => window.removeEventListener('de-editor-appearance', update)
  }, [])

  const hub = allHubs.find((item) => item.id === activeId) ?? null
  const openHub = (id) => {
    setActiveId(id)
    window.scrollTo({ top: 0, behavior: 'instant' })
  }
  const closeHub = () => setActiveId(null)
  const practice = (sourceMode = false) => {
    if (!hub) return
    const id = hub.id
    closeHub()
    window.setTimeout(() => openExistingPractice(id, sourceMode), 30)
  }

  return <>{extraNavMount && createPortal(<ExtraHubNav activeId={activeId} onOpen={openHub} />, extraNavMount)}{mainMount && hub && createPortal(<HubPage hub={hub} appearance={appearance} onClose={closeHub} onPractice={practice} />, mainMount)}{visualMount && visualItem && createPortal(<AlgorithmVisual item={visualItem} />, visualMount)}</>
}
