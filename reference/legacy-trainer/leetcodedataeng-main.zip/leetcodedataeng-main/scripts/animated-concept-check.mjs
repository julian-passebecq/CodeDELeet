import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import { lessons } from '../src/curriculum.js'

const read = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8')
const layer = read('src/AnimatedConceptLayer.jsx')
const css = `${read('src/animatedConcepts.css')}\n${read('src/animatedConceptExtras.css')}`
const main = read('src/main.jsx')
const research = read('VISUAL_LEARNING_RESEARCH.md')

const algorithmLessons = lessons.filter((item) => item.track === 'algorithms')
const expectedAlgorithmIds = [
  'al-linear-search',
  'al-frequency-map',
  'al-dedupe-order',
  'al-stack-queue',
  'al-batching',
  'al-hash-join',
  'al-binary-search',
  'al-sorting',
  'al-two-pointers',
  'al-sliding-window',
  'al-prefix-sum',
  'al-heap-top-k',
  'al-graph-traversal',
  'al-topological-sort',
  'al-merge-intervals',
]

assert.equal(algorithmLessons.length, 15, `animated visual: expected 15 algorithm lessons, found ${algorithmLessons.length}`)
assert.deepEqual(new Set(algorithmLessons.map((item) => item.id)), new Set(expectedAlgorithmIds), 'animated visual: algorithm lesson set changed; update visual coverage intentionally')

const requiredSceneKeys = [
  'scan', 'binary', 'hash', 'dedupe', 'stackqueue', 'batch', 'rank', 'sort', 'pointers', 'sliding', 'prefix', 'topk',
  'bfs', 'topo', 'intervals', 'partition', 'join', 'medallion', 'git',
]
for (const key of requiredSceneKeys) {
  assert(layer.includes(`${key}: [`), `animated visual: missing scene metadata for ${key}`)
}

const algorithmResolverContracts = [
  ["/linear search/.test(text)", "return 'scan'"],
  ["/binary search/.test(text)", "return 'binary'"],
  ["/frequency|hash map|hash lookup|nested-loop lookup/.test(text)", "return 'hash'"],
  ["item.track === 'algorithms' && /deduplic|dedupe/.test(text)", "return 'dedupe'"],
  ["/stack vs queue|stack.*lifo|queue.*fifo/.test(text)", "return 'stackqueue'"],
  ["item.track === 'algorithms' && /batch|chunk/.test(text)", "return 'batch'"],
  ["/two pointer/.test(text)", "return 'pointers'"],
  ["/sliding window/.test(text)", "return 'sliding'"],
  ["/prefix sum/.test(text)", "return 'prefix'"],
  ["/heap|top k|top-k/.test(text)", "return 'topk'"],
  ["/topological/.test(text)", "return 'topo'"],
  ["/\\bbfs\\b|graph traversal/.test(text)", "return 'bfs'"],
  ["/merge overlapping interval|merge interval/.test(text)", "return 'intervals'"],
  ["/sorting|stable sort/.test(text)", "return 'sort'"],
]
for (const [matcher, result] of algorithmResolverContracts) {
  assert(layer.includes(matcher) && layer.includes(result), `animated visual: resolver contract missing ${matcher} → ${result}`)
}

assert(layer.indexOf("return 'rank'") < layer.indexOf("return 'dedupe'"), 'animated visual: SQL rank resolver ordering should remain explicit')
assert(layer.includes("item.track === 'algorithms' && /deduplic|dedupe/"), 'animated visual: algorithm dedupe must not fall into SQL ROW_NUMBER visual')
assert(layer.includes('const ordered =') && layer.includes("step >= 2 ? ordered : raw"), 'animated visual: ROW_NUMBER visual must visibly reorder rows before ranking')
assert(layer.includes("step === 0 ? true : step === 1 ? dateKeep : clusterKeep"), 'animated visual: partition animation must progressively prune partitions then clustered blocks')

assert(layer.includes('ANIMATED CONCEPT'), 'animated visual: practice card label missing')
assert(layer.includes('Pause animation') && layer.includes('Play animation'), 'animated visual: play/pause controls missing')
assert(layer.includes('Previous visual step') && layer.includes('Next visual step') && layer.includes('Reset animation'), 'animated visual: step/reset controls missing')
assert(layer.includes('[0.75, 1, 1.5]'), 'animated visual: speed controls missing')
assert(layer.includes('Go to visual step'), 'animated visual: direct step navigation missing')
assert(layer.includes("prefers-reduced-motion: reduce"), 'animated visual: autoplay must respect reduced-motion preference')
assert(css.includes('@media(prefers-reduced-motion:reduce)'), 'animated visual: CSS motion must be disabled for reduced-motion users')
assert(layer.includes('requestAnimationFrame') && layer.includes('MutationObserver'), 'animated visual: DOM synchronization must be animation-frame coalesced')

assert(layer.includes('BigOCheatSheet') && layer.includes('Time complexity patterns you should recognize instantly'), 'animated visual: Big-O visual cheat sheet missing')
assert(layer.includes('SqlCheatSheet') && layer.includes('What each SQL operation does to rows'), 'animated visual: SQL row-behavior cheat sheet missing')
assert(layer.includes("['WINDOW', 'Keep rows'") && layer.includes("['QUALIFY', 'Filter window result'"), 'animated visual: SQL visual must distinguish window row-preservation from QUALIFY filtering')
assert(layer.includes("['Hash lookup', 'hash'") && layer.includes("['Nested loop', 'nested'") && layer.includes("['Top K heap', 'heap'"), 'animated visual: Big-O cheat sheet must cover constant, quadratic and bounded-heap patterns')

assert(!/mermaid/i.test(layer), 'animated visual: micro-behavior layer must not depend on Mermaid')
assert(main.includes("import AnimatedConceptLayer from './AnimatedConceptLayer'"), 'animated visual: main must import AnimatedConceptLayer')
assert(main.includes('<AnimatedConceptLayer />'), 'animated visual: main must mount AnimatedConceptLayer')
assert(main.includes("import './animatedConcepts.css'") && main.includes("import './animatedConceptExtras.css'"), 'animated visual: main must load both concept style sheets')
assert(css.includes('.vc-rank-row.filtered') && css.includes('.vc-window-brace') && css.includes('.vc-block-grid') && css.includes('.vc-git-track'), 'animated visual: core SQL/window/storage/Git visual styles missing')

for (const source of ['visualgo.net', 'cs.usfca.edu', 'medium.com/learning-sql']) {
  assert(research.includes(source), `animated visual: research note missing ${source}`)
}
assert(research.includes('Do not use Mermaid for micro-behavior'), 'animated visual: visual architecture policy must remain documented')
assert(research.includes('Do not copy article artwork'), 'animated visual: research/adaptation policy must remain explicit')

console.log(`Animated concept validation: ${algorithmLessons.length} classical algorithms · ${requiredSceneKeys.length} interactive scene families · Big-O + SQL visual cheat sheets`)
console.log('Animated visual validation passed: step controls, reduced motion, algorithm coverage, SQL row behavior, partition pruning and Mermaid separation are intact.')
