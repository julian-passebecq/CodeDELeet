import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import '../src/modernLakehouseExtensions.js'
import '../src/airflow3StreamingExtensions.js'
import '../src/dataReliabilityExtensions.js'
import '../src/architectureVisualExtensions.js'
import { lessons } from '../src/curriculum.js'
import { sqlChallenges } from '../src/sqlChallenges.js'
import { engineChallenges } from '../src/engineLab.js'
import { pythonLabChallenges } from '../src/pythonLab.js'

const main = fs.readFileSync(new URL('../src/main.jsx', import.meta.url), 'utf8')
const themeBridge = fs.readFileSync(new URL('../src/EditorThemeBridge.jsx', import.meta.url), 'utf8')
const utilities = fs.readFileSync(new URL('../src/LabUtilities.jsx', import.meta.url), 'utf8')
const readability = fs.readFileSync(new URL('../src/readability.css', import.meta.url), 'utf8')
const variantGuard = fs.readFileSync(new URL('../src/VariantSwitchGuard.jsx', import.meta.url), 'utf8')
const officialLayer = fs.readFileSync(new URL('../src/OfficialSourceLayer.jsx', import.meta.url), 'utf8')
const officialCss = fs.readFileSync(new URL('../src/officialSources.css', import.meta.url), 'utf8')

const collections = [
  ['core', lessons],
  ['sql', sqlChallenges],
  ['engine', engineChallenges],
  ['python', pythonLabChallenges],
]

const titleOwners = new Map()
for (const [collection, items] of collections) {
  for (const item of items) {
    assert.equal(typeof item.title, 'string', `${collection}/${item.id}: title must be text`)
    assert(item.title.trim(), `${collection}/${item.id}: title must not be blank`)
    const title = item.title.trim()
    const owners = titleOwners.get(title) ?? []
    owners.push(`${collection}/${item.id}`)
    titleOwners.set(title, owners)
  }
}

const ambiguousTitles = [...titleOwners.entries()].filter(([, owners]) => owners.length > 1)
assert.equal(
  ambiguousTitles.length,
  0,
  `UI bridge title lookup is ambiguous: ${ambiguousTitles.map(([title, owners]) => `${title} => ${owners.join(', ')}`).join(' | ')}`,
)
assert.equal(titleOwners.size, 323, `UI bridge should see 323 unique practice titles in v2.12, found ${titleOwners.size}`)

assert(main.includes("import './readability.css'"), 'UI contract: readability overrides must load')
assert(main.indexOf("import './readability.css'") > main.indexOf("import './organization.css'"), 'UI contract: readability overrides should load after feature styles')
assert(main.includes('OfficialSourceLayer') && main.includes("import './officialSources.css'"), 'UI contract: official documentation layer and styles must load')
assert(officialLayer.includes('officialSources') && officialLayer.includes('target="_blank"') && officialLayer.includes('requestAnimationFrame'), 'UI contract: official docs must render safely and coalesce DOM sync')
assert(officialCss.includes('.official-source-row') && officialCss.includes(':focus-visible'), 'UI contract: official source links need visible styling and keyboard focus')

for (const theme of ['de-gray', 'de-black', 'de-light']) {
  assert(themeBridge.includes(`defineTheme('${theme}'`), `UI contract: missing Monaco theme ${theme}`)
}
assert(themeBridge.includes('requestAnimationFrame') && themeBridge.includes('settleTimer'), 'UI contract: Monaco theme should be re-applied after React/Monaco settles')
assert(themeBridge.includes("window.addEventListener('de-editor-appearance'"), 'UI contract: theme bridge must react to appearance changes')

assert(utilities.includes("restoreProgressBackup(localStorage, await file.text(), { replace: true })"), 'UI contract: user-facing Restore must replace stale trainer state')
assert(utilities.includes('Restore replaces the trainer'), 'UI contract: Restore semantics should be explained in Lab tools')

assert(readability.includes('.hub-interview-grid') && readability.includes('.reference-content'), 'UI contract: readability pass must cover interview and reference study content')
assert(readability.includes('font-size: 10px') || readability.includes('font-size: 10.5px'), 'UI contract: study prose should not remain at 7–8px')

assert(variantGuard.includes('scheduleRepair') && variantGuard.includes('variant-select'), 'UI contract: variant blank-editor repair must remain wired')

console.log(`UI contract: ${titleOwners.size} unique practice titles across ${collections.reduce((sum, [, items]) => sum + items.length, 0)} practice items`)
console.log('UI contract validation passed: title routing, official sources, themes, restore semantics, readability and variant guard are consistent.')
