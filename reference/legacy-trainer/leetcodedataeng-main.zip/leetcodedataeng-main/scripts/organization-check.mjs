import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import '../src/modernLakehouseExtensions.js'
import '../src/airflow3StreamingExtensions.js'
import '../src/dataReliabilityExtensions.js'
import '../src/architectureVisualExtensions.js'
import { lessons, tracks } from '../src/curriculum.js'
import { cheatSheets } from '../src/cheatSheets.js'
import { extraHubs } from '../src/learningHubContent.js'
import {
  CORE_TRACK_IDS,
  SUPPORTING_TRACK_IDS,
  OPTIONAL_TRACK_IDS,
  tierForTrack,
} from '../src/curriculumTiers.js'

const main = fs.readFileSync(new URL('../src/main.jsx', import.meta.url), 'utf8')
const front = fs.readFileSync(new URL('../src/FrontPageGuide.jsx', import.meta.url), 'utf8')
const organization = fs.readFileSync(new URL('../src/OrganizationLayer.jsx', import.meta.url), 'utf8')
const organizationCss = fs.readFileSync(new URL('../src/organization.css', import.meta.url), 'utf8')
const referenceCss = fs.readFileSync(new URL('../src/referenceLayer.css', import.meta.url), 'utf8')
const packageJson = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'))

const unique = (values) => new Set(values).size === values.length

assert(unique(tracks.map((track) => track.id)), 'organization: track IDs must be unique')
assert(unique(tracks.map((track) => track.short)), 'organization: track short labels must be unique')
assert(unique(lessons.map((lesson) => lesson.id)), 'organization: core lesson IDs must be unique after all extensions')

const trackIds = new Set(tracks.map((track) => track.id))
for (const lesson of lessons) {
  assert(trackIds.has(lesson.track), `organization: lesson ${lesson.id} points to missing track ${lesson.track}`)
}

const lessonCounts = new Map(tracks.map((track) => [track.id, 0]))
for (const lesson of lessons) lessonCounts.set(lesson.track, (lessonCounts.get(lesson.track) ?? 0) + 1)
for (const track of tracks) {
  assert((lessonCounts.get(track.id) ?? 0) > 0, `organization: track ${track.id} has no exercises`)
}

const requiredCore = [
  'foundations', 'algorithms', 'python', 'sql', 'storage-performance', 'pyspark',
  'pipeline-troubleshooting', 'analytics-engineering', 'seniority',
]
for (const id of requiredCore) {
  assert(trackIds.has(id), `organization: missing core path track ${id}`)
  assert(CORE_TRACK_IDS.has(id), `organization: ${id} exists but is not classified as core`)
}

const tierMembership = [CORE_TRACK_IDS, SUPPORTING_TRACK_IDS, OPTIONAL_TRACK_IDS]
for (const track of tracks) {
  const memberships = tierMembership.filter((set) => set.has(track.id)).length
  assert(memberships === 1, `organization: track ${track.id} must belong to exactly one explicit tier, found ${memberships}`)
  const expectedTier = CORE_TRACK_IDS.has(track.id) ? 'core' : OPTIONAL_TRACK_IDS.has(track.id) ? 'optional' : 'supporting'
  assert(tierForTrack(track) === expectedTier, `organization: tier resolver disagrees for ${track.id}`)
}

for (const id of ['airflow', 'git', 'cloud']) {
  assert(SUPPORTING_TRACK_IDS.has(id) && !CORE_TRACK_IDS.has(id), `organization: ${id} should be supporting, not part of Core progress`)
}

for (const id of ['docker', 'kubernetes', 'mlops-practical', 'nosql-optional', 'genai-optional']) {
  const track = tracks.find((item) => item.id === id)
  assert(Boolean(track), `organization: optional breadth missing ${id}`)
  assert(OPTIONAL_TRACK_IDS.has(id), `organization: ${id} must be in the shared optional tier`)
  assert(track?.short.includes('Optional') || track?.name.startsWith('Optional —'), `organization: ${id} should remain visibly optional`)
}

assert(main.includes("import OrganizationLayer from './OrganizationLayer'"), 'organization: main must mount OrganizationLayer')
assert(main.includes('<OrganizationLayer />'), 'organization: OrganizationLayer must render')
assert(main.includes("import './organization.css'"), 'organization: organization styles must load')

const extensionImports = [
  './algorithmExtensions', './analyticsEngineeringExtensions', './seniorityExtensions', './sourceCourseExtensions',
  './storagePerformanceExtensions', './pipelineTroubleshootingExtensions', './airflowTroubleshootingExtensions',
  './modernLakehouseExtensions', './airflow3StreamingExtensions', './dataReliabilityExtensions', './architectureVisualExtensions',
]
const appImportIndex = main.indexOf("import App from './App'")
assert(appImportIndex > 0, 'organization: App import missing')
for (const extension of extensionImports) {
  const index = main.indexOf(`import '${extension}'`)
  assert(index >= 0 && index < appImportIndex, `organization: ${extension} must load before App`)
}

assert(organization.includes("from './curriculumTiers'"), 'organization: grouped curriculum must use the shared tier source of truth')
assert(front.includes('CORE_TRACK_IDS') && front.includes("from './curriculumTiers'"), 'organization: Home Core progress must use the shared tier source of truth')
assert(!front.includes('const CORE_TRACKS = new Set'), 'organization: Home must not maintain a duplicate Core track list')
assert(organization.includes('TIER_META') && organization.includes('organized-full-curriculum'), 'organization: full curriculum must render the shared three-tier model')
assert(organization.includes('organization-home-duplicate'), 'organization: redundant Dashboard entry must be marked for hiding while brand remains Home')
assert(organizationCss.includes('.organization-home-duplicate') && organizationCss.includes('display: none !important'), 'organization: redundant Dashboard entry must actually be hidden')
assert(organization.includes('full-curriculum-grid'), 'organization: Home full curriculum must replace the legacy raw grid')
assert(referenceCss.includes('.reference-layer-ready .sidebar > .track-nav'), 'organization: sidebar should remain reference-first rather than reintroducing the raw curriculum list')

const trackTargets = [...front.matchAll(/openCoreTrack\('([^']+)'\)/g)].map((match) => match[1])
for (const target of trackTargets) {
  assert(tracks.some((track) => track.short === target), `organization: home target "${target}" does not match a track short label`)
}

const hubTargets = [...front.matchAll(/openLearningHub\('([^']+)'\)/g)].map((match) => match[1])
const hubLabels = new Set([...cheatSheets, ...extraHubs].map((hub) => hub.label))
const intentionalHubAliases = new Map([
  ['Storage & Performance', 'storage-performance'],
  ['Pipeline Troubleshooting', 'pipeline-troubleshooting'],
])
for (const target of hubTargets) {
  const labelMatch = [...hubLabels].some((label) => label.includes(target) || target.includes(label))
  const aliasId = intentionalHubAliases.get(target)
  const aliasMatch = aliasId ? extraHubs.some((hub) => hub.id === aliasId) : false
  assert(labelMatch || aliasMatch, `organization: home learning-hub target "${target}" has no matching hub or intentional alias`)
}

const coreLessonCount = lessons.filter((lesson) => CORE_TRACK_IDS.has(lesson.track)).length
const supportingLessonCount = lessons.filter((lesson) => SUPPORTING_TRACK_IDS.has(lesson.track)).length
const optionalLessonCount = lessons.filter((lesson) => OPTIONAL_TRACK_IDS.has(lesson.track)).length
assert(coreLessonCount + supportingLessonCount + optionalLessonCount === lessons.length, 'organization: tier lesson totals must cover the complete curriculum')
assert.equal(coreLessonCount, 145, `organization: expected 145 Core drills in v2.12, found ${coreLessonCount}`)
assert.equal(supportingLessonCount, 38, `organization: expected 38 Supporting drills in v2.12, found ${supportingLessonCount}`)
assert.equal(optionalLessonCount, 28, `organization: expected 28 Optional drills in v2.12, found ${optionalLessonCount}`)

assert(packageJson.version.startsWith('2.12.'), 'organization: package version should be v2.12.x for this audit pass')

console.log(`Organization audit: ${tracks.length} tracks · ${lessons.length} curriculum lessons`)
console.log(`Tier totals: core=${coreLessonCount} · supporting=${supportingLessonCount} · optional=${optionalLessonCount}`)
console.log(`Navigation targets checked: ${trackTargets.length} track links · ${hubTargets.length} hub links`)
console.log('Organization audit passed: hierarchy, shared progress math, navigation targets and extension wiring are consistent.')
