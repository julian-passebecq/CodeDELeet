import assert from 'node:assert/strict'
import {
  BACKUP_FORMAT,
  BACKUP_VERSION,
  STORAGE_PREFIX,
  collectProgressBackup,
  restoreProgressBackup,
  validateProgressBackup,
} from '../src/progressBackup.js'

class FakeStorage {
  constructor(entries = {}) {
    this.map = new Map(Object.entries(entries))
    this.failOnceFor = null
  }

  get length() { return this.map.size }
  key(index) { return [...this.map.keys()][index] ?? null }
  getItem(key) { return this.map.has(key) ? this.map.get(key) : null }
  setItem(key, value) {
    if (this.failOnceFor === key) {
      this.failOnceFor = null
      throw new Error(`simulated storage failure for ${key}`)
    }
    this.map.set(key, String(value))
  }
  removeItem(key) { this.map.delete(key) }
}

const appKey = (name) => `${STORAGE_PREFIX}:${name}`
const backup = {
  format: BACKUP_FORMAT,
  version: BACKUP_VERSION,
  exportedAt: '2026-09-03T00:00:00.000Z',
  entries: {
    [appKey('drafts')]: JSON.stringify({ 'sql-example': 'SELECT 1;' }),
    [appKey('flags')]: JSON.stringify(['sql-example']),
  },
}

assert.equal(validateProgressBackup(backup), backup, 'valid backup should be accepted')

const exact = new FakeStorage({
  [appKey('drafts')]: JSON.stringify({ stale: 'old code' }),
  [appKey('mastered')]: JSON.stringify(['stale-id']),
  'unrelated-app:key': 'keep me',
})
assert.equal(restoreProgressBackup(exact, backup, { replace: true }), 2, 'exact restore should report restored entry count')
assert.equal(exact.getItem(appKey('drafts')), backup.entries[appKey('drafts')], 'exact restore should replace drafts')
assert.equal(exact.getItem(appKey('flags')), backup.entries[appKey('flags')], 'exact restore should restore backup flags')
assert.equal(exact.getItem(appKey('mastered')), null, 'exact restore should remove stale trainer keys absent from backup')
assert.equal(exact.getItem('unrelated-app:key'), 'keep me', 'exact restore must not remove unrelated localStorage')

const merged = new FakeStorage({ [appKey('mastered')]: JSON.stringify(['keep']) })
restoreProgressBackup(merged, backup)
assert.equal(merged.getItem(appKey('mastered')), JSON.stringify(['keep']), 'default merge restore should remain available for programmatic callers')

const exported = collectProgressBackup(exact, '2026-09-03T00:00:00.000Z')
assert.deepEqual(Object.keys(exported.entries).sort(), [appKey('drafts'), appKey('flags')].sort(), 'backup export should contain only trainer keys')

const invalidTarget = new FakeStorage({ [appKey('flags')]: JSON.stringify(['before']) })
assert.throws(() => restoreProgressBackup(invalidTarget, { ...backup, format: 'wrong' }, { replace: true }), /not a Coding Reset backup/i)
assert.equal(invalidTarget.getItem(appKey('flags')), JSON.stringify(['before']), 'invalid backup must not modify existing storage')

const rollback = new FakeStorage({
  [appKey('drafts')]: JSON.stringify({ before: 'safe' }),
  [appKey('mastered')]: JSON.stringify(['before-id']),
  'unrelated-app:key': 'still safe',
})
rollback.failOnceFor = appKey('flags')
assert.throws(() => restoreProgressBackup(rollback, backup, { replace: true }), /simulated storage failure/i)
assert.equal(rollback.getItem(appKey('drafts')), JSON.stringify({ before: 'safe' }), 'failed restore should roll drafts back')
assert.equal(rollback.getItem(appKey('mastered')), JSON.stringify(['before-id']), 'failed restore should roll mastery back')
assert.equal(rollback.getItem(appKey('flags')), null, 'failed restore should not leave partially restored keys')
assert.equal(rollback.getItem('unrelated-app:key'), 'still safe', 'rollback must preserve unrelated storage')

console.log('Backup validation passed: exact restore, merge mode, unrelated-key preservation and rollback are safe.')
