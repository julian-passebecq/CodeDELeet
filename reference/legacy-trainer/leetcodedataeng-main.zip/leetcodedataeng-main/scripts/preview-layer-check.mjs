import assert from 'node:assert/strict'
import fs from 'node:fs'

const course = fs.readFileSync(new URL('../src/CourseSourcePreviews.jsx', import.meta.url), 'utf8')
const original = fs.readFileSync(new URL('../src/OriginalSourcePreviews.jsx', import.meta.url), 'utf8')
const css = fs.readFileSync(new URL('../src/originalSourcePreview.css', import.meta.url), 'utf8')

assert(course.includes("pane.classList.toggle('course-source-preview-active'"), 'course source preview must mark the active code pane')
assert(css.includes('.course-source-preview-active') && css.includes(':not(.original-source-preview)'), 'course source data must replace the generic illustrative preview')
assert(css.includes('.original-source-preview-active'), 'original notebook preview replacement must remain')

for (const source of [course, original]) {
  assert(source.includes('requestAnimationFrame'), 'source preview DOM synchronization should be animation-frame coalesced')
  assert(source.includes('cancelAnimationFrame'), 'source preview synchronization must cancel pending work on unmount')
}

assert(original.includes("document.addEventListener('change', scheduleSync, true)"), 'original source preview must resync when dialect/engine changes')
assert(css.includes('font-size: 9px') && css.includes('font-size: 10px'), 'source preview tables/metadata should remain readable')

console.log('Source preview validation passed: source-derived data replaces fallback previews, remains readable, and DOM sync is coalesced.')
