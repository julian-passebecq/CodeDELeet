import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import '../src/modernLakehouseExtensions.js'
import '../src/airflow3StreamingExtensions.js'
import '../src/dataReliabilityExtensions.js'
import { architectureVisualDiagrams } from '../src/architectureVisualExtensions.js'
import { lessons } from '../src/curriculum.js'

const visualLayer = fs.readFileSync(new URL('../src/TechnologyVisualLayer.jsx', import.meta.url), 'utf8')
const visualRegistry = fs.readFileSync(new URL('../src/technologyVisualRegistry.js', import.meta.url), 'utf8')
const technologyMark = fs.readFileSync(new URL('../src/TechnologyMark.jsx', import.meta.url), 'utf8')
const visualCss = fs.readFileSync(new URL('../src/technologyVisuals.css', import.meta.url), 'utf8')
const diagramLayer = fs.readFileSync(new URL('../src/PracticeDiagramLayer.jsx', import.meta.url), 'utf8')
const officialLayer = fs.readFileSync(new URL('../src/OfficialSourceLayer.jsx', import.meta.url), 'utf8')
const frontPage = fs.readFileSync(new URL('../src/FrontPageGuide.jsx', import.meta.url), 'utf8')
const main = fs.readFileSync(new URL('../src/main.jsx', import.meta.url), 'utf8')

assert(main.includes("import './architectureVisualExtensions'"), 'visual: architecture overrides must load before App')
assert(main.indexOf("import './architectureVisualExtensions'") < main.indexOf("import App from './App'"), 'visual: architecture overrides must mutate lessons before App')
assert(main.includes("import TechnologyVisualLayer from './TechnologyVisualLayer'"), 'visual: TechnologyVisualLayer import missing')
assert(main.includes('<TechnologyVisualLayer />'), 'visual: TechnologyVisualLayer must render')
assert(main.includes("import './technologyVisuals.css'"), 'visual: technology visual styles must load')

assert(visualRegistry.includes('pythondotorg-assets') && visualRegistry.includes('python-logo-only.svg'), 'visual: Python must use the official PSF asset')
assert(visualRegistry.includes("src: '/icons/microsoft/fabric.svg'"), 'visual: Microsoft Fabric should use a local official icon asset')
assert(visualRegistry.includes("src: '/icons/microsoft/power-bi.svg'"), 'visual: Power BI should use the current Fabric icon-set asset')
assert(visualRegistry.includes("src: '/icons/microsoft/lakehouse.svg'"), 'visual: Fabric Lakehouse icon asset missing')
assert(fs.existsSync(new URL('../public/icons/microsoft/fabric.svg', import.meta.url)), 'visual: Fabric SVG must ship with the site')
assert(fs.existsSync(new URL('../public/icons/microsoft/power-bi.svg', import.meta.url)), 'visual: Power BI SVG must ship with the site')
assert(fs.existsSync(new URL('../public/icons/microsoft/lakehouse.svg', import.meta.url)), 'visual: Lakehouse SVG must ship with the site')
assert(visualLayer.includes('not affiliated with the PSF') && visualLayer.includes('Microsoft Fabric and Power BI icons'), 'visual: trademark/non-affiliation notice must remain visible')
assert(!visualLayer.includes('microsoft/PowerBI-Icons'), 'visual: archived PowerBI-Icons hotlink should no longer be used')

assert(!/duckdb\.org\/.*\.(svg|png)/i.test(visualRegistry), 'visual: DuckDB logo must not be embedded in UI without approval')
assert(!/getdbt\.com\/.*\.(svg|png)|dbt.*logo/i.test(visualRegistry), 'visual: dbt logo marks must not be embedded in the UI')
assert(!/pandas.*\.(svg|png)/i.test(visualRegistry), 'visual: pandas navigation should use a neutral table pictogram')
assert(visualRegistry.includes("kind: 'duckdb'") && visualRegistry.includes("glyph: 'database'"), 'visual: DuckDB must have a neutral database pictogram')
assert(visualRegistry.includes("kind: 'dbt'") && visualRegistry.includes("glyph: 'layers'"), 'visual: dbt must have a neutral transformation pictogram')
assert(visualRegistry.includes("kind: 'airflow'") && visualRegistry.includes("glyph: 'workflow'"), 'visual: Airflow must have a neutral DAG pictogram')
assert(visualRegistry.includes("kind: 'spark'") && visualRegistry.includes("glyph: 'spark'"), 'visual: Spark must have a neutral execution pictogram')
assert(visualRegistry.includes("kind: 'dataframe'") && visualRegistry.includes("glyph: 'table'"), 'visual: pandas/Polars must have a neutral table pictogram')
assert(visualRegistry.includes("kind: 'lineage'") && visualRegistry.includes("glyph: 'network'"), 'visual: CDC/lineage must have a neutral topology pictogram')
assert(visualLayer.includes("host?.querySelector('strong')") && visualLayer.includes("host.querySelector('small')"), 'visual: icon resolution must use primary UI labels rather than scanning full descriptions')
assert(visualLayer.includes('requestAnimationFrame') && visualLayer.includes('MutationObserver'), 'visual: DOM decoration must remain animation-frame coalesced')
assert(technologyMark.includes('onError={() => setFailed(true)}') && technologyMark.includes('fallbackGlyphFor'), 'visual: reusable marks need image-failure fallback')
assert(frontPage.includes('TechnologyMark') && frontPage.includes('focus-card-icon'), 'visual: Home focus cards must show technology marks')
assert(officialLayer.includes('TechnologyMark') && officialLayer.includes('official-source-icon'), 'visual: official docs links must show source-aware marks')
assert(visualCss.includes('.technology-mark') && visualCss.includes('.official-source-icon') && visualCss.includes('.practice-diagram-topic-icon'), 'visual: reusable mark styles must cover cards, sources and diagrams')

assert(diagramLayer.includes('mermaid@11.17.2'), 'diagram: Mermaid must stay pinned to the reviewed 11.17.2 release')
assert(diagramLayer.includes("securityLevel: 'strict'"), 'diagram: strict Mermaid security must remain enabled')
assert(diagramLayer.includes('seed: 1') && diagramLayer.includes('randomize: false'), 'diagram: architecture layout must be deterministic')
assert(diagramLayer.includes('nodeSeparation: 70') && diagramLayer.includes('idealEdgeLengthMultiplier: 1.6'), 'diagram: architecture spacing configuration missing')
assert(diagramLayer.includes("architecture ? 'ARCHITECTURE' : 'FLOW'"), 'diagram: UI should distinguish architecture diagrams from process flows')
assert(diagramLayer.includes('role="img"') && diagramLayer.includes('aria-label'), 'diagram: rendered diagrams need an accessible image label')
assert(diagramLayer.includes('practice-diagram-fallback') && diagramLayer.includes('{source}'), 'diagram: Mermaid source fallback must remain available')
assert(diagramLayer.includes('TechnologyMark') && diagramLayer.includes('practice-diagram-topic-icon'), 'diagram: diagram header should carry a technology visual')
assert(diagramLayer.includes('requestAnimationFrame') && diagramLayer.includes('MutationObserver'), 'diagram: DOM sync must be animation-frame coalesced')

const expectedArchitectureIds = [
  'cdc-log-vs-polling',
  'cdc-envelope-upsert-delete',
  'fabric-mirroring-vs-etl',
  'fabric-mirroring-troubleshoot',
  'modern-format-table-engine-catalog',
  'lineage-impact-debugging',
  'ae-dbt-revenue-mart',
  'ae-spark-delta-merge',
]
assert.equal(Object.keys(architectureVisualDiagrams).length, expectedArchitectureIds.length, 'diagram: unexpected architecture override count')
for (const id of expectedArchitectureIds) {
  const lesson = lessons.find((item) => item.id === id)
  assert(lesson, `diagram: missing lesson ${id}`)
  assert(/^\s*architecture-beta\b/.test(lesson.diagram ?? ''), `diagram: ${id} should use architecture-beta`)
}

const allowedArchitectureIcons = new Set(['cloud', 'database', 'disk', 'internet', 'server'])
for (const [id, source] of Object.entries(architectureVisualDiagrams)) {
  const icons = [...source.matchAll(/\b(?:service|group)\s+\w+\(([^)]+)\)/g)].map((match) => match[1])
  assert(icons.length > 0, `diagram: ${id} should declare visual service icons`)
  for (const icon of icons) assert(allowedArchitectureIcons.has(icon), `diagram: ${id} uses unregistered icon ${icon}`)
  assert(source.includes('-->'), `diagram: ${id} should make data/control direction explicit`)
}

console.log(`Visual architecture validation: ${expectedArchitectureIds.length} architecture diagrams · current Microsoft Fabric/Power BI assets + official Python mark + neutral restricted-vendor pictograms`)
console.log('Visual architecture validation passed: current icon policy, source-aware marks, deterministic Mermaid architecture rendering, accessibility and fallbacks are intact.')
