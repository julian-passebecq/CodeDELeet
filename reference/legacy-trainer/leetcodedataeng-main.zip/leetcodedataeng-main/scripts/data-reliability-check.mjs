import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import '../src/modernLakehouseExtensions.js'
import '../src/airflow3StreamingExtensions.js'
import { dataReliabilityLessons } from '../src/dataReliabilityExtensions.js'
import { lessons } from '../src/curriculum.js'
import { cheatSheets } from '../src/cheatSheets.js'
import { extraHubs, hubExtensions } from '../src/learningHubContent.js'

const requiredIds = [
  'cdc-log-vs-polling',
  'cdc-envelope-upsert-delete',
  'cdc-offset-recovery',
  'dbt-model-contract-enforced',
  'dbt-contract-vs-test',
  'lineage-run-event-model',
  'lineage-impact-debugging',
  'fabric-mirroring-vs-etl',
  'fabric-mirroring-troubleshoot',
]

assert.equal(dataReliabilityLessons.length, 9, `expected 9 data-reliability drills, found ${dataReliabilityLessons.length}`)
for (const id of requiredIds) assert(dataReliabilityLessons.some((item) => item.id === id), `missing ${id}`)

const coreTracks = new Set(['pipeline-troubleshooting', 'analytics-engineering', 'storage-performance'])
assert.equal(dataReliabilityLessons.filter((item) => coreTracks.has(item.track)).length, 7, 'expected 7 Core reliability drills')
assert.equal(dataReliabilityLessons.filter((item) => item.track === 'airflow').length, 2, 'expected 2 Supporting lineage/Airflow drills')

const envelope = lessons.find((item) => item.id === 'cdc-envelope-upsert-delete')
assert(envelope?.solution.includes("{'c', 'u', 'r'}") && envelope?.solution.includes("op == 'd'"), 'CDC envelope exercise must preserve upsert and delete semantics')
assert(envelope?.solution.includes("event['after']") && /before|key/.test(envelope?.solution ?? ''), 'CDC envelope must distinguish after-state from delete identity')

const recovery = lessons.find((item) => item.id === 'cdc-offset-recovery')
assert(/offset|source position/i.test(recovery?.solution ?? ''), 'CDC recovery must reason about connector/source offsets')
assert(/retention|history/i.test(recovery?.solution ?? ''), 'CDC recovery must reason about source-log retention/history')
assert(/snapshot|bootstrap/i.test(recovery?.solution ?? ''), 'CDC recovery must include controlled re-snapshot/re-bootstrap when offsets are invalid')

const contract = lessons.find((item) => item.id === 'dbt-model-contract-enforced')
assert(contract?.solution.includes('enforced: true'), 'dbt contract drill must enable enforcement')
assert(contract?.solution.includes('data_type:'), 'dbt contract drill must declare column data types')

const contractVsTest = lessons.find((item) => item.id === 'dbt-contract-vs-test')
assert(/shape/i.test(contractVsTest?.concept ?? '') && /content/i.test(contractVsTest?.concept ?? ''), 'dbt contract-vs-test drill must distinguish shape from content')

const dbtHub = extraHubs.find((item) => item.id === 'dbt')
assert(dbtHub, 'dbt hub missing')
assert(!dbtHub.mentalModels.some((text) => text.includes('Tests are executable data contracts')), 'dbt hub must not call all tests executable data contracts')
assert(dbtHub.mentalModels.some((text) => text.includes('model contracts')), 'dbt hub must explain model contracts separately')
assert(dbtHub.sections.some(([title]) => title === 'Model contract'), 'dbt hub must include a model-contract reference snippet')

const lineage = lessons.find((item) => item.id === 'lineage-run-event-model')
assert(/JOB =/.test(lineage?.solution ?? '') && /RUN =/.test(lineage?.solution ?? '') && /DATASET/.test(lineage?.solution ?? ''), 'lineage exercise must distinguish Job, Run and Dataset')
assert(/FAIL/.test(lineage?.solution ?? ''), 'lineage exercise must include runtime failure state')

const airflow = cheatSheets.find((item) => item.id === 'airflow')
assert(airflow?.sections.some(([title]) => title === 'OpenLineage'), 'Airflow reference must include OpenLineage')
assert(airflow?.interview.includes('OpenLineage / data lineage'), 'Airflow interview checklist must include lineage')

const mirror = lessons.find((item) => item.id === 'fabric-mirroring-vs-etl')
assert(/replication/i.test(mirror?.solution ?? '') && /transformation/i.test(mirror?.solution ?? ''), 'Fabric Mirroring exercise must separate replication from downstream transformation')
assert(/Delta Parquet/i.test(mirror?.solution ?? ''), 'Fabric Mirroring exercise must mention OneLake Delta Parquet representation')

const mirrorTroubleshoot = lessons.find((item) => item.id === 'fabric-mirroring-troubleshoot')
for (const token of ['MIRROR STATUS', 'ONELAKE', 'SQL ENDPOINT']) {
  assert(mirrorTroubleshoot?.solution.includes(token), `mirroring troubleshooting must check ${token}`)
}

const deCards = hubExtensions['de-interview']?.interviewCards ?? []
for (const title of ['CDC vs polling', 'Contract vs data test', 'Operational lineage']) {
  assert(deCards.some(([cardTitle]) => cardTitle === title), `DE interview hub missing ${title}`)
}

const allowedHosts = new Set(['debezium.io', 'docs.getdbt.com', 'openlineage.io', 'learn.microsoft.com'])
let officialCount = 0
for (const lesson of dataReliabilityLessons) {
  assert(Array.isArray(lesson.officialSources) && lesson.officialSources.length > 0, `${lesson.id}: missing official sources`)
  for (const source of lesson.officialSources) {
    const parsed = new URL(source.url)
    assert.equal(parsed.protocol, 'https:', `${lesson.id}: official source must use HTTPS`)
    assert(allowedHosts.has(parsed.hostname), `${lesson.id}: unexpected official source host ${parsed.hostname}`)
    officialCount += 1
  }
}
assert(officialCount >= 15, `expected at least 15 first-party references, found ${officialCount}`)

const main = fs.readFileSync(new URL('../src/main.jsx', import.meta.url), 'utf8')
assert(main.includes("import './dataReliabilityExtensions'"), 'main must load data reliability extensions')
assert(main.indexOf("import './dataReliabilityExtensions'") < main.indexOf("import App from './App'"), 'data reliability extensions must load before App')

console.log(`Data reliability validation: ${dataReliabilityLessons.length} drills · ${officialCount} first-party references`)
console.log('Data reliability validation passed: CDC recovery, dbt contracts, operational lineage and Fabric Mirroring diagnostics are current and distinct.')
