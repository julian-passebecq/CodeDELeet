import fs from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import { storageLessons } from '../src/storagePerformanceExtensions.js'
import { lessons, tracks } from '../src/curriculum.js'
import { extraHubs, hubExtensions } from '../src/learningHubContent.js'

const failures = []
const assert = (condition, message) => { if (!condition) failures.push(message) }
const nonEmpty = (value) => typeof value === 'string' && value.trim().length > 0

const track = tracks.find((item) => item.id === 'storage-performance')
assert(Boolean(track), 'storage: missing storage-performance core track')
assert(storageLessons.length >= 14, `storage: expected at least 14 drills, found ${storageLessons.length}`)

const requiredIds = [
  'sp-layers', 'sp-python-parquet', 'sp-pyarrow-filter', 'sp-spark-parquet', 'sp-duckdb-parquet',
  'sp-json-normalize', 'sp-avro-spark', 'sp-delta-read-write', 'sp-partition-design', 'sp-clustering',
  'sp-sql-index', 'sp-small-files', 'sp-pruning-pushdown', 'sp-compression',
]
for (const id of requiredIds) assert(storageLessons.some((item) => item.id === id), `storage: missing ${id}`)

for (const item of storageLessons) {
  assert(nonEmpty(item.title), `storage/${item.id}: missing title`)
  assert(nonEmpty(item.concept), `storage/${item.id}: missing concept`)
  assert(nonEmpty(item.task), `storage/${item.id}: missing task`)
  assert(nonEmpty(item.starter), `storage/${item.id}: missing starter`)
  assert(nonEmpty(item.solution), `storage/${item.id}: missing solution`)
  assert(Array.isArray(item.hints) && item.hints.length > 0, `storage/${item.id}: missing hints`)
  assert(nonEmpty(item.pitfall), `storage/${item.id}: missing pitfall`)
}

const ids = lessons.map((item) => item.id)
assert(new Set(ids).size === ids.length, 'storage integration introduced duplicate lesson IDs')
assert(lessons.filter((item) => item.track === 'storage-performance').length === storageLessons.length, 'storage track count differs from exported storage lessons')

const hub = extraHubs.find((item) => item.id === 'storage-performance')
assert(Boolean(hub), 'storage: missing learning hub')
assert(hub?.sections?.length >= 8, 'storage hub should contain a substantial cheat sheet')
assert(hub?.mentalModels?.length >= 4, 'storage hub should contain storage mental models')
assert(hub?.interview?.length >= 7, 'storage hub should contain interview checklist topics')

const ext = hubExtensions['storage-performance']
assert(ext?.algorithms?.length >= 8, 'storage hub should contain performance patterns')
assert(ext?.problems?.length >= 8, 'storage hub should contain typical storage problems')
assert(ext?.interviewCards?.length >= 8, 'storage hub should contain structured interview cards')

const layers = storageLessons.find((item) => item.id === 'sp-layers')
assert(/Parquet.*Avro.*JSON/s.test(layers?.solution ?? ''), 'storage layers exercise should cover requested file formats')
assert(/Delta Lake.*TABLE FORMAT/s.test(layers?.solution ?? '') || /TABLE FORMAT[\s\S]*Delta Lake/.test(layers?.solution ?? ''), 'storage layers exercise should identify Delta Lake as a table layer')
assert(/DuckDB.*QUERY ENGINE/s.test(layers?.solution ?? '') || /QUERY ENGINE[\s\S]*DuckDB/.test(layers?.solution ?? ''), 'storage layers exercise should identify DuckDB as an engine')

assert(storageLessons.some((item) => item.id === 'sp-python-parquet' && item.solution.includes('pd.read_parquet')), 'storage: missing pandas Parquet read example')
assert(storageLessons.some((item) => item.id === 'sp-spark-parquet' && item.solution.includes('spark.read') && item.solution.includes('.parquet')), 'storage: missing PySpark Parquet read example')
assert(storageLessons.some((item) => item.id === 'sp-duckdb-parquet' && item.solution.includes('read_parquet')), 'storage: missing DuckDB Parquet query example')
assert(storageLessons.some((item) => item.id === 'sp-sql-index' && item.solution.includes('CREATE INDEX')), 'storage: missing SQL index example')
assert(storageLessons.some((item) => item.id === 'sp-partition-design'), 'storage: missing partitioning design exercise')
assert(storageLessons.some((item) => item.id === 'sp-clustering'), 'storage: missing clustering exercise')
assert(storageLessons.filter((item) => nonEmpty(item.diagram)).length >= 3, 'storage: diagrams should explain format/table and physical-layout concepts')

const root = process.cwd()
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8')
const main = read('src/main.jsx')
const frontPage = read('src/FrontPageGuide.jsx')
const bridge = read('src/StorageHubBridge.jsx')

assert(main.includes("'./storagePerformanceExtensions'"), 'main must load storage performance extensions before render')
assert(main.includes('StorageHubBridge'), 'main must mount StorageHubBridge')
assert(frontPage.includes("'storage-performance'"), 'storage performance must count toward Core DE progress')
assert(frontPage.includes('Storage · Formats · Performance'), 'home page must expose storage focus card')
assert(frontPage.includes("['05', 'Storage', 'Storage / Perf']"), 'recommended path must include storage before PySpark/analytics engineering')
assert(bridge.includes("detail: HUB_ID"), 'storage hub nav must use learning-hub event routing')
assert(bridge.includes('dataStorageFilled') || bridge.includes('storageFilled'), 'storage hub source tab should be populated with storage drills')
assert(bridge.includes("crumb.textContent !== 'Storage / Perf'"), 'storage breadcrumb bridge should avoid mutation loops')

const deCards = hubExtensions['de-interview']?.interviewCards ?? []
assert(deCards.some((card) => card[0] === 'Partition vs cluster vs index'), 'DE interview hub should include physical-layout interview question')
assert(deCards.some((card) => card[0] === 'Small-file problem'), 'DE interview hub should include small-file production question')

console.log(`Storage & performance: ${storageLessons.length} core drills`)
console.log(`Storage interview cards: ${ext?.interviewCards?.length ?? 0}`)
console.log(`Total core lessons after storage integration: ${lessons.length}`)

if (failures.length) {
  console.error(`Storage validation failed with ${failures.length} issue(s):`)
  for (const failure of failures) console.error(`- ${failure}`)
  process.exit(1)
}

console.log('Storage validation passed: formats, Python/PySpark I/O, Delta/DuckDB, partitioning, clustering, indexes and performance design.')
