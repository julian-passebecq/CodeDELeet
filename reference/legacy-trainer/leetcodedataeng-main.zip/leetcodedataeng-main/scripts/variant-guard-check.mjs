import assert from 'node:assert/strict'
import fs from 'node:fs'
import { shouldRestoreVariantStarter } from '../src/variantDraftPolicy.js'

assert.equal(shouldRestoreVariantStarter({ editorText: '', starter: 'select 1;', savedDraft: null }), true, 'blank editor with no saved draft should restore starter')
assert.equal(shouldRestoreVariantStarter({ editorText: 'select 2;', starter: 'select 1;', savedDraft: null }), false, 'rendered code must never be replaced')
assert.equal(shouldRestoreVariantStarter({ editorText: '', starter: 'select 1;', savedDraft: 'select customer_id from customers;' }), false, 'valid saved variant draft must survive Monaco remount')
assert.equal(shouldRestoreVariantStarter({ editorText: '', starter: 'select 1;', savedDraft: '' }), true, 'persisted empty draft should recover to starter on variant switch')
assert.equal(shouldRestoreVariantStarter({ editorText: '', starter: '   ', savedDraft: null }), false, 'variant without starter cannot be repaired')

const guard = fs.readFileSync(new URL('../src/VariantSwitchGuard.jsx', import.meta.url), 'utf8')
assert(guard.includes('readSavedDraft') && guard.includes('draftKey'), 'variant guard must inspect the variant-specific saved draft')
assert(guard.includes('shouldRestoreVariantStarter'), 'variant guard must use the tested pure repair policy')
assert(guard.includes("`${engine.id}:engine:${activeEngine}`"), 'engine draft key must match App engine draft storage')
assert(guard.includes("`${sql.id}:sql:${select.value}`"), 'SQL draft key must match App SQL draft storage')

console.log('Variant guard validation passed: empty variants recover without overwriting valid saved SQL/DuckDB/BigQuery/pandas/PySpark drafts.')
