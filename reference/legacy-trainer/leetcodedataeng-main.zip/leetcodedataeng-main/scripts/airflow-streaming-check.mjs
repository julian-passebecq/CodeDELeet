import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import '../src/modernLakehouseExtensions.js'
import { airflow3StreamingLessons } from '../src/airflow3StreamingExtensions.js'
import { lessons } from '../src/curriculum.js'
import { cheatSheets } from '../src/cheatSheets.js'
import { hubExtensions } from '../src/learningHubContent.js'

const requiredIds = [
  'af3-task-sdk',
  'af3-asset-scheduling',
  'af3-upgrade-map',
  'stream-watermark-window',
  'stream-checkpoint-recovery',
  'stream-foreachbatch-idempotent',
  'stream-stream-join-watermarks',
  'stream-checkpoint-evolution',
]

assert.equal(airflow3StreamingLessons.length, 8, `expected 8 Airflow/streaming lessons, found ${airflow3StreamingLessons.length}`)
for (const id of requiredIds) assert(airflow3StreamingLessons.some((item) => item.id === id), `missing ${id}`)
assert.equal(airflow3StreamingLessons.filter((item) => item.track === 'airflow').length, 3, 'expected 3 Airflow 3 supporting drills')
assert.equal(airflow3StreamingLessons.filter((item) => item.track === 'pyspark').length, 5, 'expected 5 PySpark streaming core drills')

const airflow = cheatSheets.find((item) => item.id === 'airflow')
assert(airflow, 'Airflow cheat sheet missing')
const taskFlow = airflow.sections.find(([title]) => title === 'TaskFlow DAG')?.[1] ?? ''
assert(taskFlow.includes('from airflow.sdk import dag, task'), 'Airflow reference must use airflow.sdk')
assert(!taskFlow.includes('airflow.decorators'), 'Airflow reference must not display legacy airflow.decorators imports')
assert(airflow.starter.includes('from airflow.sdk import dag, task'), 'Airflow starter must use airflow.sdk')
assert(airflow.sections.some(([title, code]) => title === 'Airflow 3 Assets' && code.includes('Asset(')), 'Airflow reference must teach Assets')
assert(airflow.sections.some(([title]) => title === 'Airflow 3 architecture'), 'Airflow reference must explain Airflow 3 architecture')
assert(airflow.interview.some((topic) => topic.includes('Dataset → Asset')), 'Airflow interview checklist must include Dataset → Asset migration')

const watermark = lessons.find((item) => item.id === 'stream-watermark-window')
assert(watermark?.solution.includes("withWatermark('event_time', '20 minutes')"), 'watermark drill must use withWatermark')
assert(watermark?.solution.includes("F.window('event_time', '10 minutes')"), 'watermark drill must use an event-time window')

const checkpoint = lessons.find((item) => item.id === 'stream-checkpoint-recovery')
assert(checkpoint?.solution.includes('checkpointLocation'), 'checkpoint drill must configure checkpointLocation')

const foreachBatch = lessons.find((item) => item.id === 'stream-foreachbatch-idempotent')
assert(foreachBatch?.solution.includes('batch_id') && foreachBatch?.solution.includes('foreachBatch'), 'foreachBatch drill must use the micro-batch ID')
assert(/at-least-once/i.test(foreachBatch?.concept ?? ''), 'foreachBatch drill must state its default at-least-once semantics')

const streamJoin = lessons.find((item) => item.id === 'stream-stream-join-watermarks')
assert((streamJoin?.solution.match(/withWatermark/g) ?? []).length >= 2, 'stream-stream join must watermark both streams')
assert(streamJoin?.solution.includes('INTERVAL 1 HOUR'), 'stream-stream join must include a time-range condition')

const evolution = lessons.find((item) => item.id === 'stream-checkpoint-evolution')
assert(/cannot|incompatible|No, not blindly/i.test(evolution?.solution ?? ''), 'checkpoint-evolution drill must warn against incompatible state reuse')

const sparkHub = hubExtensions.pyspark
assert(sparkHub?.algorithms?.some(([title]) => title === 'Event time + watermark'), 'PySpark hub must include streaming state pattern')
assert(sparkHub?.interviewCards?.some(([title]) => title === 'Watermark vs checkpoint'), 'PySpark hub must include watermark/checkpoint interview card')
assert(sparkHub?.interviewCards?.some(([title]) => title === 'foreachBatch semantics'), 'PySpark hub must include foreachBatch interview card')

const allowedHosts = new Set(['airflow.apache.org', 'spark.apache.org'])
let officialCount = 0
for (const lesson of airflow3StreamingLessons) {
  assert(Array.isArray(lesson.officialSources) && lesson.officialSources.length > 0, `${lesson.id}: missing official sources`)
  for (const source of lesson.officialSources) {
    const parsed = new URL(source.url)
    assert.equal(parsed.protocol, 'https:', `${lesson.id}: official source must use HTTPS`)
    assert(allowedHosts.has(parsed.hostname), `${lesson.id}: unexpected official source host ${parsed.hostname}`)
    officialCount += 1
  }
}
assert(officialCount >= 10, `expected at least 10 official-doc references, found ${officialCount}`)

const main = fs.readFileSync(new URL('../src/main.jsx', import.meta.url), 'utf8')
assert(main.includes("import './airflow3StreamingExtensions'"), 'main must load Airflow 3/streaming extensions before App')
assert(main.indexOf("import './airflow3StreamingExtensions'") < main.indexOf("import App from './App'"), 'Airflow 3/streaming extensions must mutate curriculum before App loads')

console.log(`Airflow 3 + streaming validation: ${airflow3StreamingLessons.length} drills · ${officialCount} first-party references`)
console.log('Airflow 3/Structured Streaming validation passed: public SDK, Assets, upgrade concepts, watermarks, checkpoints, foreachBatch and stream joins are current.')
