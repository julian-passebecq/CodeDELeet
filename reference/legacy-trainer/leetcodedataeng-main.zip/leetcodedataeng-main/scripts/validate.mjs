import { lessons, tracks } from '../src/curriculum.js'
import '../src/algorithmExtensions.js'
import { analyticsLessons, mlopsLessons } from '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import { sqlChallenges, sqlChallengeTopics } from '../src/sqlChallenges.js'
import { getSqlDialectChallenge, sqlDialects } from '../src/sqlDialects.js'
import { engineChallenges, engineDefinitions, engineTopics, getEngineVariant } from '../src/engineLab.js'
import { pythonLabChallenges, pythonLabTopics } from '../src/pythonLab.js'

const failures = []
const warnings = []
const levels = new Set(['Beginner', 'Intermediate', 'Expert'])

function assert(condition, message) {
  if (!condition) failures.push(message)
}

function warn(condition, message) {
  if (!condition) warnings.push(message)
}

function nonEmpty(value) {
  return typeof value === 'string' && value.trim().length > 0
}

function validateTopicMembership(items, topics, collection) {
  const topicIds = new Set(topics.map((t) => t.id))
  for (const topic of topics) {
    assert(nonEmpty(topic.id), `${collection}: topic missing id`)
    assert(nonEmpty(topic.name), `${collection}: topic ${topic.id || '(unknown)'} missing name`)
  }
  for (const item of items) {
    assert(topicIds.has(item.track), `${collection}/${item.id}: unknown track ${item.track}`)
  }
}

function validateCommon(items, collection) {
  for (const item of items) {
    assert(nonEmpty(item.id), `${collection}: item missing id`)
    assert(nonEmpty(item.title), `${collection}/${item.id}: missing title`)
    assert(levels.has(item.level), `${collection}/${item.id}: invalid level ${item.level}`)
    assert(nonEmpty(item.concept), `${collection}/${item.id}: missing concept`)
    assert(nonEmpty(item.task), `${collection}/${item.id}: missing task`)
    assert(Array.isArray(item.hints) && item.hints.length > 0, `${collection}/${item.id}: missing hints`)
    assert(nonEmpty(item.pitfall), `${collection}/${item.id}: missing pitfall`)
  }
}

const collections = [
  ['core', lessons],
  ['sql', sqlChallenges],
  ['engine', engineChallenges],
  ['python', pythonLabChallenges],
]

const seenIds = new Map()
for (const [collection, items] of collections) {
  for (const item of items) {
    if (seenIds.has(item.id)) failures.push(`duplicate global id ${item.id}: ${seenIds.get(item.id)} and ${collection}`)
    else seenIds.set(item.id, collection)
  }
}

validateTopicMembership(lessons, tracks, 'core')
validateTopicMembership(sqlChallenges, sqlChallengeTopics, 'sql')
validateTopicMembership(engineChallenges, engineTopics, 'engine')
validateTopicMembership(pythonLabChallenges, pythonLabTopics, 'python')

validateCommon(lessons, 'core')
validateCommon(sqlChallenges, 'sql')
validateCommon(engineChallenges, 'engine')
validateCommon(pythonLabChallenges, 'python')

for (const item of lessons) {
  assert(nonEmpty(item.language), `core/${item.id}: missing language`)
  assert(nonEmpty(item.starter), `core/${item.id}: missing starter`)
  assert(nonEmpty(item.solution), `core/${item.id}: missing solution`)
  assert(nonEmpty(item.why), `core/${item.id}: missing why-it-matters explanation`)
}

const requiredAlgorithmIds = [
  'al-linear-search', 'al-binary-search', 'al-sorting', 'al-two-pointers', 'al-sliding-window',
  'al-prefix-sum', 'al-heap-top-k', 'al-graph-traversal', 'al-topological-sort', 'al-merge-intervals',
]
const algorithmLessons = lessons.filter((item) => item.track === 'algorithms')
assert(algorithmLessons.length >= 15, `algorithms: expected at least 15 practical drills, found ${algorithmLessons.length}`)
for (const id of requiredAlgorithmIds) assert(algorithmLessons.some((item) => item.id === id), `algorithms: missing classical pattern ${id}`)

assert(tracks.some((track) => track.id === 'analytics-engineering'), 'core: missing Analytics Engineering practical track')
assert(tracks.some((track) => track.id === 'mlops-practical'), 'core: missing MLOps practical track')
assert(analyticsLessons.length >= 12, `analytics engineering: expected at least 12 labs, found ${analyticsLessons.length}`)
assert(mlopsLessons.length >= 9, `MLOps: expected at least 9 labs, found ${mlopsLessons.length}`)
for (const id of ['ae-dbt-profile', 'ae-dbt-parse-log', 'ae-dbt-revenue-mart', 'ae-dbt-tests', 'ae-pandas-revenue', 'ae-spark-silver', 'ae-spark-delta-merge']) {
  assert(analyticsLessons.some((item) => item.id === id), `analytics engineering: missing ${id}`)
}
for (const id of ['mlops-docker-run', 'mlops-dockerfile', 'mlops-fastapi', 'mlops-compose', 'mlops-model-api', 'mlops-mlflow', 'mlops-gh-actions', 'mlops-orchestration']) {
  assert(mlopsLessons.some((item) => item.id === id), `MLOps: missing ${id}`)
}
assert([...analyticsLessons, ...mlopsLessons].filter((item) => nonEmpty(item.diagram)).length >= 6, 'practical labs should include architecture/flow diagrams where they add value')

const seniorityLessons = lessons.filter((item) => item.track === 'seniority')
assert(tracks.some((track) => track.id === 'seniority'), 'core: missing Junior → Senior track')
assert(seniorityLessons.length >= 8, `seniority: expected at least 8 comparisons, found ${seniorityLessons.length}`)
for (const id of ['js-sql-incremental', 'js-sql-dedupe', 'js-python-files', 'js-python-api', 'js-pyspark-join', 'js-pyspark-delta', 'js-dbt-incremental', 'js-quality-gate']) {
  const item = seniorityLessons.find((lesson) => lesson.id === id)
  assert(Boolean(item), `seniority: missing ${id}`)
  if (item) assert(nonEmpty(item.solutionExplanation), `seniority/${id}: missing explanation of junior vs senior difference`)
}
assert(seniorityLessons.filter((item) => nonEmpty(item.diagram)).length >= 4, 'seniority: expected Mermaid flows for architecture-heavy comparisons')

const sourceSparkLessons = lessons.filter((item) => item.sourcePack?.startsWith('pyspark-tutorial-master'))
assert(sourceSparkLessons.length >= 8, `PySpark uploaded course: expected at least 8 source-derived exercises, found ${sourceSparkLessons.length}`)
for (const id of ['src-sp-rdd-parallelize', 'src-sp-textfile', 'src-sp-read-dataframe', 'src-sp-aggregate-insurance', 'src-sp-sql-temp-view', 'src-sp-topandas-boundary', 'src-sp-titanic-clean']) {
  assert(sourceSparkLessons.some((item) => item.id === id), `PySpark uploaded course: missing ${id}`)
}

const noSqlLessons = lessons.filter((item) => item.track === 'nosql-optional')
const genAiLessons = lessons.filter((item) => item.track === 'genai-optional')
const sourcedK8sLessons = lessons.filter((item) => item.sourcePack?.startsWith('Advanced Deployment with Kubernetes'))
assert(noSqlLessons.length >= 3, `NoSQL optional: expected at least 3 practical exercises, found ${noSqlLessons.length}`)
assert(genAiLessons.length >= 4, `GenAI optional: expected at least 4 practical exercises, found ${genAiLessons.length}`)
assert(sourcedK8sLessons.length >= 3, `Kubernetes optional: expected at least 3 source-derived exercises, found ${sourcedK8sLessons.length}`)
for (const id of ['docker', 'kubernetes', 'mlops-practical', 'nosql-optional', 'genai-optional']) {
  const track = tracks.find((item) => item.id === id)
  assert(Boolean(track), `optional breadth: missing track ${id}`)
  if (track) assert(track.name.startsWith('Optional —'), `optional breadth: ${id} must be visibly labelled optional`)
}

const dialectIds = new Set(sqlDialects.map((d) => d.id))
assert(dialectIds.has('tsql') && dialectIds.has('duckdb') && dialectIds.has('bigquery'), 'sql dialect list must include tsql, duckdb, and bigquery')
for (const item of sqlChallenges) {
  for (const dialect of sqlDialects) {
    const variant = getSqlDialectChallenge(item, dialect.id)
    assert(variant.dialect === dialect.id, `sql/${item.id}/${dialect.id}: wrong resolved dialect`)
    assert(nonEmpty(variant.starter), `sql/${item.id}/${dialect.id}: missing starter`)
    assert(nonEmpty(variant.solution), `sql/${item.id}/${dialect.id}: missing solution`)
    assert(nonEmpty(variant.solutionExplanation), `sql/${item.id}/${dialect.id}: missing explanation`)
    assert(nonEmpty(variant.dialectLabel), `sql/${item.id}/${dialect.id}: missing dialect label`)
    if (dialect.id !== 'tsql') assert(!/\bdbo\./i.test(variant.starter + variant.solution), `sql/${item.id}/${dialect.id}: leaked dbo. schema prefix`)
    if (dialect.id === 'bigquery') {
      assert(!/\bDATEADD\s*\(/i.test(variant.starter + variant.solution), `sql/${item.id}/bigquery: leaked DATEADD`)
      assert(!/\bAS\s+int\b/i.test(variant.starter + variant.solution), `sql/${item.id}/bigquery: leaked T-SQL INT cast`)
    }
  }
}

for (const item of engineChallenges) {
  const variantNames = Object.keys(item.variants ?? {})
  assert(variantNames.length > 0, `engine/${item.id}: no variants`)
  for (const engine of variantNames) {
    assert(Boolean(engineDefinitions[engine]), `engine/${item.id}: unknown engine ${engine}`)
    const raw = item.variants[engine]
    assert(nonEmpty(raw.language), `engine/${item.id}/${engine}: missing language`)
    assert(nonEmpty(raw.starter), `engine/${item.id}/${engine}: missing starter`)
    assert(nonEmpty(raw.solution), `engine/${item.id}/${engine}: missing solution`)
    assert(nonEmpty(raw.explanation), `engine/${item.id}/${engine}: missing explanation`)
    const resolved = getEngineVariant(item, engine)
    assert(resolved.engine === engine, `engine/${item.id}/${engine}: resolver changed available engine`)
    assert(resolved.engineLabel === engineDefinitions[engine].label, `engine/${item.id}/${engine}: wrong label`)
    assert(nonEmpty(resolved.starter), `engine/${item.id}/${engine}: switch resolved to blank starter`)
  }
}

const qualify = engineChallenges.find((item) => item.id === 'bq-qualify')
assert(Boolean(qualify), 'engine: missing bq-qualify regression exercise')
if (qualify) {
  const bq = getEngineVariant(qualify, 'bigquery')
  const duck = getEngineVariant(qualify, 'duckdb')
  assert(nonEmpty(bq.starter), 'bq-qualify: BigQuery starter became blank')
  assert(nonEmpty(duck.starter), 'bq-qualify: DuckDB starter became blank')
  assert(/QUALIFY/i.test(duck.starter), 'bq-qualify: DuckDB starter should retain QUALIFY pattern')
}

for (const item of pythonLabChallenges) {
  assert(item.language === 'python', `python/${item.id}: language must be python`)
  assert(nonEmpty(item.starter), `python/${item.id}: missing starter`)
  assert(nonEmpty(item.solution), `python/${item.id}: missing solution`)
  assert(nonEmpty(item.solutionExplanation), `python/${item.id}: missing explanation`)
}

for (const [collection, items] of collections) assert(items.length > 0, `${collection}: collection is empty`)

for (const [name, items, topics] of [
  ['core', lessons, tracks], ['sql', sqlChallenges, sqlChallengeTopics], ['engine', engineChallenges, engineTopics], ['python', pythonLabChallenges, pythonLabTopics],
]) {
  for (const topic of topics) warn(items.some((item) => item.track === topic.id), `${name}: topic ${topic.id} has no exercises`)
}

const total = lessons.length + sqlChallenges.length + engineChallenges.length + pythonLabChallenges.length
console.log(`Content: core=${lessons.length}, sql=${sqlChallenges.length}, engine=${engineChallenges.length}, python=${pythonLabChallenges.length}, total=${total}`)
console.log(`Algorithms: ${algorithmLessons.length} drills`)
console.log(`Analytics engineering: ${analyticsLessons.length} practical labs`)
console.log(`Junior vs Senior: ${seniorityLessons.length} comparisons`)
console.log(`PySpark uploaded-course labs: ${sourceSparkLessons.length}`)
console.log(`Optional breadth: NoSQL=${noSqlLessons.length}, Kubernetes-source=${sourcedK8sLessons.length}, GenAI=${genAiLessons.length}, MLOps=${mlopsLessons.length}`)
console.log(`Global IDs: ${seenIds.size} unique`)
console.log(`SQL variants checked: ${sqlChallenges.length * sqlDialects.length}`)
console.log(`Engine variants checked: ${engineChallenges.reduce((n, item) => n + Object.keys(item.variants ?? {}).length, 0)}`)

for (const message of warnings) console.warn(`WARN: ${message}`)
if (failures.length) {
  console.error(`\nValidation failed with ${failures.length} issue(s):`)
  for (const message of failures) console.error(`- ${message}`)
  process.exit(1)
}

console.log('Validation passed.')
