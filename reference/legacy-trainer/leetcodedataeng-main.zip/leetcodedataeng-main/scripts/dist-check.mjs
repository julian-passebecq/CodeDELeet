import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url))
const dist = path.join(root, 'dist')
const assetsDir = path.join(dist, 'assets')
const indexPath = path.join(dist, 'index.html')

assert(fs.existsSync(indexPath), 'dist check: dist/index.html is missing; run the production build first')
assert(fs.existsSync(assetsDir), 'dist check: dist/assets is missing')

const html = fs.readFileSync(indexPath, 'utf8')
const localRefs = [...html.matchAll(/(?:src|href)=["']\.\/(assets\/[^"']+)["']/g)].map((match) => match[1])
assert(localRefs.length > 0, 'dist check: index.html has no local built asset references')

for (const ref of localRefs) {
  const target = path.join(dist, ref)
  assert(fs.existsSync(target), `dist check: index.html references missing asset ${ref}`)
}

const files = fs.readdirSync(assetsDir)
const jsFiles = files.filter((name) => name.endsWith('.js'))
const cssFiles = files.filter((name) => name.endsWith('.css'))
assert(jsFiles.length >= 4, `dist check: expected split JavaScript bundles, found only ${jsFiles.length}`)
assert(cssFiles.length >= 1, 'dist check: expected at least one CSS bundle')

for (const marker of ['curriculum-data-', 'react-vendor-', 'editor-vendor-']) {
  assert(jsFiles.some((name) => name.startsWith(marker)), `dist check: expected ${marker} bundle is missing`)
}

const jsStats = jsFiles.map((name) => ({ name, bytes: fs.statSync(path.join(assetsDir, name)).size }))
const largest = jsStats.reduce((max, current) => current.bytes > max.bytes ? current : max, { name: '', bytes: 0 })
const maxChunkBytes = 500 * 1024
assert(largest.bytes <= maxChunkBytes, `dist check: ${largest.name} is ${(largest.bytes / 1024).toFixed(1)} KiB; keep individual JS chunks under 500 KiB`)

const totalJsBytes = jsStats.reduce((sum, item) => sum + item.bytes, 0)
const totalCssBytes = cssFiles.reduce((sum, name) => sum + fs.statSync(path.join(assetsDir, name)).size, 0)

console.log(`Production assets: ${jsFiles.length} JS chunks · ${cssFiles.length} CSS bundle(s) · ${localRefs.length} referenced assets verified`)
console.log(`Largest JS chunk: ${largest.name} · ${(largest.bytes / 1024).toFixed(1)} KiB`)
console.log(`Built payload: ${(totalJsBytes / 1024).toFixed(1)} KiB JS · ${(totalCssBytes / 1024).toFixed(1)} KiB CSS`)
console.log('Production asset smoke check passed: references resolve and bundle splitting is preserved.')
