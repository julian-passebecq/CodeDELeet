import assert from 'node:assert/strict'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import { lessons, tracks } from '../src/curriculum.js'
import { cheatSheets } from '../src/cheatSheets.js'
import { extraHubs, hubExtensions } from '../src/learningHubContent.js'
import fs from 'node:fs'

const repoText = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8')

const track = tracks.find((item) => item.id === 'pipeline-troubleshooting')
assert(track, 'troubleshooting: missing core track')

const items = lessons.filter((item) => item.track === 'pipeline-troubleshooting')
assert(items.length >= 19, `troubleshooting: expected at least 19 drills, found ${items.length}`)
assert.equal(new Set(items.map((item) => item.id)).size, items.length, 'troubleshooting: duplicate IDs')

for (const item of items) {
  assert(item.title?.trim(), `troubleshooting: ${item.id} missing title`)
  assert(item.task?.trim(), `troubleshooting: ${item.id} missing task`)
  assert(item.solution?.trim(), `troubleshooting: ${item.id} missing solution`)
}

const required = [
  'tr-incident-loop', 'tr-row-reconciliation', 'tr-schema-drift', 'tr-idempotent-rerun',
  'tr-late-watermark', 'tr-missing-partition', 'tr-join-explosion', 'tr-partition-redesign',
  'tr-small-files', 'tr-spark-skew', 'tr-driver-oom', 'tr-api-retry', 'tr-airflow-retries',
  'tr-airflow-queued', 'tr-backfill', 'tr-quality-quarantine', 'tr-polars-lazy',
  'tr-duckdb-debug', 'tr-tool-choice',
]
assert(required.every((id) => items.some((item) => item.id === id)), 'troubleshooting: required incident/tool-choice drills missing')

const polars = items.find((item) => item.id === 'tr-polars-lazy')
assert(polars.solution.includes('scan_parquet') && polars.solution.includes('.collect()'), 'troubleshooting: Polars lazy example incomplete')
const duckdb = items.find((item) => item.id === 'tr-duckdb-debug')
assert(duckdb.solution.includes('read_parquet') && duckdb.solution.includes('COUNT(DISTINCT'), 'troubleshooting: DuckDB reconciliation example incomplete')
const airflowRetry = items.find((item) => item.id === 'tr-airflow-retries')
assert(airflowRetry.diagram?.includes('Bounded retry') && airflowRetry.diagram?.includes('Quarantine'), 'troubleshooting: Airflow failure Mermaid diagram missing')
const incident = items.find((item) => item.id === 'tr-incident-loop')
assert(incident.diagram?.includes('Replay / backfill') && incident.diagram?.includes('Reconcile'), 'troubleshooting: incident lifecycle Mermaid diagram missing')

const hub = extraHubs.find((item) => item.id === 'pipeline-troubleshooting')
assert(hub, 'troubleshooting: learning hub missing')
assert(hub.sections.some(([title]) => title === 'Tool choice'), 'troubleshooting hub: tool choice matrix missing')
const ext = hubExtensions['pipeline-troubleshooting']
assert(ext?.algorithms?.length >= 8, 'troubleshooting hub: debugging/optimization patterns missing')
assert(ext?.interviewCards?.length >= 8, 'troubleshooting hub: interview incident cards missing')

const airflow = cheatSheets.find((item) => item.id === 'airflow')
assert(airflow?.sections.some(([title]) => title === 'Task-state troubleshooting'), 'Airflow reference: task-state troubleshooting missing')
assert(airflow?.sections.some(([title]) => title === 'Pools + concurrency'), 'Airflow reference: pools/concurrency troubleshooting missing')
assert(airflow?.sections.some(([title]) => title === 'Backfill checklist'), 'Airflow reference: backfill checklist missing')

const main = repoText('src/main.jsx')
const frontPage = repoText('src/FrontPageGuide.jsx')
const bridge = repoText('src/TroubleshootingHubBridge.jsx')
assert(main.includes("'./pipelineTroubleshootingExtensions'") && main.includes("'./airflowTroubleshootingExtensions'"), 'main must load troubleshooting extensions')
assert(main.includes('TroubleshootingHubBridge'), 'main must mount TroubleshootingHubBridge')
assert(frontPage.includes("'pipeline-troubleshooting'"), 'troubleshooting must count toward Core DE progress')
assert(frontPage.includes('Pipeline Troubleshooting'), 'home page must expose troubleshooting focus card')
assert(frontPage.includes("['07', 'Troubleshoot', 'Troubleshoot']"), 'recommended path must include troubleshooting')
assert(bridge.includes("detail: HUB_ID") && bridge.includes('troubleshootingFilled'), 'troubleshooting hub bridge must wire nav and source drills')

console.log(`Pipeline troubleshooting: ${items.length} core drills`)
console.log(`Troubleshooting interview cards: ${ext.interviewCards.length}`)
console.log(`Airflow reference sections: ${airflow.sections.length}`)
console.log('Troubleshooting validation passed: incidents, replay, partitioning, Spark, Airflow, Polars/DuckDB and optimization.')
