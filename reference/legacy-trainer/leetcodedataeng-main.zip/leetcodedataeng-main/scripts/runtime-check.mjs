import fs from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import { collectProgressBackup, restoreProgressBackup, validateProgressBackup, STORAGE_PREFIX } from '../src/progressBackup.js'
import { cheatSheets } from '../src/cheatSheets.js'
import { extraHubs, hubExtensions } from '../src/learningHubContent.js'
import { originalPreviewRuleCount, resolveOriginalSourcePreview } from '../src/sourcePreviewData.js'

const failures = []
const assert = (condition, message) => { if (!condition) failures.push(message) }

function fakeStorage(initial = {}) {
  const values = new Map(Object.entries(initial))
  return {
    get length() { return values.size },
    key(index) { return [...values.keys()][index] ?? null },
    getItem(key) { return values.has(key) ? values.get(key) : null },
    setItem(key, value) { values.set(key, String(value)) },
    dump() { return Object.fromEntries(values) },
  }
}

const source = fakeStorage({
  [`${STORAGE_PREFIX}:flags`]: JSON.stringify(['sql-row-number']),
  [`${STORAGE_PREFIX}:notes`]: JSON.stringify({ 'sql-row-number': 'redo' }),
  'other-app:key': JSON.stringify('ignore me'),
})
const backup = collectProgressBackup(source, '2026-09-03T18:00:00.000Z')
assert(Object.keys(backup.entries).length === 2, 'backup should include only trainer storage keys')
assert(!('other-app:key' in backup.entries), 'backup must not include unrelated localStorage entries')
assert(validateProgressBackup(JSON.stringify(backup)).format === 'de-coding-reset-backup', 'serialized backup should validate')

const destination = fakeStorage()
assert(restoreProgressBackup(destination, backup) === 2, 'restore should report restored entry count')
assert(destination.getItem(`${STORAGE_PREFIX}:flags`) === JSON.stringify(['sql-row-number']), 'restore should preserve serialized values')

try {
  validateProgressBackup({ ...backup, entries: { 'other-app:key': '[]' } })
  failures.push('backup validator accepted an unrelated storage key')
} catch {}
try {
  validateProgressBackup({ ...backup, entries: { [`${STORAGE_PREFIX}:flags`]: 'not-json' } })
  failures.push('backup validator accepted malformed serialized state')
} catch {}

const root = process.cwd()
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8')
const main = read('src/main.jsx')
const utilities = read('src/LabUtilities.jsx')
const algorithms = read('src/algorithmExtensions.js')
const practicalLabs = read('src/analyticsEngineeringExtensions.js')
const seniorityExtensions = read('src/seniorityExtensions.js')
const sourceCourseExtensions = read('src/sourceCourseExtensions.js')
const seniorityLayer = read('src/SeniorityPracticeLayer.jsx')
const seniorityCss = read('src/seniorityPractice.css')
const courseSourcePreviews = read('src/CourseSourcePreviews.jsx')
const variantGuard = read('src/VariantSwitchGuard.jsx')
const practiceDiagramLayer = read('src/PracticeDiagramLayer.jsx')
const practicalLabsCss = read('src/practicalLabs.css')
const frontPage = read('src/FrontPageGuide.jsx')
const frontPageCss = read('src/frontPage.css')
const focusPriorityCss = read('src/focusPriority.css')
const editorAppearanceCss = read('src/editorAppearance.css')
const editorThemeBridge = read('src/EditorThemeBridge.jsx')
const editorThemeCss = read('src/editorTheme.css')
const referenceLayer = read('src/ReferenceLayer.jsx')
const referenceLayerCss = read('src/referenceLayer.css')
const learningHubLayer = read('src/LearningHubLayer.jsx')
const learningHubCss = read('src/learningHub.css')
const originalSourcePreview = read('src/OriginalSourcePreviews.jsx')
const originalSourcePreviewCss = read('src/originalSourcePreview.css')
const sourcePreviewData = read('src/sourcePreviewData.js')

assert(main.includes('LabUtilities') && main.includes('LabErrorBoundary'), 'main.jsx must mount reliability wrappers')
assert(main.includes("'./algorithmExtensions'"), 'main.jsx must load classical algorithm extensions')
assert(main.includes("'./analyticsEngineeringExtensions'"), 'main.jsx must load practical analytics/MLOps extensions')
assert(main.includes("'./seniorityExtensions'"), 'main.jsx must load Junior vs Senior comparisons')
assert(main.includes("'./sourceCourseExtensions'"), 'main.jsx must load uploaded PySpark/NoSQL/optional course extensions')
assert(main.includes('SeniorityPracticeLayer') && main.includes("'./seniorityPractice.css'"), 'main.jsx must mount Junior/Senior compare UX')
assert(main.includes('CourseSourcePreviews'), 'main.jsx must mount uploaded-course source data previews')
assert(main.includes('VariantSwitchGuard'), 'main.jsx must mount the engine/dialect blank-switch guard')
assert(main.includes('PracticeDiagramLayer') && main.includes("'./practicalLabs.css'"), 'main.jsx must mount/stylize practical Mermaid diagrams')
assert(main.includes('FrontPageGuide') && main.includes("'./frontPage.css'") && main.includes("'./focusPriority.css'"), 'main.jsx must mount the focused landing page')
assert(main.includes('ReferenceLayer') && main.includes('OriginalSourcePreviews'), 'main.jsx must retain reference/source layers')
assert(main.includes('LearningHubLayer') && main.includes("'./learningHub.css'"), 'main.jsx must mount five-part learning hubs')
assert(main.includes('EditorThemeBridge') && main.includes("'./editorTheme.css'"), 'main.jsx must mount real Monaco theme bridge')

assert(variantGuard.includes("classList.contains('variant-select')"), 'variant guard must listen to real engine/dialect selector changes')
assert(variantGuard.includes('getEngineVariant') && variantGuard.includes('getSqlDialectChallenge'), 'variant guard must resolve both engine and SQL dialect starters')
assert(variantGuard.includes('editorText() ===') && variantGuard.includes('resetStarter()'), 'variant guard must repair blank editor models with the selected starter')
assert(variantGuard.includes('[40, 120, 260]'), 'variant guard should tolerate Monaco/React remount timing instead of relying on one tick')

assert(practicalLabs.includes("id: 'analytics-engineering'") && practicalLabs.includes("id: 'mlops-practical'"), 'practical Analytics Engineering and MLOps tracks must exist')
for (const required of ['ae-dbt-parse-log', 'ae-dbt-revenue-mart', 'ae-dbt-tests', 'ae-pandas-revenue', 'ae-spark-delta-merge', 'mlops-dockerfile', 'mlops-compose', 'mlops-model-api', 'mlops-mlflow', 'mlops-gh-actions']) {
  assert(practicalLabs.includes(`id: '${required}'`), `practical labs missing ${required}`)
}
assert(practicalLabs.includes('TD 6 — Analytics Engineering practical') && practicalLabs.includes('TD 1 — MLOps practical'), 'practical tracks must retain their tutorial/source grouping')
assert(practicalLabs.includes('ecommerceDiagram') && practicalLabs.includes('mlopsDiagram'), 'practical labs should contain project architecture diagrams')

for (const required of ['js-sql-incremental', 'js-sql-dedupe', 'js-python-files', 'js-python-api', 'js-pyspark-join', 'js-pyspark-delta', 'js-dbt-incremental', 'js-quality-gate']) {
  assert(seniorityExtensions.includes(`id: '${required}'`), `Junior vs Senior track missing ${required}`)
}
assert(seniorityExtensions.includes('incrementalFlow') && seniorityExtensions.includes('sparkFlow') && seniorityExtensions.includes('qualityFlow'), 'Junior vs Senior comparisons need visual production-flow diagrams')
assert(seniorityLayer.includes('Junior baseline') && seniorityLayer.includes('Senior version') && seniorityLayer.includes('Compare'), 'seniority practice must relabel editor tabs around the comparison model')
assert(seniorityLayer.includes('Rerun') && seniorityLayer.includes('Correctness') && seniorityLayer.includes('Scale'), 'seniority practice must teach the three production review lenses')
assert(seniorityCss.includes('.seniority-lenses'), 'seniority comparison styling must exist')

assert(sourceCourseExtensions.includes('pyspark-tutorial-master — uploaded course'), 'uploaded PySpark course must be preserved as a source grouping')
for (const required of ['src-sp-rdd-parallelize', 'src-sp-textfile', 'src-sp-read-dataframe', 'src-sp-aggregate-insurance', 'src-sp-sql-temp-view', 'src-sp-topandas-boundary', 'src-sp-titanic-clean']) {
  assert(sourceCourseExtensions.includes(`id: '${required}'`), `uploaded PySpark course missing ${required}`)
}
assert(sourceCourseExtensions.includes('lyon2-nosql-main — uploaded course'), 'uploaded NoSQL course must be preserved as a source grouping')
assert(sourceCourseExtensions.includes("id: 'nosql-optional'") && sourceCourseExtensions.includes("id: 'genai-optional'"), 'NoSQL and GenAI breadth tracks must exist')
assert(sourceCourseExtensions.includes('Optional —') && sourceCourseExtensions.includes("['docker', 'kubernetes', 'mlops-practical']"), 'Docker/Kubernetes/MLOps must be visibly demoted to optional breadth')
assert(sourceCourseExtensions.includes('k8sDiagram') && sourceCourseExtensions.includes('ragDiagram') && sourceCourseExtensions.includes('nosqlDiagram'), 'optional architecture-heavy topics need Mermaid-ready diagrams')

assert(courseSourcePreviews.includes('FL_insurance_sample.csv') && courseSourcePreviews.includes('titanic_sample.csv') && courseSourcePreviews.includes('movielens_movies_sample.json'), 'uploaded course data previews must expose the source-derived Spark and NoSQL samples')
assert(courseSourcePreviews.includes('SOURCE-DERIVED'), 'uploaded course previews must clearly label source-derived data')
assert(fs.existsSync(path.join(root, 'public/labs/pyspark/FL_insurance_sample.csv')), 'PySpark insurance sample file must ship with the site')
assert(fs.existsSync(path.join(root, 'public/labs/pyspark/titanic_sample.csv')), 'PySpark Titanic sample file must ship with the site')
assert(fs.existsSync(path.join(root, 'public/labs/nosql/movielens_movies_sample.json')), 'NoSQL MovieLens sample file must ship with the site')

assert(practiceDiagramLayer.includes('mermaid@11.17.2') && practiceDiagramLayer.includes("securityLevel: 'strict'"), 'Mermaid renderer must be pinned and use strict security mode')
assert(practiceDiagramLayer.includes('practice-diagram-fallback'), 'diagram UI must retain a text fallback if Mermaid cannot load')
assert(practicalLabsCss.includes('.practice-mermaid-svg'), 'practical diagram CSS must exist')

assert(!utilities.includes('pendingReveal') && !utilities.includes('Protect solution reveal'), 'solution reveal warning/interception must remain removed')
assert(utilities.includes('inline-theme-picker') && utilities.includes('ensureInlineThemeMount'), 'editor theme controls must remain visible in toolbar')
assert(utilities.includes("{ id: 'gray'") && utilities.includes("{ id: 'black'") && utilities.includes("{ id: 'light'"), 'gray, black and light appearances must exist')
assert(editorAppearanceCss.includes("data-editor-appearance='gray'") && editorAppearanceCss.includes("data-editor-appearance='black'") && editorAppearanceCss.includes("data-editor-appearance='light'"), 'appearance shell CSS must cover all three modes')
assert(editorThemeBridge.includes("defineTheme('de-gray'") && editorThemeBridge.includes("defineTheme('de-black'") && editorThemeBridge.includes("defineTheme('de-light'"), 'real Monaco palettes must exist for all three appearances')
assert(editorThemeBridge.includes("'keyword', foreground: '7DD3FC'") && editorThemeBridge.includes("'string', foreground: 'A31515'"), 'black/light syntax palettes must use high-contrast token colors')
assert(editorThemeCss.includes('filter: none !important'), 'legacy inversion must be neutralized')

const expectedSheets = ['python', 'pandas', 'pyspark', 'sql', 'powershell', 'csharp-functions', 'csharp-tabular', 'airflow', 'dax', 'kubernetes']
assert(expectedSheets.every((id) => cheatSheets.some((sheet) => sheet.id === id)), 'requested language/platform cheat sheets must remain available')
for (const sheet of cheatSheets) {
  assert(sheet.sections?.length >= 4, `cheat sheet ${sheet.id} should contain at least four syntax sections`)
  assert(sheet.mentalModels?.length >= 3, `cheat sheet ${sheet.id} should contain mental models`)
  assert(sheet.interview?.length >= 4, `cheat sheet ${sheet.id} should contain interview checklist items`)
  assert(typeof sheet.starter === 'string' && sheet.starter.trim(), `cheat sheet ${sheet.id} should include starter code`)
}

const requiredExtraHubs = ['coding-concepts', 'duckdb', 'dbt', 'de-interview', 'bi']
assert(requiredExtraHubs.every((id) => extraHubs.some((hub) => hub.id === id)), 'coding, DuckDB, dbt, DE interview and BI hubs must exist')
assert(hubExtensions.python?.algorithms?.length >= 6 && hubExtensions.python?.interviewCards?.length >= 4, 'Python hub must include algorithms and structured interview cards')
assert(hubExtensions.sql?.algorithms?.length >= 4 && hubExtensions.sql?.interviewCards?.length >= 4, 'SQL hub must include patterns and structured interview cards')
assert(hubExtensions.dbt?.interviewCards?.length >= 3, 'dbt hub must include theory/example/interview cards')
assert(hubExtensions['de-interview']?.interviewCards?.length >= 4, 'DE hub must include typical architecture/database interview cards')
assert(hubExtensions.bi?.interviewCards?.length >= 4, 'BI hub must include BI/finance/logistics interview cards')

assert(learningHubLayer.includes("['cheat', 'Cheat sheet'") && learningHubLayer.includes("['algorithms', 'Algorithms / patterns'") && learningHubLayer.includes("['source', 'Source labs'") && learningHubLayer.includes("['problems', 'Typical problems'") && learningHubLayer.includes("['interview', 'Interview'"), 'each learning hub must expose the five requested sections')
assert(learningHubLayer.includes('data-learning-hub-id') && learningHubLayer.includes('hubForPractice'), 'practice breadcrumb must route back to the correct learning hub')
assert(learningHubLayer.includes("item.collection === 'python-lab'") && learningHubLayer.includes("item.collection === 'sql-lab'"), 'Python and SQL lab breadcrumbs must resolve to language roots')
assert(learningHubLayer.includes("actions.classList.toggle('has-variants'") && learningHubCss.includes('.code-pane-actions.has-variants > .language-chip'), 'multi-engine UI must hide the duplicate language chip')
assert(learningHubLayer.includes('compact-hide-rule') && learningHubLayer.includes('AlgorithmVisual'), 'practice pages must be compact and algorithm drills must get visual mental models')
assert(learningHubCss.includes('.problem-section.compact-hide-rule') && learningHubCss.includes('.algorithm-mini-visual'), 'compact/visual practice styles must exist')

assert(referenceLayer.includes('FullCurriculum') && referenceLayer.includes('tracks.map'), 'home page must expose full curriculum')
assert(referenceLayer.includes('VariantButtons') && referenceLayer.includes('DataPreview'), 'variant buttons and data previews must remain')
assert(referenceLayer.includes('ExpandedPatterns') && referenceLayer.includes('extraPatterns'), 'Pattern Bridge expansion must remain')
assert(referenceLayerCss.includes('.variant-select-enhanced') && referenceLayerCss.includes('.variant-button-row'), 'legacy variant select enhancement must remain')

assert(originalPreviewRuleCount >= 12, 'source preview resolver should cover original notebook packs')
const joinPreview = resolveOriginalSourcePreview({ sourcePack: 'Inner Joins', title: 'Match customers to detailed orders' })
assert(joinPreview?.tables?.some((t) => t.name === 'df_customers' && t.rows.some((row) => row.includes('Toufik'))), 'inner-join preview must use original customer rows')
const footballPreview = resolveOriginalSourcePreview({ sourcePack: 'CASE football exercise', title: 'Count home and away wins conditionally' })
assert(footballPreview?.sourceFile === 'season-1011_csv.csv' && footballPreview.tables[0].rows.some((row) => row.includes('Lille')), 'football CASE preview must use uploaded season dataset')
const windowPreview = resolveOriginalSourcePreview({ sourcePack: 'Window Functions — OVER', title: 'Repeat a grand total on every row with OVER()' })
assert(windowPreview?.tables?.some((t) => t.name === 'capteur_a_retrail.csv' && t.rows[0][2] === 4200), 'window preview must use original sensor CSV rows')
const groupingPreview = resolveOriginalSourcePreview({ sourcePack: 'Grouping Sets', title: 'Baseline: reimbursements by contract type' })
assert(groupingPreview?.tables?.some((t) => t.name.includes('health reimbursements')), 'grouping-set preview must use original health notebook sample')
assert(sourcePreviewData.includes('appartements_nord_pdc.csv') && sourcePreviewData.includes('weights_turnover_retail.csv'), 'real-estate and retail source samples must remain')
assert(originalSourcePreview.includes('SOURCE-DERIVED') && originalSourcePreviewCss.includes('.source-derived-badge'), 'source-derived preview labeling must remain')

assert(algorithms.includes('al-topological-sort') && algorithms.includes('al-sliding-window') && algorithms.includes('al-heap-top-k'), 'algorithm extensions must include DAG, sliding-window and heap patterns')
assert(frontPage.includes('CORE FOCUS') && frontPage.includes('OPTIONAL BREADTH') && frontPage.includes('Junior vs Senior'), 'landing page must communicate the core-vs-optional priority and seniority path')
assert(frontPage.includes('Analytics Engineering') && frontPage.includes('PySpark') && frontPage.includes('dbt'), 'landing page must foreground analytics/data engineering skills')
assert(frontPageCss.includes('.home-page.home-simplified') && frontPageCss.includes('.simple-mode-grid'), 'simplified landing styles must remain')
assert(focusPriorityCss.includes('.core-focus-tier') && focusPriorityCss.includes('.optional-focus-tier'), 'core/optional focus styles must exist')

if (failures.length) {
  console.error(`Runtime validation failed with ${failures.length} issue(s):`)
  for (const failure of failures) console.error(`- ${failure}`)
  process.exit(1)
}

console.log(`Reference sheets: ${cheatSheets.length}`)
console.log(`Extra learning hubs: ${extraHubs.length}`)
console.log(`Original source preview rules: ${originalPreviewRuleCount}`)
console.log('Runtime checks passed: core-vs-optional focus, Junior/Senior compare, uploaded PySpark/NoSQL previews, variant switching, Mermaid diagrams, learning hubs, Monaco themes and trainer safeguards.')
