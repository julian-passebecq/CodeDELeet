import assert from 'node:assert/strict'
import fs from 'node:fs'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import { modernLakehouseLessons } from '../src/modernLakehouseExtensions.js'
import { lessons } from '../src/curriculum.js'
import { hubExtensions } from '../src/learningHubContent.js'

const requiredIds = [
  'modern-format-table-engine-catalog',
  'modern-iceberg-hidden-partition',
  'modern-duckdb-iceberg',
  'modern-databricks-liquid-clustering',
  'modern-fabric-vorder',
  'modern-fabric-partition-vs-liquid',
  'modern-spark-aqe',
  'modern-polars-lazy-parquet',
  'modern-dbt-microbatch',
  'modern-engine-layout-decision',
]

assert.equal(modernLakehouseLessons.length, 10, `modern web: expected 10 lessons, found ${modernLakehouseLessons.length}`)
for (const id of requiredIds) assert(modernLakehouseLessons.some((item) => item.id === id), `modern web: missing ${id}`)

const allowedHosts = new Set(['iceberg.apache.org', 'duckdb.org', 'learn.microsoft.com', 'spark.apache.org', 'docs.pola.rs', 'docs.getdbt.com'])
for (const item of modernLakehouseLessons) {
  assert(item.sourcePack?.startsWith('Web verified'), `modern web/${item.id}: should identify web-verified provenance`)
  assert(Array.isArray(item.officialSources) && item.officialSources.length > 0, `modern web/${item.id}: missing official sources`)
  for (const source of item.officialSources) {
    const url = new URL(source.url)
    assert(url.protocol === 'https:', `modern web/${item.id}: source must use https`)
    assert(allowedHosts.has(url.hostname), `modern web/${item.id}: non-first-party source host ${url.hostname}`)
    assert(source.label?.trim(), `modern web/${item.id}: source label missing`)
  }
}

const byId = (id) => modernLakehouseLessons.find((item) => item.id === id)
assert(byId('modern-iceberg-hidden-partition').solution.includes('bucket(32, customer_id)'), 'modern web: Iceberg exercise should use hidden partition transforms')
assert(byId('modern-duckdb-iceberg').solution.includes('iceberg_snapshots'), 'modern web: DuckDB exercise should inspect Iceberg snapshots')
assert(byId('modern-databricks-liquid-clustering').solution.includes('CLUSTER BY'), 'modern web: Databricks exercise should use CLUSTER BY')
assert(/V-ORDER|V-Order/.test(byId('modern-fabric-vorder').solution), 'modern web: Fabric exercise should distinguish V-Order')
assert(byId('modern-spark-aqe').solution.includes('spark.sql.adaptive.enabled'), 'modern web: Spark exercise should cover AQE')
assert(byId('modern-polars-lazy-parquet').solution.includes('scan_parquet'), 'modern web: Polars exercise should use lazy scan_parquet')
assert(byId('modern-dbt-microbatch').solution.includes("incremental_strategy='microbatch'"), 'modern web: dbt exercise should configure microbatch')

assert(lessons.filter((item) => item.track === 'storage-performance').some((item) => item.id === 'modern-iceberg-hidden-partition'), 'modern web: storage integration missing')
assert(lessons.filter((item) => item.track === 'pyspark').some((item) => item.id === 'modern-spark-aqe'), 'modern web: PySpark integration missing')
assert(lessons.filter((item) => item.track === 'analytics-engineering').some((item) => item.id === 'modern-dbt-microbatch'), 'modern web: Analytics Engineering integration missing')
assert(lessons.filter((item) => item.track === 'pipeline-troubleshooting').some((item) => item.id === 'modern-polars-lazy-parquet'), 'modern web: troubleshooting integration missing')

assert(hubExtensions['storage-performance']?.interviewCards?.some((card) => card[0] === 'Iceberg hidden partitioning'), 'modern web: storage hub should teach Iceberg')
assert(hubExtensions.pyspark?.interviewCards?.some((card) => card[0] === 'AQE'), 'modern web: PySpark hub should teach AQE')
assert(hubExtensions.dbt?.interviewCards?.some((card) => card[0] === 'Microbatch'), 'modern web: dbt hub should teach microbatch')
assert(hubExtensions['de-interview']?.interviewCards?.some((card) => card[0] === 'Modern physical layout'), 'modern web: DE interview hub should include runtime-aware layout')

const main = fs.readFileSync(new URL('../src/main.jsx', import.meta.url), 'utf8')
const layer = fs.readFileSync(new URL('../src/OfficialSourceLayer.jsx', import.meta.url), 'utf8')
const css = fs.readFileSync(new URL('../src/officialSources.css', import.meta.url), 'utf8')
assert(main.includes("import './modernLakehouseExtensions'"), 'modern web: extension must load before App')
assert(main.indexOf("import './modernLakehouseExtensions'") < main.indexOf("import App from './App'"), 'modern web: extension must mutate curriculum before App module loads')
assert(main.includes('<OfficialSourceLayer />'), 'modern web: official-source layer must render')
assert(layer.includes('.problem-meta') && layer.includes('officialSources'), 'modern web: source layer must attach to practice metadata')
assert(layer.includes('requestAnimationFrame'), 'modern web: source layer DOM observer should be coalesced')
assert(css.includes('.official-source-row a') && css.includes(':focus-visible'), 'modern web: official source links need readable/focusable styling')

console.log(`Modern lakehouse validation: ${modernLakehouseLessons.length} web-verified core drills · ${modernLakehouseLessons.reduce((sum, item) => sum + item.officialSources.length, 0)} official-doc references`)
console.log('Modern web validation passed: Iceberg, DuckDB/Iceberg, liquid clustering, Fabric V-Order, Spark AQE, Polars lazy scans and dbt microbatch are wired to first-party docs.')
