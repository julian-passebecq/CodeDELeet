import assert from 'node:assert/strict'
import '../src/algorithmExtensions.js'
import '../src/analyticsEngineeringExtensions.js'
import '../src/seniorityExtensions.js'
import '../src/sourceCourseExtensions.js'
import '../src/storagePerformanceExtensions.js'
import '../src/pipelineTroubleshootingExtensions.js'
import '../src/airflowTroubleshootingExtensions.js'
import '../src/modernLakehouseExtensions.js'
import '../src/airflow3StreamingExtensions.js'
import '../src/dataReliabilityExtensions.js'
import '../src/architectureVisualExtensions.js'
import { lessons, tracks } from '../src/curriculum.js'
import { sqlChallenges } from '../src/sqlChallenges.js'
import { engineChallenges } from '../src/engineLab.js'
import { pythonLabChallenges } from '../src/pythonLab.js'

const nonEmpty = (value) => typeof value === 'string' && value.trim().length > 0
const levels = new Set(['Beginner', 'Intermediate', 'Expert'])
const trackIds = new Set(tracks.map((track) => track.id))

assert.equal(new Set(tracks.map((track) => track.id)).size, tracks.length, 'full curriculum: duplicate track IDs')
assert.equal(new Set(lessons.map((lesson) => lesson.id)).size, lessons.length, 'full curriculum: duplicate lesson IDs')

for (const lesson of lessons) {
  assert(trackIds.has(lesson.track), `full curriculum/${lesson.id}: unknown track ${lesson.track}`)
  assert(nonEmpty(lesson.title), `full curriculum/${lesson.id}: missing title`)
  assert(levels.has(lesson.level), `full curriculum/${lesson.id}: invalid level ${lesson.level}`)
  assert(nonEmpty(lesson.language), `full curriculum/${lesson.id}: missing language`)
  assert(nonEmpty(lesson.concept), `full curriculum/${lesson.id}: missing concept`)
  assert(nonEmpty(lesson.why), `full curriculum/${lesson.id}: missing why`)
  assert(nonEmpty(lesson.task), `full curriculum/${lesson.id}: missing task`)
  assert(nonEmpty(lesson.starter), `full curriculum/${lesson.id}: missing starter`)
  assert(nonEmpty(lesson.solution), `full curriculum/${lesson.id}: missing solution`)
  assert(Array.isArray(lesson.hints) && lesson.hints.length > 0, `full curriculum/${lesson.id}: missing hints`)
  assert(nonEmpty(lesson.pitfall), `full curriculum/${lesson.id}: missing pitfall`)
}

for (const track of tracks) {
  const count = lessons.filter((lesson) => lesson.track === track.id).length
  assert(count > 0, `full curriculum: track ${track.id} has no exercises`)
}

const collections = [
  ['curriculum', lessons],
  ['sql', sqlChallenges],
  ['engine', engineChallenges],
  ['python', pythonLabChallenges],
]
const globalIds = new Map()
for (const [collection, items] of collections) {
  for (const item of items) {
    assert(!globalIds.has(item.id), `full runtime: duplicate global ID ${item.id} in ${globalIds.get(item.id)} and ${collection}`)
    globalIds.set(item.id, collection)
  }
}

const expectedTotal = lessons.length + sqlChallenges.length + engineChallenges.length + pythonLabChallenges.length
assert.equal(globalIds.size, expectedTotal, 'full runtime: global ID count does not match all loaded collections')
assert.equal(lessons.length, 211, `full runtime: expected 211 curriculum lessons in v2.12, found ${lessons.length}`)
assert.equal(expectedTotal, 323, `full runtime: expected 323 distinct practice items in v2.12, found ${expectedTotal}`)

console.log(`Full runtime curriculum: ${tracks.length} tracks · ${lessons.length} curriculum lessons · ${expectedTotal} total practice items`)
console.log('Full runtime validation passed: all loaded extensions have complete lesson metadata and globally unique IDs.')
