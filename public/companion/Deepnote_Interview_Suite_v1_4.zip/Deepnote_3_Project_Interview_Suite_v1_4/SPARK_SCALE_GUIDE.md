# Spark Scale Guide — Deepnote Local Interview Mode

## What this suite uses

The Spark notebooks use:

```python
SparkSession.builder.master("local[2]")
```

That is a **single-machine local Spark application with two worker threads**.
It is not a two-node cluster.

Deepnote Free currently documents its Basic machine as **5 GB RAM / 2 vCPU**.

## Order of magnitude

Use this as a learning guideline, not a service-level guarantee:

| Logical dataset/workload | Guidance |
|---|---|
| 10k–100k rows / few MB | trivial |
| 100k–1M / ~10–200 MB | ideal practice |
| 1–5M narrow rows / ~100–500 MB | reasonable for many simple operations |
| 1–2M narrow/generated rows / ~100–250 MB | upper practice / mild stress |
| >2M rows or multi-GB wide data with heavy shuffle/window/join | outside this practice suite |
| tens of GB to TB+ | use real remote/serverless Spark compute |

Row width matters more than row count. A million 20-byte rows and a million 2-KB JSON rows are radically different.

## Why local Spark is still useful

The following concepts are real in local mode:

- DataFrame API
- lazy transformations/actions
- partitions
- narrow vs wide transformations
- shuffle boundaries
- joins
- broadcast hints
- windows
- Spark SQL
- physical plans / `explain("formatted")`
- AQE configuration
- driver-side `collect()` risks

What it does **not** reproduce faithfully:
- cross-machine network shuffle
- executor loss across nodes
- autoscaling
- distributed storage locality
- large-cluster scheduling/resource contention

## Production-scale perspective

Spark itself is designed for distributed workloads and its official FAQ notes production ETL/analysis workloads at PB scale. That is a statement about **clusters**, not this 5-GB Deepnote VM.

## Official references

- Deepnote Spark: https://deepnote.com/docs/spark
- Deepnote pricing: https://deepnote.com/pricing
- Spark local master URLs: https://spark.apache.org/docs/latest/submitting-applications.html
- Spark FAQ: https://spark.apache.org/faq.html
