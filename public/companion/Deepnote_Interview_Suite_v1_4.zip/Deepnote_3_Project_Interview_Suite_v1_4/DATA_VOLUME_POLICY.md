# Data Volume Policy — v1.4

This suite is for interview practice, not throughput benchmarking.

## Stored data

The bundle intentionally contains **no large datasets**. All fixtures are embedded, synthetic, and small.

- Python examples: usually 4–10 records
- Pandas examples: usually 5–10 rows
- Hybrid mocks: about 5 rows in the shared fixture
- SQL optimization demo: 500 generated rows
- Classic SQL exam fixtures: small synthetic tables
- PySpark normal exercises: 5 fact rows + 3 dimension rows

## Spark exception: optional generated benchmark

Project 1 / Notebook 3 includes an **optional** Spark-only benchmark:

- `100k` rows — default
- `500k` rows — medium
- `2M` rows — upper practice/stress setting

The notebook contains a hard cap of **2,000,000 rows**.

The benchmark:
- is generated on demand with `spark.range()`;
- is not stored in the ZIP;
- uses only three narrow columns;
- performs one grouped aggregation;
- does not `collect()` the large DataFrame;
- should not be cached/persisted.

This is enough to make Spark do genuine partitioned work and a shuffle without turning the practice notebook into a resource-stress project.

## Why not bigger?

On a 2-vCPU / 5-GB local Deepnote VM, the goal is to learn:
- DataFrame syntax
- lazy evaluation
- partitions
- joins
- windows
- shuffle boundaries
- physical plans
- skew concepts

It is not useful to force 10–20M rows just to make the VM slow or unstable.

Use remote/serverless Spark later for true multi-node or tens-of-GB-plus behavior.
