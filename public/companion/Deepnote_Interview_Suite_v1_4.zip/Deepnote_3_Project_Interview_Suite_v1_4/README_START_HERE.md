# Deepnote 3-Project Interview Suite — v1.4

This is the debugged 3-project / 9-notebook interview practice suite.

## Project 1 — Python / Pandas / PySpark
1. Python Core Interview Arena
2. Pandas + NumPy Data Wrangling Arena
3. PySpark DataFrame Interview Arena

### Spark upgrade in v1.4
Deepnote officially supports Spark/PySpark. The PySpark notebook now treats real Spark execution as the preferred path:
- local `SparkSession` for the tiny interview datasets;
- optional native checkbox to install PySpark in the current Deepnote machine session if missing;
- UTC Spark timezone;
- runnable filter/groupBy/join/window/broadcast/repartition/explain/Spark-SQL checks;
- graceful syntax-only fallback if the project environment still cannot start Spark.

For a persistent Spark setup, use a Spark-ready project environment or project initialization rather than reinstalling on every hardware restart.

## Project 2 — SQL / Pipeline
1. SQL Screener + Onsite Arena — 10 mocks / 80 questions
2. SQL Patterns + Optimization + Interview Playbook
3. Airflow / Pipeline / SQL DE Arena

70 SQL questions have automatic result checkers; optimization/EXPLAIN questions remain evidence/reasoning based.

## Project 3 — Hybrid DE / BI
1. dbt + DAX + Power BI
2. Mixed Technical Mock Exams
3. Conceptual DE Mock Exam

The mixed mocks now run their PySpark question too when Spark is available.

## Deepnote UX retained
- native H2/H3 collapsible hierarchy
- notebook maps / at-a-glance summaries
- Red / Orange / Green status controls
- personal notes
- editable answer cells
- PASS/FAIL checkers where deterministic
- hidden reference answers
- 9 IPYNB backups

## Import
Upload only the single `.deepnote` file inside each project's `UPLOAD_THIS_PROJECT/` folder. Each one already contains exactly 3 notebooks.


## v1.4 Spark decision

We now standardize on **Deepnote local Spark first**:

- `local[2]`
- 4 shuffle partitions for small interview data
- AQE enabled
- optional 100k / 1M / 5M generated-data benchmark
- clear distinction between local single-machine Spark and a real remote cluster

See `SPARK_SCALE_GUIDE.md`.

For daily interview practice, keep data small. The point is to learn Spark APIs, transformations,
shuffles, joins, windows and plans. Use a remote/serverless cluster only when you specifically
want real distributed scale behavior.


## v1.4 data-volume policy

This is a **practice-sized** suite. No large datasets are stored in the project.

The only intentionally larger workload is the optional PySpark benchmark:
`100k` / `500k` / `2M` generated rows, with a hard cap at 2M.

See `DATA_VOLUME_POLICY.md`.
