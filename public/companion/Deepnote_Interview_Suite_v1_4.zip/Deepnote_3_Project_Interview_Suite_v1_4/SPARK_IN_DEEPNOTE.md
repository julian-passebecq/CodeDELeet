# Spark in Deepnote — v1.3

## Recommended starting mode

Use **local Spark on the Deepnote Basic machine**.

The project deliberately starts:

```python
SparkSession.builder.master("local[2]")
```

This gives us a predictable two-thread Spark lab for interview exercises.

## Why this is enough initially

You can genuinely practise:
- PySpark DataFrames
- joins
- groupBy/shuffles
- windows
- Spark SQL
- broadcast joins
- repartition/coalesce
- `explain("formatted")`
- partitions
- AQE

A remote cluster is not required for learning those APIs.

## If PySpark is not installed

The notebook has an optional install control. For repeated use, configure PySpark once in
Deepnote project initialization instead of reinstalling after each machine restart.

## Remote cluster later

Deepnote also supports Spark Connect to Spark >= 3.4 remote environments. Keep that for later
when you specifically want real multi-node behavior or larger workloads.

See `SPARK_SCALE_GUIDE.md` for the order-of-magnitude data sizes.
