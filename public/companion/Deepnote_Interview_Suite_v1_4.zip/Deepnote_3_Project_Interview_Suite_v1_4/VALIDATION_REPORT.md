# Validation Report — Deepnote 3-Project Interview Suite v1.4

**109/109 checks passed.**

## Data-volume decision

- No large datasets are stored in the suite.
- Normal Python/Pandas/SQL/Hybrid fixtures are tiny synthetic data.
- SQL optimization demo generates 500 rows.
- Normal PySpark fixture is 5 fact rows + 3 dimension rows.
- Optional PySpark benchmark: 100k / 500k / 2M generated rows.
- Hard cap: 2,000,000 rows.
- Benchmark does not collect/cache/persist the large DataFrame.

## Runtime limitation

This build environment does not have PySpark installed and cannot download packages, so a JVM SparkSession was not launched here. Every Spark code cell syntax-compiles and the Deepnote notebook contains its own live startup/runtime checks. Python, Pandas, NumPy and SQLite runtime probes were executed here.

## Inventory

- Deepnote projects: 3
- notebooks: 9
- Deepnote blocks: 1029
- code blocks: 315
- IPYNB backups: 9

- PASS — **Exactly 3 native Deepnote project files**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote: YAML parses**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote: exactly 3 notebooks**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote: sortingKey values explicitly quoted**: 222 blocks
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote: block IDs unique**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote: blockGroup IDs unique**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: collapsible H2/H3 hierarchy**: H2=6, H3=11
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: native input names unique**: 2 controls
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: every code block syntax-compiles**: 23 blocks
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: Markdown fences balanced**: 22
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: disclosure blocks balanced**: 11/11
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: status control present**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N1: notes control present**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: collapsible H2/H3 hierarchy**: H2=7, H3=9
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: native input names unique**: 2 controls
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: every code block syntax-compiles**: 20 blocks
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: Markdown fences balanced**: 14
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: disclosure blocks balanced**: 8/8
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: status control present**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N2: notes control present**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: collapsible H2/H3 hierarchy**: H2=8, H3=15
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: native input names unique**: 5 controls
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: every code block syntax-compiles**: 24 blocks
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: Markdown fences balanced**: 26
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: disclosure blocks balanced**: 11/11
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: status control present**
- PASS — **Python_Pandas_PySpark_Interview_Arena.deepnote N3: notes control present**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote: YAML parses**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote: exactly 3 notebooks**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote: sortingKey values explicitly quoted**: 535 blocks
- PASS — **SQL_Pipeline_Interview_Arena.deepnote: block IDs unique**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote: blockGroup IDs unique**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: collapsible H2/H3 hierarchy**: H2=3, H3=10
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: native input names unique**: 20 controls
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: every code block syntax-compiles**: 170 blocks
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: Markdown fences balanced**: 22
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: disclosure blocks balanced**: 11/11
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: status control present**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N1: notes control present**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: collapsible H2/H3 hierarchy**: H2=16, H3=35
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: native input names unique**: 2 controls
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: every code block syntax-compiles**: 0 blocks
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: Markdown fences balanced**: 96
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: disclosure blocks balanced**: 20/20
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: status control present**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N2: notes control present**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: collapsible H2/H3 hierarchy**: H2=8, H3=9
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: native input names unique**: 2 controls
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: every code block syntax-compiles**: 14 blocks
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: Markdown fences balanced**: 4
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: disclosure blocks balanced**: 3/3
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: status control present**
- PASS — **SQL_Pipeline_Interview_Arena.deepnote N3: notes control present**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote: YAML parses**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote: exactly 3 notebooks**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote: sortingKey values explicitly quoted**: 272 blocks
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote: block IDs unique**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote: blockGroup IDs unique**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: collapsible H2/H3 hierarchy**: H2=7, H3=11
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: native input names unique**: 2 controls
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: every code block syntax-compiles**: 15 blocks
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: Markdown fences balanced**: 6
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: disclosure blocks balanced**: 3/3
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: status control present**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N1: notes control present**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: collapsible H2/H3 hierarchy**: H2=6, H3=3
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: native input names unique**: 7 controls
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: every code block syntax-compiles**: 40 blocks
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: Markdown fences balanced**: 20
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: disclosure blocks balanced**: 6/6
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: status control present**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N2: notes control present**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: collapsible H2/H3 hierarchy**: H2=5, H3=28
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: native input names unique**: 22 controls
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: every code block syntax-compiles**: 9 blocks
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: Markdown fences balanced**: 0
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: disclosure blocks balanced**: 8/8
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: status control present**
- PASS — **Hybrid_Data_Engineering_BI_Interview_Arena.deepnote N3: notes control present**
- PASS — **Exactly 9 IPYNB backups**: 9
- PASS — **IPYNB valid: 01_01_Python_Core_Interview_Arena.ipynb**: 72 cells
- PASS — **IPYNB valid: 02_02_Pandas_NumPy_Data_Wrangling_Arena.ipynb**: 62 cells
- PASS — **IPYNB valid: 03_03_PySpark_DataFrame_Interview_Arena.ipynb**: 88 cells
- PASS — **IPYNB valid: 01_01_SQL_Screener_and_Onsite_Arena.ipynb**: 359 cells
- PASS — **IPYNB valid: 02_02_SQL_Patterns_Optimization_Interview_Playbook.ipynb**: 124 cells
- PASS — **IPYNB valid: 03_03_Airflow_Pipeline_SQL_Data_Engineering_Arena.ipynb**: 52 cells
- PASS — **IPYNB valid: 01_01_BI_Analytics_Engineering_dbt_DAX_Power_BI.ipynb**: 54 cells
- PASS — **IPYNB valid: 02_02_Mixed_Data_Engineering_Technical_Mock_Exams.ipynb**: 110 cells
- PASS — **IPYNB valid: 03_03_Conceptual_Data_Engineering_Mock_Exam.ipynb**: 108 cells
- PASS — **No individual stored artifact exceeds 5 MB**: []
- PASS — **Spark benchmark hard cap is 2M**
- PASS — **Spark benchmark options are 100k/500k/2M**
- PASS — **No Spark benchmark 5M option remains**
- PASS — **Large benchmark DataFrame is not collected**
- PASS — **No cached/persisted benchmark**
- PASS — **Spark uses local[2]**
- PASS — **Spark shuffle partitions = 4**
- PASS — **Spark default parallelism = 2**
- PASS — **Spark AQE enabled**
- PASS — **Spark formatted plan exercise present**
- PASS — **SQL project retains 10 classic exams**: 10
- PASS — **Hybrid conceptual exam retains 20 QCM**: 20
- PASS — **Hybrid technical notebook retains 3 mixed mocks**: 3
- PASS — **Runtime probe: Python core patterns**
- PASS — **Runtime probe: Pandas merge/transform**
- PASS — **Runtime probe: NumPy broadcasting/top-K**
- PASS — **Runtime probe: SQLite EXPLAIN/index demo**
- PASS — **Runtime probe: QCM canonical answer map = 20**
- PASS — **Validation environment has Java for Spark startup shape**: /usr/bin/java